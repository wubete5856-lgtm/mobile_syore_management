<?php
require_once 'config/config.php';
$db = getDB();
$hash = password_hash('admin123', PASSWORD_DEFAULT);
$stmt = $db->prepare("UPDATE users SET password = :hash");
$stmt->execute([':hash' => $hash]);
echo "✅ Password reset to admin123 for all users. Delete this file now.";
?>