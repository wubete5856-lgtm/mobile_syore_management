<?php
require_once '../config/config.php';
requireRole('admin');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Users - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h2><i class="fas fa-users"></i> Manage Users</h2>
            <button class="btn btn-primary" onclick="openAddModal()">
                <i class="fas fa-user-plus"></i> Add User
            </button>
        </div>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="usersBody">
                            <tr><td colspan="7" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- User Modal -->
    <div class="modal fade" id="userModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle"><i class="fas fa-user-plus"></i> Add User</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="userForm">
                        <input type="hidden" id="userId" value="0">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Username *</label>
                            <input type="text" class="form-control" id="username" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Full Name *</label>
                            <input type="text" class="form-control" id="full_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" class="form-control" id="email">
                        </div>
                        <div class="mb-3" id="passwordField">
                            <label class="form-label fw-bold" id="passwordLabel">Password *</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter password (min 6 chars)">
                            <small class="text-muted" id="passwordHint">Required for new users</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Role</label>
                            <select class="form-control" id="role">
                                <option value="admin">Admin</option>
                                <option value="manager">Manager</option>
                                <option value="store_keeper">Store Keeper</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Status</label>
                            <select class="form-control" id="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div id="formAlert"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveUserBtn">
                        <i class="fas fa-save"></i> Save User
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(function() {
        loadUsers();

        window.openAddModal = function() {
            resetForm();
            $('#modalTitle').html('<i class="fas fa-user-plus"></i> Add User');
            $('#passwordLabel').text('Password *');
            $('#password').attr('placeholder', 'Enter password (min 6 chars)');
            $('#passwordHint').text('Required for new users');
            $('#password').prop('required', true);
            $('#userModal').modal('show');
        };

        $('#saveUserBtn').click(function() {
            const id = $('#userId').val();
            const username = $('#username').val().trim();
            const full_name = $('#full_name').val().trim();
            const email = $('#email').val().trim();
            const password = $('#password').val();
            const role = $('#role').val();
            const status = $('#status').val();

            if (!username || !full_name) {
                showAlert('danger', 'Username and Full Name are required');
                return;
            }
            if (id == 0 && !password) {
                showAlert('danger', 'Password is required for new users');
                return;
            }
            if (password && password.length < 6) {
                showAlert('danger', 'Password must be at least 6 characters');
                return;
            }

            const data = {
                action: id > 0 ? 'update' : 'create',
                id: id,
                username: username,
                full_name: full_name,
                email: email,
                password: password,
                role: role,
                status: status
            };

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Saving...').prop('disabled', true);

            $.ajax({
                url: '../api/users.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        setTimeout(function() {
                            $('#userModal').modal('hide');
                            loadUsers();
                            resetForm();
                        }, 1000);
                    } else {
                        showAlert('danger', res.message);
                    }
                },
                error: function() {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error saving user');
                }
            });
        });

        $(document).on('click', '.edit-user', function() {
            const id = $(this).data('id');
            $.ajax({
                url: '../api/users.php',
                type: 'GET',
                data: { id: id },
                dataType: 'json',
                success: function(res) {
                    if (res.success && res.data) {
                        const u = res.data;
                        $('#userId').val(u.id);
                        $('#username').val(u.username);
                        $('#full_name').val(u.full_name);
                        $('#email').val(u.email || '');
                        $('#role').val(u.role);
                        $('#status').val(u.status);
                        $('#password').val('');
                        $('#modalTitle').html('<i class="fas fa-edit"></i> Edit User');
                        $('#passwordLabel').text('New Password (optional)');
                        $('#password').attr('placeholder', 'Leave blank to keep current');
                        $('#passwordHint').text('Leave blank to keep current password');
                        $('#password').prop('required', false);
                        $('#userModal').modal('show');
                    } else {
                        alert('Failed to load user data');
                    }
                },
                error: function() {
                    alert('Error loading user data');
                }
            });
        });

        $(document).on('click', '.delete-user', function() {
            const id = $(this).data('id');
            const username = $(this).data('username');
            if (username === 'admin') {
                alert('Cannot delete the system admin user');
                return;
            }
            if (confirm('Delete user "' + username + '"? This cannot be undone.')) {
                $.ajax({
                    url: '../api/users.php',
                    type: 'POST',
                    data: { action: 'delete', id: id },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            showAlert('success', res.message);
                            loadUsers();
                        } else {
                            alert(res.message);
                        }
                    },
                    error: function() {
                        alert('Error deleting user');
                    }
                });
            }
        });

        $('#userModal').on('hidden.bs.modal', function() {
            resetForm();
        });

        function resetForm() {
            $('#userId').val('0');
            $('#username').val('');
            $('#full_name').val('');
            $('#email').val('');
            $('#password').val('');
            $('#role').val('store_keeper');
            $('#status').val('active');
            $('#formAlert').html('');
            $('#modalTitle').html('<i class="fas fa-user-plus"></i> Add User');
            $('#passwordLabel').text('Password *');
            $('#password').attr('placeholder', 'Enter password (min 6 chars)');
            $('#passwordHint').text('Required for new users');
            $('#password').prop('required', true);
        }

        function loadUsers() {
            $.ajax({
                url: '../api/users.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data && res.data.length > 0) {
                        res.data.forEach(function(u) {
                            const statusBadge = u.status === 'active' ?
                                '<span class="badge bg-success">Active</span>' :
                                '<span class="badge bg-danger">Inactive</span>';
                            const roleBadge = u.role === 'admin' ?
                                '<span class="badge bg-danger">Admin</span>' :
                                u.role === 'manager' ?
                                '<span class="badge bg-warning text-dark">Manager</span>' :
                                '<span class="badge bg-info">Store Keeper</span>';
                            html += `<tr>
                                <td>${u.id}</td>
                                <td><strong>${u.username}</strong></td>
                                <td>${u.full_name}</td>
                                <td>${u.email || '-'}</td>
                                <td>${roleBadge}</td>
                                <td>${statusBadge}</td>
                                <td>
                                    <button class="btn btn-sm btn-warning edit-user" data-id="${u.id}" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-user" data-id="${u.id}" data-username="${u.username}" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = '<tr><td colspan="7" class="text-center">No users found</td></tr>';
                    }
                    $('#usersBody').html(html);
                },
                error: function() {
                    $('#usersBody').html('<tr><td colspan="7" class="text-center text-danger">Failed to load users</td></tr>');
                }
            });
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#formAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#formAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }
    });
    </script>
</body>
</html>