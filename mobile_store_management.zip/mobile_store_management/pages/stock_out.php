<?php require_once '../config/config.php'; requireLogin(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Issue Materials - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-arrow-up"></i> Issue Materials (Stock Out)</h2>
        <hr>

        <!-- Tabs -->
        <ul class="nav nav-tabs" id="stockOutTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="request-tab" data-bs-toggle="tab" href="#request" role="tab">New Request</a>
            </li>
            <?php if (hasRole('admin') || hasRole('manager')): ?>
            <li class="nav-item">
                <a class="nav-link" id="approve-tab" data-bs-toggle="tab" href="#approve" role="tab">Pending Approvals</a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link" id="history-tab" data-bs-toggle="tab" href="#history" role="tab">Request History</a>
            </li>
        </ul>

        <div class="tab-content mt-3">
            <!-- New Request Tab -->
            <div class="tab-pane fade show active" id="request" role="tabpanel">
                <div class="card shadow">
                    <div class="card-header"><h5>Create Stock Out Request</h5></div>
                    <div class="card-body">
                        <form id="stockOutForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3"><label>Model *</label>
                                        <select class="form-control" id="soModel" required></select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3"><label>Quantity *</label>
                                        <input type="number" class="form-control" id="soQty" min="1" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3"><label>Department</label>
                                        <input type="text" class="form-control" id="soDepartment">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3"><label>Employee Name</label>
                                        <input type="text" class="form-control" id="soEmployee">
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label>Purpose</label>
                                <textarea class="form-control" id="soPurpose" rows="2"></textarea>
                            </div>
                            <div id="soAlert"></div>
                            <button type="submit" class="btn btn-warning"><i class="fas fa-paper-plane"></i> Submit Request</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Approvals Tab (Admin/Manager only) -->
            <?php if (hasRole('admin') || hasRole('manager')): ?>
            <div class="tab-pane fade" id="approve" role="tabpanel">
                <div class="card shadow">
                    <div class="card-header"><h5>Pending Requests</h5></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead><tr><th>Date</th><th>Model</th><th>Qty</th><th>Department</th><th>Employee</th><th>Requested By</th><th>Action</th></tr></thead>
                                <tbody id="pendingRequests"><tr><td colspan="7" class="text-center">Loading...</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- History Tab -->
            <div class="tab-pane fade" id="history" role="tabpanel">
                <div class="card shadow">
                    <div class="card-header"><h5>All Requests</h5></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead><tr><th>Date</th><th>Model</th><th>Qty</th><th>Status</th><th>Approved By</th></tr></thead>
                                <tbody id="historyRequests"><tr><td colspan="6" class="text-center">Loading...</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(function() {
        loadModels();
        loadPending();
        loadHistory();

        // Submit request
        $('#stockOutForm').on('submit', function(e) {
            e.preventDefault();
            const model = $('#soModel').val();
            const qty = $('#soQty').val();
            if (!model || !qty) {
                $('#soAlert').html('<div class="alert alert-danger">Model and Quantity are required</div>');
                return;
            }
            const data = {
                model_id: model,
                quantity: qty,
                department: $('#soDepartment').val().trim(),
                employee: $('#soEmployee').val().trim(),
                purpose: $('#soPurpose').val().trim()
            };
            $.post('../api/stock_out.php', data, function(res) {
                if (res.success) {
                    $('#soAlert').html('<div class="alert alert-success">'+res.message+'</div>');
                    $('#stockOutForm')[0].reset();
                    loadPending();
                    loadHistory();
                } else {
                    $('#soAlert').html('<div class="alert alert-danger">'+res.message+'</div>');
                }
            }, 'json');
        });

        // Approve / Reject
        $(document).on('click', '.approve-request', function() {
            const id = $(this).data('id');
            if (confirm('Approve this request?')) {
                $.post('../api/stock_out.php', { action: 'approve', id: id }, function(res) {
                    if (res.success) { loadPending(); loadHistory(); alert(res.message); } else alert(res.message);
                }, 'json');
            }
        });
        $(document).on('click', '.reject-request', function() {
            const id = $(this).data('id');
            const reason = prompt('Rejection reason:');
            if (reason !== null) {
                $.post('../api/stock_out.php', { action: 'reject', id: id, reason: reason }, function(res) {
                    if (res.success) { loadPending(); loadHistory(); alert(res.message); } else alert(res.message);
                }, 'json');
            }
        });

        function loadModels() {
            $.get('../api/materials.php', function(res) {
                let opts = '<option value="">Select Model</option>';
                if (res.success) {
                    res.data.forEach(m => {
                        opts += `<option value="${m.id}">${m.code} - ${m.name} (Stock: ${m.current_stock})</option>`;
                    });
                }
                $('#soModel').html(opts);
            }, 'json');
        }

        function loadPending() {
            $.get('../api/stock_out.php', { status: 'pending' }, function(res) {
                let html = '';
                if (res.success && res.data.length) {
                    res.data.forEach(r => {
                        html += `<tr>
                            <td>${new Date(r.transaction_date).toLocaleDateString()}</td>
                            <td>${r.model_name||''}</td>
                            <td>${r.quantity}</td>
                            <td>${r.department||''}</td>
                            <td>${r.employee_name||''}</td>
                            <td>${r.full_name||''}</td>
                            <td>
                                <button class="btn btn-sm btn-success approve-request" data-id="${r.id}"><i class="fas fa-check"></i> Approve</button>
                                <button class="btn btn-sm btn-danger reject-request" data-id="${r.id}"><i class="fas fa-times"></i> Reject</button>
                            </td>
                        </tr>`;
                    });
                } else { html = '<tr><td colspan="7" class="text-center">No pending requests</td></tr>'; }
                $('#pendingRequests').html(html);
            }, 'json');
        }

        function loadHistory() {
            $.get('../api/stock_out.php', { history: 1 }, function(res) {
                let html = '';
                if (res.success && res.data.length) {
                    res.data.forEach(r => {
                        const statusClass = r.status === 'APPROVED' ? 'success' : (r.status === 'REJECTED' ? 'danger' : 'warning');
                        html += `<tr>
                            <td>${new Date(r.transaction_date).toLocaleDateString()}</td>
                            <td>${r.model_name||''}</td>
                            <td>${r.quantity}</td>
                            <td><span class="badge bg-${statusClass}">${r.status}</span></td>
                            <td>${r.approved_by_name||''}</td>
                        </tr>`;
                    });
                } else { html = '<tr><td colspan="5" class="text-center">No history</td></tr>'; }
                $('#historyRequests').html(html);
            }, 'json');
        }

        // Refresh when tabs change
        $('#stockOutTabs a').on('shown.bs.tab', function(e) {
            const target = $(e.target).attr('href');
            if (target === '#approve') loadPending();
            if (target === '#history') loadHistory();
        });
    });
    </script>
</body>
</html>