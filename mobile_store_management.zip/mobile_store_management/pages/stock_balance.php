<?php
require_once '../config/config.php';
requireLogin();

// Only Manager can access this page
if (!hasRole('manager')) {
    header('Location: dashboard.php');
    exit();
}

$role = $_SESSION['role'];
$userName = $_SESSION['full_name'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Stock Balance - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-database"></i> Stock Balance</h2>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Device</th>
                                <th>Category</th>
                                <th>Current Stock</th>
                                <th>Min Stock</th>
                                <th>Unit Price</th>
                                <th>Total Value</th>
                            </tr>
                        </thead>
                        <tbody id="balanceBody">
                            <tr><td colspan="7" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        $.ajax({
            url: '../api/stock_balance.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                let html = '';
                let grandTotal = 0;
                if (data.success && data.data.length) {
                    data.data.forEach(function(m) {
                        const total = m.current_stock * m.unit_price;
                        grandTotal += total;
                        html += `<tr>
                            <td><strong>${m.code}</strong></td>
                            <td>${m.name}</td>
                            <td>${m.category_name || '-'}</td>
                            <td>${m.current_stock}</td>
                            <td>${m.min_stock_level}</td>
                            <td>$${parseFloat(m.unit_price).toFixed(2)}</td>
                            <td>$${total.toFixed(2)}</td>
                        </tr>`;
                    });
                    html += `<tr class="table-info">
                        <td colspan="6"><strong>Grand Total Value</strong></td>
                        <td><strong>$${grandTotal.toFixed(2)}</strong></td>
                    </tr>`;
                } else {
                    html = '<tr><td colspan="7" class="text-center text-muted">No stock data</td></tr>';
                }
                $('#balanceBody').html(html);
            },
            error: function() {
                $('#balanceBody').html('<tr><td colspan="7" class="text-center text-danger">Failed to load stock balance</td></tr>');
            }
        });
    });
    </script>
</body>
</html>