<?php
require_once '../config/config.php';
requireLogin(); // All logged-in users can manage brands
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Brands - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h2><i class="fas fa-tag"></i> Brands</h2>
            <button class="btn btn-primary" onclick="openAddModal()">
                <i class="fas fa-plus-circle"></i> Add Brand
            </button>
        </div>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="brandsBody">
                            <tr><td colspan="5" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Brand Modal -->
    <div class="modal fade" id="brandModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle"><i class="fas fa-tag"></i> Add Brand</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="brandForm" autocomplete="off">
                        <input type="hidden" id="brandId" value="0">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Brand Name *</label>
                            <input type="text" class="form-control" id="brandName" placeholder="e.g., Apple, Samsung" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea class="form-control" id="brandDesc" rows="2" placeholder="Optional description"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Status</label>
                            <select class="form-control" id="brandStatus">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div id="brandAlert"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveBrandBtn">
                        <i class="fas fa-save"></i> Save Brand
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(function() {
        loadBrands();

        window.openAddModal = function() {
            resetForm();
            $('#modalTitle').html('<i class="fas fa-tag"></i> Add Brand');
            $('#brandModal').modal('show');
            $('#brandName').focus();
        };

        // ========== SAVE BRAND ==========
        $('#saveBrandBtn').on('click', function() {
            const id = $('#brandId').val();
            const name = $('#brandName').val().trim();
            const description = $('#brandDesc').val().trim();
            const status = $('#brandStatus').val();

            console.log('Saving brand:', { id, name, description, status });

            if (!name) {
                showAlert('danger', 'Brand name is required');
                $('#brandName').focus();
                return;
            }

            const data = {
                action: id > 0 ? 'update' : 'create',
                id: id,
                name: name,
                description: description,
                status: status
            };

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Saving...').prop('disabled', true);

            $.ajax({
                url: '../api/brands.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                timeout: 10000,
                success: function(res) {
                    console.log('AJAX Success:', res);
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        setTimeout(function() {
                            $('#brandModal').modal('hide');
                            loadBrands();
                            resetForm();
                        }, 1000);
                    } else {
                        showAlert('danger', res.message || 'Failed to save brand');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    console.error('Response:', xhr.responseText);
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error: ' + status + ' - ' + error);
                }
            });
        });

        // ========== EDIT BRAND ==========
        $(document).on('click', '.edit-brand', function() {
            const id = $(this).data('id');
            console.log('Editing brand ID:', id);
            $.ajax({
                url: '../api/brands.php',
                type: 'GET',
                data: { id: id },
                dataType: 'json',
                success: function(res) {
                    if (res.success && res.data) {
                        const b = res.data;
                        $('#brandId').val(b.id);
                        $('#brandName').val(b.name);
                        $('#brandDesc').val(b.description || '');
                        $('#brandStatus').val(b.status || 'active');
                        $('#modalTitle').html('<i class="fas fa-edit"></i> Edit Brand');
                        $('#brandModal').modal('show');
                    } else {
                        showAlert('danger', 'Failed to load brand data');
                    }
                },
                error: function() {
                    showAlert('danger', 'Error loading brand data');
                }
            });
        });

        // ========== DELETE BRAND ==========
        $(document).on('click', '.delete-brand', function() {
            const id = $(this).data('id');
            if (confirm('Delete this brand?')) {
                $.ajax({
                    url: '../api/brands.php',
                    type: 'POST',
                    data: { action: 'delete', id: id },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            showAlert('success', res.message);
                            loadBrands();
                        } else {
                            showAlert('danger', res.message);
                        }
                    },
                    error: function() {
                        showAlert('danger', 'Error deleting brand');
                    }
                });
            }
        });

        // ========== RESET FORM ==========
        $('#brandModal').on('hidden.bs.modal', function() {
            resetForm();
        });

        function resetForm() {
            $('#brandId').val('0');
            $('#brandName').val('');
            $('#brandDesc').val('');
            $('#brandStatus').val('active');
            $('#brandAlert').html('');
            $('#modalTitle').html('<i class="fas fa-tag"></i> Add Brand');
        }

        // ========== LOAD BRANDS ==========
        function loadBrands() {
            console.log('Loading brands...');
            $.ajax({
                url: '../api/brands.php',
                type: 'GET',
                dataType: 'json',
                timeout: 10000,
                success: function(res) {
                    console.log('Brands loaded:', res);
                    let html = '';
                    if (res.success && res.data && res.data.length > 0) {
                        res.data.forEach(function(b) {
                            const statusBadge = b.status === 'active' ?
                                '<span class="badge bg-success">Active</span>' :
                                '<span class="badge bg-danger">Inactive</span>';
                            html += `<tr>
                                <td>${b.id}</td>
                                <td><strong>${b.name}</strong></td>
                                <td>${b.description || '-'}</td>
                                <td>${statusBadge}</td>
                                <td>
                                    <button class="btn btn-sm btn-warning edit-brand" data-id="${b.id}" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-brand" data-id="${b.id}" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = '<tr><td colspan="5" class="text-center text-muted">No brands found. Click "Add Brand" to create one.</td></tr>';
                    }
                    $('#brandsBody').html(html);
                },
                error: function(xhr, status, error) {
                    console.error('Load brands error:', status, error);
                    $('#brandsBody').html('<tr><td colspan="5" class="text-center text-danger">Failed to load brands: ' + error + '</td></tr>');
                }
            });
        }

        // ========== SHOW ALERT ==========
        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#brandAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#brandAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }

        // Enter key support
        $('#brandName').on('keypress', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                $('#saveBrandBtn').click();
            }
        });
    });
    </script>
</body>
</html>