x<?php
require_once '../config/config.php';
requireLogin();

// Only Admin and Manager can access this page
if (!hasRole('admin') && !hasRole('manager')) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Monitor Inventory - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-warehouse"></i> Monitor Inventory</h2>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Stock</th>
                                <th>Min Stock</th>
                                <th>Max Stock</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="invBody">
                            <tr><td colspan="7" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        $.ajax({
            url: '../api/inventory.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                let html = '';
                if (data.success && data.data.length) {
                    data.data.forEach(function(m) {
                        const stockStatus = m.current_stock <= m.reorder_point ?
                            '<span class="badge bg-danger">Low</span>' :
                            '<span class="badge bg-success">OK</span>';
                        const statusBadge = m.status === 'active' ?
                            '<span class="badge bg-success">Active</span>' :
                            '<span class="badge bg-danger">Inactive</span>';
                        html += `<tr>
                            <td><strong>${m.code}</strong></td>
                            <td>${m.name}</td>
                            <td>${m.category_name || '-'}</td>
                            <td>${m.current_stock} ${stockStatus}</td>
                            <td>${m.min_stock_level}</td>
                            <td>${m.max_stock_level}</td>
                            <td>${statusBadge}</td>
                        </tr>`;
                    });
                } else {
                    html = '<tr><td colspan="7" class="text-center text-muted">No inventory data</td></tr>';
                }
                $('#invBody').html(html);
            },
            error: function(xhr) {
                $('#invBody').html(`
                    <tr><td colspan="7" class="text-center text-danger">
                        Failed to load inventory. Error: ${xhr.status} - ${xhr.statusText}
                    </td></tr>
                `);
            }
        });
    });
    </script>
</body>
</html>