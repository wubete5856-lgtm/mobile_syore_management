<?php require_once '../config/config.php'; requireRole('admin'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>System Settings - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-cog"></i> System Settings</h2>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <form id="settingsForm">
                    <div id="settingsAlert"></div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3"><label>Company Name</label>
                                <input type="text" class="form-control" id="company_name" name="company_name"></div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3"><label>Currency Symbol</label>
                                <input type="text" class="form-control" id="currency_symbol" name="currency_symbol"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3"><label>Company Address</label>
                                <input type="text" class="form-control" id="company_address" name="company_address"></div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3"><label>Company Phone</label>
                                <input type="text" class="form-control" id="company_phone" name="company_phone"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3"><label>Company Email</label>
                                <input type="email" class="form-control" id="company_email" name="company_email"></div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3"><label>Low Stock Threshold</label>
                                <input type="number" class="form-control" id="low_stock_threshold" name="low_stock_threshold"></div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Settings</button>
                </form>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadSettings();
        $('#settingsForm').on('submit', function(e) {
            e.preventDefault();
            const data = $(this).serialize();
            $.post('../api/settings.php', data, function(res) {
                if (res.success) {
                    $('#settingsAlert').html('<div class="alert alert-success">'+res.message+'</div>');
                } else {
                    $('#settingsAlert').html('<div class="alert alert-danger">'+res.message+'</div>');
                }
            }, 'json');
        });
        function loadSettings() {
            $.get('../api/settings.php', function(data) {
                if (data.success) {
                    const s = data.data;
                    Object.keys(s).forEach(key => { $(`#${key}`).val(s[key]); });
                }
            }, 'json');
        }
    });
    </script>
</body>
</html>