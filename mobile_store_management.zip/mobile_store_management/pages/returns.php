<?php require_once '../config/config.php'; requireLogin(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Return Materials - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-undo"></i> Return Materials</h2>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Return Form</h5></div>
                    <div class="card-body">
                        <form id="returnForm">
                            <div class="mb-3">
                                <label>Model *</label>
                                <select class="form-control" id="retModel" required></select>
                            </div>
                            <div class="mb-3">
                                <label>Quantity *</label>
                                <input type="number" class="form-control" id="retQty" min="1" required>
                            </div>
                            <div class="mb-3">
                                <label>Reason *</label>
                                <textarea class="form-control" id="retReason" rows="2" required></textarea>
                            </div>
                            <div id="retAlert"></div>
                            <button type="submit" class="btn btn-info"><i class="fas fa-undo"></i> Return</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Return History</h5></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead><tr><th>Date</th><th>Model</th><th>Qty</th><th>Reason</th></tr></thead>
                                <tbody id="retHistory"><tr><td colspan="4" class="text-center">Loading...</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadModels();
        loadHistory();
        $('#returnForm').on('submit', function(e) {
            e.preventDefault();
            const model = $('#retModel').val();
            const qty = $('#retQty').val();
            const reason = $('#retReason').val().trim();
            if (!model || !qty || !reason) {
                $('#retAlert').html('<div class="alert alert-danger">All fields required</div>');
                return;
            }
            const data = { model_id: model, quantity: qty, reason: reason };
            $.post('../api/returns.php', data, function(res) {
                if (res.success) {
                    $('#retAlert').html('<div class="alert alert-success">'+res.message+'</div>');
                    $('#returnForm')[0].reset();
                    loadHistory();
                } else {
                    $('#retAlert').html('<div class="alert alert-danger">'+res.message+'</div>');
                }
            }, 'json');
        });
        function loadModels() {
            $.get('../api/materials.php', function(res) {
                let opts = '<option value="">Select Model</option>';
                if (res.success) res.data.forEach(m => opts += `<option value="${m.id}">${m.code} - ${m.name}</option>`);
                $('#retModel').html(opts);
            }, 'json');
        }
        function loadHistory() {
            $.get('../api/returns.php', function(res) {
                let html = '';
                if (res.success && res.data.length) {
                    res.data.forEach(r => {
                        html += `<tr>
                            <td>${new Date(r.transaction_date).toLocaleDateString()}</td>
                            <td>${r.model_name||''}</td>
                            <td>${r.quantity}</td>
                            <td>${r.notes||''}</td>
                        </tr>`;
                    });
                } else {
                    html = '<tr><td colspan="4" class="text-center">No returns</td></tr>';
                }
                $('#retHistory').html(html);
            }, 'json');
        }
    });
    </script>
</body>
</html>