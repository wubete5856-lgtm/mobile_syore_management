<?php require_once '../config/config.php'; requireRole('admin'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Audit Log - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-clipboard-list"></i> Audit Log</h2>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Action</th>
                                <th>Module</th>
                                <th>Description</th>
                                <th>IP</th>
                                <th>Date/Time</th>
                            </tr>
                        </thead>
                        <tbody id="auditBody">
                            <tr><td colspan="7" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        $.get('../api/audit_log.php', function(data) {
            let html = '';
            if (data.success && data.data.length) {
                data.data.forEach(log => {
                    html += `<tr>
                        <td>${log.id}</td>
                        <td>${log.full_name || 'System'}</td>
                        <td><span class="badge bg-primary">${log.action}</span></td>
                        <td>${log.module || '-'}</td>
                        <td>${log.description}</td>
                        <td>${log.ip_address || '-'}</td>
                        <td>${new Date(log.created_at).toLocaleString()}</td>
                    </tr>`;
                });
            } else {
                html = '<tr><td colspan="7" class="text-center">No audit records</td></tr>';
            }
            $('#auditBody').html(html);
        }, 'json');
    });
    </script>
</body>
</html>