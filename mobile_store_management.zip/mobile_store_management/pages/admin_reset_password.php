<?php
require_once '../config/config.php';
requireRole('admin');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reset Passwords - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-key text-primary"></i> Reset User Passwords</h2>
        <hr>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> Enter a new password for any user below. The password will be hashed and updated immediately.
        </div>
        <div id="globalAlert"></div>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Role</th>
                                <th>New Password</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="usersBody">
                            <tr>
                                <td colspan="6" class="text-center py-3">
                                    <div class="spinner-border text-primary" role="status"></div>
                                    <p class="mt-2">Loading users...</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadUsers();

        $(document).on('click', '.reset-password-btn', function() {
            const id = $(this).data('id');
            const username = $(this).data('username');
            const password = $(`#new_password_${id}`).val().trim();

            if (!password || password.length < 6) {
                showAlert('danger', 'Password must be at least 6 characters');
                return;
            }

            if (!confirm(`Reset password for user "${username}"?`)) return;

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);

            $.ajax({
                url: '../api/admin_reset_password.php',
                type: 'POST',
                data: { id: id, password: password },
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        $(`#new_password_${id}`).val('');
                    } else {
                        showAlert('danger', res.message);
                    }
                },
                error: function(xhr, status, error) {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'AJAX Error: ' + status + ' - ' + error);
                    console.error('AJAX Error:', xhr.responseText);
                }
            });
        });

        function loadUsers() {
            $.ajax({
                url: '../api/admin_reset_password.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data && res.data.length > 0) {
                        res.data.forEach(function(u) {
                            const roleBadge = u.role === 'admin' ?
                                '<span class="badge bg-danger">Admin</span>' :
                                u.role === 'manager' ?
                                '<span class="badge bg-warning text-dark">Manager</span>' :
                                '<span class="badge bg-info">Store Keeper</span>';
                            html += `<tr>
                                <td>${u.id}</td>
                                <td><strong>${u.username}</strong></td>
                                <td>${u.full_name}</td>
                                <td>${roleBadge}</td>
                                <td><input type="password" class="form-control" id="new_password_${u.id}" placeholder="Enter new password (min 6 chars)" style="min-width:150px;"></td>
                                <td><button class="btn btn-sm btn-primary reset-password-btn" data-id="${u.id}" data-username="${u.username}"><i class="fas fa-key"></i> Reset</button></td>
                            </tr>`;
                        });
                    } else {
                        html = `<tr><td colspan="6" class="text-center text-muted py-3">
                            <i class="fas fa-info-circle"></i> ${res.message || 'No users found'}</td></tr>`;
                    }
                    $('#usersBody').html(html);
                },
                error: function(xhr, status, error) {
                    $('#usersBody').html(`
                        <tr><td colspan="6" class="text-center text-danger py-3">
                            <i class="fas fa-exclamation-triangle"></i> Failed to load users: ${error}
                            <br><small>Check browser console for details.</small>
                        </td></tr>
                    `);
                    console.error('Error loading users:', xhr.responseText);
                }
            });
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#globalAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#globalAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }
    });
    </script>
</body>
</html>