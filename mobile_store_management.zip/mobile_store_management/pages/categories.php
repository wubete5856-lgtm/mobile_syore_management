<?php
require_once '../config/config.php';
requireRole('admin');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Categories - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h2><i class="fas fa-tags"></i> Categories</h2>
            <button class="btn btn-primary" onclick="openAddModal()">
                <i class="fas fa-plus-circle"></i> Add Category
            </button>
        </div>
        <hr>
        <div id="globalError" class="alert alert-danger" style="display:none;"></div>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Parent</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="categoriesBody">
                            <tr><td colspan="6" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Category Modal -->
    <div class="modal fade" id="categoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle"><i class="fas fa-tag"></i> Add Category</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="categoryForm" autocomplete="off">
                        <input type="hidden" id="categoryId" value="0">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="categoryName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea class="form-control" id="categoryDesc" rows="2"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Parent Category</label>
                            <select class="form-control" id="categoryParent">
                                <option value="">None (Top Level)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Status</label>
                            <select class="form-control" id="categoryStatus">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div id="modalAlert"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveCategoryBtn">
                        <i class="fas fa-save"></i> Save Category
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadCategories();
        loadParentOptions();

        window.openAddModal = function() {
            resetForm();
            $('#modalTitle').html('<i class="fas fa-tag"></i> Add Category');
            $('#categoryModal').modal('show');
            $('#categoryName').focus();
        };

        // Save
        $('#saveCategoryBtn').click(function() {
            const id = $('#categoryId').val();
            const name = $('#categoryName').val().trim();
            const description = $('#categoryDesc').val().trim();
            const parent_id = $('#categoryParent').val();
            const status = $('#categoryStatus').val();

            if (!name) {
                showModalAlert('danger', 'Category name is required');
                return;
            }

            const data = {
                action: id > 0 ? 'update' : 'create',
                id: id,
                name: name,
                description: description,
                parent_id: parent_id || '',
                status: status
            };

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Saving...').prop('disabled', true);

            $.ajax({
                url: '../api/categories.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showModalAlert('success', res.message);
                        setTimeout(function() {
                            $('#categoryModal').modal('hide');
                            loadCategories();
                            loadParentOptions();
                            resetForm();
                        }, 1000);
                    } else {
                        showModalAlert('danger', res.message || 'Failed to save');
                    }
                },
                error: function(xhr) {
                    $btn.html(originalText).prop('disabled', false);
                    showModalAlert('danger', 'AJAX Error: ' + xhr.status + ' - ' + xhr.statusText);
                }
            });
        });

        // Edit
        $(document).on('click', '.edit-category', function() {
            const id = $(this).data('id');
            $.ajax({
                url: '../api/categories.php',
                type: 'GET',
                data: { id: id },
                dataType: 'json',
                success: function(res) {
                    if (res.success && res.data) {
                        const c = res.data;
                        $('#categoryId').val(c.id);
                        $('#categoryName').val(c.name);
                        $('#categoryDesc').val(c.description || '');
                        $('#categoryParent').val(c.parent_id || '');
                        $('#categoryStatus').val(c.status || 'active');
                        $('#modalTitle').html('<i class="fas fa-edit"></i> Edit Category');
                        $('#categoryModal').modal('show');
                    } else {
                        showModalAlert('danger', 'Failed to load category data');
                    }
                },
                error: function() {
                    showModalAlert('danger', 'Error loading category data');
                }
            });
        });

        // Delete
        $(document).on('click', '.delete-category', function() {
            const id = $(this).data('id');
            const name = $(this).data('name');
            if (confirm('Delete category "' + name + '"? This cannot be undone.')) {
                $.ajax({
                    url: '../api/categories.php',
                    type: 'POST',
                    data: { action: 'delete', id: id },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            showGlobalAlert('success', res.message);
                            loadCategories();
                            loadParentOptions();
                        } else {
                            showGlobalAlert('danger', res.message);
                        }
                    },
                    error: function() {
                        showGlobalAlert('danger', 'Error deleting category');
                    }
                });
            }
        });

        // Reset modal when hidden
        $('#categoryModal').on('hidden.bs.modal', resetForm);

        function resetForm() {
            $('#categoryId').val('0');
            $('#categoryName').val('');
            $('#categoryDesc').val('');
            $('#categoryParent').val('');
            $('#categoryStatus').val('active');
            $('#modalAlert').html('');
            $('#modalTitle').html('<i class="fas fa-tag"></i> Add Category');
        }

        // Load categories
        function loadCategories() {
            $.ajax({
                url: '../api/categories.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data && res.data.length > 0) {
                        res.data.forEach(function(c) {
                            const statusBadge = c.status === 'active' ?
                                '<span class="badge bg-success">Active</span>' :
                                '<span class="badge bg-danger">Inactive</span>';
                            html += `<tr>
                                <td>${c.id}</td>
                                <td><strong>${c.name}</strong></td>
                                <td>${c.description || '-'}</td>
                                <td>${c.parent_name || 'None'}</td>
                                <td>${statusBadge}</td>
                                <td>
                                    <button class="btn btn-sm btn-warning edit-category" data-id="${c.id}"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-sm btn-danger delete-category" data-id="${c.id}" data-name="${c.name}"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = '<tr><td colspan="6" class="text-center text-muted">No categories found. Click "Add Category" to create one.</td></tr>';
                    }
                    $('#categoriesBody').html(html);
                },
                error: function(xhr) {
                    $('#categoriesBody').html(`<tr><td colspan="6" class="text-center text-danger">Failed to load categories. Error: ${xhr.status} - ${xhr.statusText}</td></tr>`);
                    showGlobalAlert('danger', 'Failed to load categories. Check console.');
                }
            });
        }

        // Load parent options
        function loadParentOptions() {
            $.ajax({
                url: '../api/categories.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let opts = '<option value="">None (Top Level)</option>';
                    const currentId = parseInt($('#categoryId').val()) || 0;
                    if (res.success) {
                        res.data.forEach(function(c) {
                            if (c.id !== currentId) {
                                opts += `<option value="${c.id}">${c.name}</option>`;
                            }
                        });
                    }
                    $('#categoryParent').html(opts);
                },
                error: function() {
                    $('#categoryParent').html('<option value="">None (Top Level)</option>');
                }
            });
        }

        // Show alert in modal
        function showModalAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#modalAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#modalAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }

        // Show alert on the page
        function showGlobalAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#globalError').show().html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#globalError .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }
    });
    </script>
</body>
</html>