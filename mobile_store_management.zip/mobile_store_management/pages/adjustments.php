<?php
require_once '../config/config.php';
requireLogin();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Stock Adjustment - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-balance-scale"></i> Stock Adjustment</h2>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Adjust Stock</h5></div>
                    <div class="card-body">
                        <form id="adjustForm">
                            <div class="mb-3">
                                <label>Model *</label>
                                <select class="form-control" id="adjModel" required>
                                    <option value="">Loading models...</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Adjustment Type *</label>
                                <select class="form-control" id="adjType" required>
                                    <option value="increase">Increase (+)</option>
                                    <option value="decrease">Decrease (-)</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Quantity *</label>
                                <input type="number" class="form-control" id="adjQty" min="1" required>
                            </div>
                            <div class="mb-3">
                                <label>Reason *</label>
                                <textarea class="form-control" id="adjReason" rows="2" required></textarea>
                            </div>
                            <div id="adjAlert"></div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Adjust Stock</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Adjustment History</h5></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead><tr><th>Date</th><th>Model</th><th>Type</th><th>Qty</th><th>Reason</th></tr></thead>
                                <tbody id="adjHistory">
                                    <tr><td colspan="5" class="text-center">Loading...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadModels();
        loadHistory();

        $('#adjustForm').on('submit', function(e) {
            e.preventDefault();

            const model = $('#adjModel').val();
            const type = $('#adjType').val();
            const qty = $('#adjQty').val();
            const reason = $('#adjReason').val().trim();

            if (!model || !qty || !reason) {
                showAlert('danger', 'All fields required');
                return;
            }
            if (qty < 1) {
                showAlert('danger', 'Quantity must be at least 1');
                return;
            }

            const data = {
                model_id: model,
                adjustment_type: type,
                quantity: qty,
                reason: reason
            };

            const $btn = $(this).find('button[type="submit"]');
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Processing...').prop('disabled', true);

            $.ajax({
                url: '../api/adjustments.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        $('#adjustForm')[0].reset();
                        loadHistory();
                    } else {
                        showAlert('danger', res.message || 'Adjustment failed');
                    }
                },
                error: function(xhr) {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error: ' + xhr.status + ' - ' + xhr.statusText);
                }
            });
        });

        function loadModels() {
            $.get('../api/materials.php', function(res) {
                let opts = '<option value="">Select Model</option>';
                if (res.success && res.data) {
                    res.data.forEach(m => opts += `<option value="${m.id}">${m.code} - ${m.name}</option>`);
                }
                $('#adjModel').html(opts);
            }, 'json');
        }

        function loadHistory() {
            $.ajax({
                url: '../api/adjustments.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data && res.data.length) {
                        res.data.forEach(a => {
                            const date = a.transaction_date ? new Date(a.transaction_date) : null;
                            const dateStr = date ? date.toLocaleDateString() + ' ' + date.toLocaleTimeString() : 'N/A';
                            const typeClass = a.transaction_type === 'increase' ? 'success' : 'danger';
                            const typeLabel = a.transaction_type === 'increase' ? 'Increase' : 'Decrease';
                            html += `<tr>
                                <td>${dateStr}</td>
                                <td>${a.model_name || ''}</td>
                                <td><span class="badge bg-${typeClass}">${typeLabel}</span></td>
                                <td>${a.quantity}</td>
                                <td>${a.notes || '-'}</td>
                            </tr>`;
                        });
                    } else {
                        html = '<tr><td colspan="5" class="text-center">No adjustments</td></tr>';
                    }
                    $('#adjHistory').html(html);
                },
                error: function() {
                    $('#adjHistory').html('<tr><td colspan="5" class="text-center text-danger">Failed to load history</td></tr>');
                }
            });
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#adjAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(() => { $('#adjAlert .alert').fadeOut(500, function() { $(this).remove(); }); }, 5000);
        }
    });
    </script>
</body>
</html>