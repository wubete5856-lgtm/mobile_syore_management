<?php
require_once '../config/config.php';
requireLogin();

$role = $_SESSION['role'];
$userName = $_SESSION['full_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        .container-fluid { padding: 8px 12px !important; }
        .row { margin: 0 -4px !important; }
        .col, .col-* { padding: 0 4px !important; }
        .card { margin-bottom: 4px !important; border-radius: 6px; }
        .card-body { padding: 0.5rem 0.8rem !important; overflow: visible !important; }
        .card-header { padding: 0.3rem 0.8rem !important; }
        .card.py-2 { padding-top: 0.2rem !important; padding-bottom: 0.2rem !important; }
        .mb-4 { margin-bottom: 0.2rem !important; }
        .mt-4 { margin-top: 0.2rem !important; }
        .mt-2 { margin-top: 0.2rem !important; }
        .mt-3 { margin-top: 0.3rem !important; }
        .mb-3 { margin-bottom: 0.3rem !important; }
        .g-1 { --bs-gutter-y: 0.15rem !important; --bs-gutter-x: 0.15rem !important; }
        .g-2 { --bs-gutter-y: 0.2rem !important; --bs-gutter-x: 0.2rem !important; }
        hr { margin: 0.2rem 0 0.3rem !important; }
        .table-sm td, .table-sm th { padding: 0.2rem 0.4rem !important; font-size: 0.85rem; }
        .table-responsive { margin-top: 0 !important; overflow-x: auto !important; }
        .btn.py-2 { padding-top: 0.2rem !important; padding-bottom: 0.2rem !important; }
        .btn.py-3 { padding-top: 0.3rem !important; padding-bottom: 0.3rem !important; }
        .h5 { font-size: 0.95rem !important; margin-bottom: 0.1rem !important; }
        .text-xs { font-size: 0.65rem !important; }
        .stat-card-link { text-decoration: none; display: block; cursor: pointer; }
        .stat-card-link:hover .card { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .btn-disabled { pointer-events: none !important; opacity: 0.6 !important; cursor: default !important; }
        .chart-container { position: relative; height: 180px !important; width: 100%; }
        .shadow { box-shadow: 0 0.1rem 0.4rem rgba(0,0,0,0.06) !important; }
        .border-left-primary { border-left-width: 3px !important; }
        .border-left-success { border-left-width: 3px !important; }
        .border-left-danger { border-left-width: 3px !important; }
        .border-left-warning { border-left-width: 3px !important; }
        .card .row.g-2 { margin: 0 !important; }
        .card .row.g-2 .col-6 { padding: 2px !important; }
        .mt-1 { margin-top: 0.15rem !important; }
        .mb-1 { margin-bottom: 0.15rem !important; }
        .badge-pulse { animation: pulse 1.5s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
        .main-content {
            margin-left: 220px !important;
            margin-top: 56px !important;
            padding: 16px 20px !important;
            min-height: calc(100vh - 56px);
            background: #f8f9fc;
            overflow: visible !important;
        }
        @media (max-width: 768px) {
            .main-content { margin-left: 0 !important; padding: 10px 12px !important; }
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center">
                    <h2><i class="fas fa-chart-line"></i> Dashboard</h2>
                    <span class="text-muted">Welcome, <?php echo htmlspecialchars($userName); ?>!</span>
                </div>
                <hr>
            </div>
        </div>

        <!-- ========================================================== -->
        <!-- STATS CARDS (7 Cards)                                      -->
        <!-- ========================================================== -->
        <div class="row g-1" id="dashboardStats">
            <div class="col-xl-2 col-md-4 mb-2">
                <a href="materials.php" class="stat-card-link">
                    <div class="card border-left-primary shadow h-100 py-1">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-primary text-uppercase"><i class="fas fa-mobile-alt"></i> Total Models</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalModels">Loading...</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-md-4 mb-2">
                <a href="brands.php" class="stat-card-link">
                    <div class="card border-left-info shadow h-100 py-1">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-info text-uppercase"><i class="fas fa-tag"></i> Total Brands</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalBrands">Loading...</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-md-4 mb-2">
                <a href="low_stock.php" class="stat-card-link">
                    <div class="card border-left-danger shadow h-100 py-1">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-danger text-uppercase"><i class="fas fa-exclamation-triangle"></i> Low Stock</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="lowStock">Loading...</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-md-4 mb-2">
                <a href="stock_in.php" class="stat-card-link">
                    <div class="card border-left-success shadow h-100 py-1">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-success text-uppercase"><i class="fas fa-arrow-down"></i> Stock In (Month)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="stockInMonth">Loading...</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-md-4 mb-2">
                <a href="stock_out.php" class="stat-card-link">
                    <div class="card border-left-warning shadow h-100 py-1">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-warning text-uppercase"><i class="fas fa-arrow-up"></i> Stock Out (Month)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="stockOutMonth">Loading...</div>
                        </div>
                    </div>
                </a>
            </div>
            <?php if ($role === 'admin' || $role === 'manager'): ?>
            <div class="col-xl-2 col-md-4 mb-2">
                <a href="pages/approvals.php" class="stat-card-link">
                    <div class="card border-left-warning shadow h-100 py-1" style="border-left-color: #f6c23e !important;">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-warning text-uppercase"><i class="fas fa-clock"></i> Pending Requests</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="pendingCount">Loading...</div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- ========================================================== -->
        <!-- LOW STOCK ALERT BAR (if any)                               -->
        <!-- ========================================================== -->
        <div id="lowStockAlert" style="display:none;" class="row g-1 mt-1">
            <div class="col-md-12">
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong><i class="fas fa-exclamation-triangle"></i> Low Stock Alert!</strong>
                    <span id="lowStockList">Loading...</span>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </div>
        </div>

        <!-- ========================================================== -->
        <!-- CHARTS: PIE + LINE                                        -->
        <!-- ========================================================== -->
        <div class="row g-1 mt-1" id="chartRow">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-light py-1">
                        <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-chart-pie"></i> Stock by Category</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-container"><canvas id="dashboardPieChart"></canvas></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-light py-1">
                        <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-chart-line"></i> Daily Stock Movement</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-container"><canvas id="dashboardLineChart"></canvas></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ========================================================== -->
        <!-- QUICK ACTIONS (Role-Specific, Disabled)                    -->
        <!-- ========================================================== -->
        <div class="row g-1 mt-1">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header py-1">
                        <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-tasks"></i> Quick Actions</h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-1">
                            <?php if ($role === 'admin'): ?>
                                <div class="col-6 col-md-3"><span class="btn btn-info w-100 py-2 btn-disabled">Add Device</span></div>
                                <div class="col-6 col-md-3"><span class="btn btn-primary w-100 py-2 btn-disabled">Manage Users</span></div>
                            <?php elseif ($role === 'manager'): ?>
                                <div class="col-6 col-md-3"><span class="btn btn-primary w-100 py-2 btn-disabled">Approve Requests</span></div>
                                <div class="col-6 col-md-3"><span class="btn btn-secondary w-100 py-2 btn-disabled">Reports</span></div>
                            <?php elseif ($role === 'employee'): ?>
                                <div class="col-6 col-md-3"><span class="btn btn-info w-100 py-2 btn-disabled">Request Stock</span></div>
                            <?php endif; ?>
                            <?php if ($role === 'store_keeper'): ?>
                                <div class="col-6 col-md-3"><span class="btn btn-success w-100 py-2 btn-disabled">Receive Stock</span></div>
                                <div class="col-6 col-md-3"><span class="btn btn-warning w-100 py-2 btn-disabled">Issue Stock</span></div>
                            <?php endif; ?>
                            <?php if ($role === 'employee'): ?>
<div class="row mt-3">
    <div class="col-md-12">
        <div class="card shadow">
            <div class="card-header bg-info text-white">
                <h5><i class="fas fa-user"></i> Employee Dashboard</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <a href="pages/stock_out.php" class="btn btn-primary w-100 py-3">
                            <i class="fas fa-paper-plane fa-2x d-block"></i>
                            Request Materials
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="pages/transactions.php" class="btn btn-info w-100 py-3">
                            <i class="fas fa-history fa-2x d-block"></i>
                            My Requests
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       <?php if ($role === 'admin' || $role === 'manager'): ?>
<div id="pendingAlert" class="row mt-1" style="display:none;">
    <div class="col-md-12">
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong><i class="fas fa-clock"></i> Pending Requests!</strong>
            You have <span id="pendingCountAlert">0</span> pending stock_out requests awaiting your approval.
            <a href="pages/approvals.php" class="btn btn-sm btn-primary ms-3">Review Now</a>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if ($role === 'store_keeper'): ?>
<div id="approvedAlert" class="row mt-1" style="display:none;">
    <div class="col-md-12">
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <strong><i class="fas fa-check-circle"></i> Approved Requests!</strong>
            You have <span id="approvedCountAlert">0</span> approved requests ready for fulfillment.
            <a href="pages/fulfill_requests.php" class="btn btn-sm btn-primary ms-3">Fulfill Now</a>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
</div>
<?php endif; ?>
                    <div class="card-body" style="overflow: visible !important;">
                        <div class="table-responsive">
                            <table class="table table-hover table-sm mb-0">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Model</th>
                                        <th>Qty</th>
                                        <th>Department</th>
                                        <th>Requested By</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="pendingRequestsBody">
                                    <tr><td colspan="6" class="text-center">Loading...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

        <!-- ========================================================== -->
        <!-- RECENT TRANSACTIONS (All Roles)                            -->
        <!-- ========================================================== -->
        <div class="row g-1 mt-1">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header py-1">
                        <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-history"></i> Recent Transactions</h6>
                    </div>
                    <div class="card-body" style="overflow: visible !important;">
                        <div class="table-responsive">
                            <table class="table table-hover table-sm mb-0">
                                <thead>
                                    <tr><th>Date</th><th>Type</th><th>Model</th><th>Quantity</th><th>Status</th></tr>
                                </thead>
                                <tbody id="recentTransactions">
                                    <tr><td colspan="5" class="text-center">Loading...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    let pieChart = null, lineChart = null;

    $(document).ready(function() {
        loadDashboardStats();
        loadCharts();
        loadRecentTransactions();
        <?php if ($role === 'admin' || $role === 'manager'): ?>
        loadPendingRequests();
        <?php endif; ?>
        // Refresh every 30 seconds
        setInterval(function() {
            loadDashboardStats();
            <?php if ($role === 'admin' || $role === 'manager'): ?>
            loadPendingRequests();
            <?php endif; ?>
        }, 30000);
    });

    function loadDashboardStats() {
        $.ajax({
            url: '../api/dashboard.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                $('#totalModels').text(data.total_models || 0);
                $('#totalBrands').text(data.total_brands || 0);
                $('#lowStock').text(data.low_stock || 0);
                $('#stockInMonth').text(data.stock_in_month || 0);
                $('#stockOutMonth').text(data.stock_out_month || 0);
                $('#pendingCount').text(data.pending_count || 0);
                $('#pendingBadge').text(data.pending_count || 0);
                
                // Low Stock Alert
                if (data.low_stock && data.low_stock > 0) {
                    $('#lowStockAlert').show();
                    $('#lowStockList').text(data.low_stock_list || 'Some items are low in stock.');
                } else {
                    $('#lowStockAlert').hide();
                }
            },
            error: function() {
                $('#totalModels').text('Error');
                $('#totalBrands').text('Error');
                $('#lowStock').text('Error');
                $('#stockInMonth').text('Error');
                $('#stockOutMonth').text('Error');
                $('#pendingCount').text('Error');
            }
        });
    }

    function loadPendingRequests() {
        $.ajax({
            url: '../api/dashboard.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                let html = '';
                if (data.pending_requests && data.pending_requests.length > 0) {
                    data.pending_requests.forEach(function(req) {
                        const date = req.transaction_date ? new Date(req.transaction_date) : null;
                        const dateStr = date ? date.toLocaleDateString() + ' ' + date.toLocaleTimeString() : 'N/A';
                        html += `<tr>
                            <td>${dateStr}</td>
                            <td>${req.model_name || 'N/A'}</td>
                            <td>${req.quantity}</td>
                            <td>${req.department || '-'}</td>
                            <td>${req.requested_by || '-'}</td>
                            <td>
                                <a href="pages/approvals.php" class="btn btn-sm btn-primary">
                                    <i class="fas fa-arrow-right"></i> Review
                                </a>
                            </td>
                        </tr>`;
                    });
                } else {
                    html = '<tr><td colspan="6" class="text-center text-muted">No pending requests</td></tr>';
                }
                $('#pendingRequestsBody').html(html);
            },
            error: function() {
                $('#pendingRequestsBody').html('<tr><td colspan="6" class="text-center text-danger">Failed to load</td></tr>');
            }
        });
    }

    function loadCharts() {
        $.ajax({
            url: '../api/dashboard.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                renderPieChart(data);
                renderLineChart(data);
            },
            error: function() { console.log('Chart data not available'); }
        });
    }

    function renderPieChart(data) {
        if (pieChart) { pieChart.destroy(); pieChart = null; }
        if (!data.stock_by_category || data.stock_by_category.labels.length === 0) {
            document.getElementById('dashboardPieChart').getContext('2d').clearRect(0, 0, 100, 100);
            return;
        }
        const ctx = document.getElementById('dashboardPieChart').getContext('2d');
        pieChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: data.stock_by_category.labels,
                datasets: [{
                    data: data.stock_by_category.data,
                    backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { font: { size: 10 } } } }
            }
        });
    }

    function renderLineChart(data) {
        if (lineChart) { lineChart.destroy(); lineChart = null; }
        const movement = (data.daily_movement && data.daily_movement.labels.length > 0) 
            ? data.daily_movement 
            : data.monthly_movement;
        if (!movement || movement.labels.length === 0) {
            document.getElementById('dashboardLineChart').getContext('2d').clearRect(0, 0, 100, 100);
            return;
        }
        const ctx = document.getElementById('dashboardLineChart').getContext('2d');
        lineChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: movement.labels,
                datasets: [
                    {
                        label: 'Stock In',
                        data: movement.in,
                        borderColor: '#1cc88a',
                        backgroundColor: 'rgba(28,200,138,0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 3
                    },
                    {
                        label: 'Stock Out',
                        data: movement.out,
                        borderColor: '#f6c23e',
                        backgroundColor: 'rgba(246,194,62,0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'top', labels: { font: { size: 10 } } } },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    function loadRecentTransactions() {
        $.ajax({
            url: '../api/dashboard.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                let html = '';
                if (data.recent_transactions && data.recent_transactions.length > 0) {
                    data.recent_transactions.forEach(function(tx) {
                        const statusBadge = getStatusBadge(tx.status);
                        const date = tx.transaction_date ? new Date(tx.transaction_date) : null;
                        const dateStr = date ? date.toLocaleDateString() + ' ' + date.toLocaleTimeString() : 'N/A';
                        html += `<tr>
                            <td>${dateStr}</td>
                            <td><span class="badge bg-${tx.transaction_type === 'IN' ? 'success' : 'warning'}">${tx.transaction_type}</span></td>
                            <td>${tx.model_name || 'N/A'}</td>
                            <td>${tx.quantity}</td>
                            <td>${statusBadge}</td>
                        </tr>`;
                    });
                } else {
                    html = '<tr><td colspan="5" class="text-center text-muted">No recent transactions</td></tr>';
                }
                $('#recentTransactions').html(html);
            }
        });
    }

    function getStatusBadge(status) {
        const badges = {
            'PENDING': '<span class="badge bg-warning">Pending</span>',
            'APPROVED': '<span class="badge bg-success">Approved</span>',
            'REJECTED': '<span class="badge bg-danger">Rejected</span>',
            'COMPLETED': '<span class="badge bg-info">Completed</span>'
        };
        return badges[status] || '<span class="badge bg-secondary">Unknown</span>';
    }
    </script>
</body>
</html>