<?php
require_once '../config/config.php';
requireLogin();

// Only Admin and Manager can manage suppliers (Admin has full, Manager can view/add/edit)
if (!hasRole('admin') && !hasRole('manager')) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Suppliers - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h2><i class="fas fa-truck"></i> Suppliers</h2>
            <button class="btn btn-primary" onclick="openAddModal()">
                <i class="fas fa-plus-circle"></i> Add Supplier
            </button>
        </div>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="suppliersBody">
                            <tr><td colspan="8" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Supplier Modal -->
    <div class="modal fade" id="supplierModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle"><i class="fas fa-truck"></i> Add Supplier</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="supplierForm" autocomplete="off">
                        <input type="hidden" id="supplierId" value="0">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Code</label>
                                    <input type="text" class="form-control" id="supplierCode" placeholder="e.g., SUP-001">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Name *</label>
                                    <input type="text" class="form-control" id="supplierName" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Contact Person</label>
                                    <input type="text" class="form-control" id="supplierContact">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" id="supplierEmail">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="text" class="form-control" id="supplierPhone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select class="form-control" id="supplierStatus">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea class="form-control" id="supplierAddress" rows="2"></textarea>
                        </div>
                        <div id="supplierAlert"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveSupplierBtn">
                        <i class="fas fa-save"></i> Save Supplier
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(function() {
        loadSuppliers();

        // Open Add Modal
        window.openAddModal = function() {
            resetForm();
            $('#modalTitle').html('<i class="fas fa-truck"></i> Add Supplier');
            $('#supplierModal').modal('show');
        };

        // Save Supplier
        $('#saveSupplierBtn').on('click', function() {
            const id = $('#supplierId').val();
            const code = $('#supplierCode').val().trim();
            const name = $('#supplierName').val().trim();
            const contact = $('#supplierContact').val().trim();
            const email = $('#supplierEmail').val().trim();
            const phone = $('#supplierPhone').val().trim();
            const address = $('#supplierAddress').val().trim();
            const status = $('#supplierStatus').val();

            if (!name) {
                showAlert('danger', 'Supplier name is required');
                $('#supplierName').focus();
                return;
            }

            const data = {
                action: id > 0 ? 'update' : 'create',
                id: id,
                code: code,
                name: name,
                contact: contact,
                email: email,
                phone: phone,
                address: address,
                status: status
            };

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Saving...').prop('disabled', true);

            $.ajax({
                url: '../api/suppliers.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        setTimeout(function() {
                            $('#supplierModal').modal('hide');
                            loadSuppliers();
                            resetForm();
                        }, 1000);
                    } else {
                        showAlert('danger', res.message);
                    }
                },
                error: function() {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error saving supplier');
                }
            });
        });

        // Edit Supplier
        $(document).on('click', '.edit-supplier', function() {
            const id = $(this).data('id');
            $.ajax({
                url: '../api/suppliers.php',
                type: 'GET',
                data: { id: id },
                dataType: 'json',
                success: function(res) {
                    if (res.success && res.data) {
                        const s = res.data;
                        $('#supplierId').val(s.id);
                        $('#supplierCode').val(s.code || '');
                        $('#supplierName').val(s.name);
                        $('#supplierContact').val(s.contact_person || '');
                        $('#supplierEmail').val(s.email || '');
                        $('#supplierPhone').val(s.phone || '');
                        $('#supplierAddress').val(s.address || '');
                        $('#supplierStatus').val(s.status || 'active');
                        $('#modalTitle').html('<i class="fas fa-edit"></i> Edit Supplier');
                        $('#supplierModal').modal('show');
                    } else {
                        alert('Failed to load supplier data');
                    }
                },
                error: function() {
                    alert('Error loading supplier data');
                }
            });
        });

        // Delete Supplier
        $(document).on('click', '.delete-supplier', function() {
            const id = $(this).data('id');
            if (confirm('Delete this supplier?')) {
                $.ajax({
                    url: '../api/suppliers.php',
                    type: 'POST',
                    data: { action: 'delete', id: id },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            showAlert('success', res.message);
                            loadSuppliers();
                        } else {
                            alert(res.message);
                        }
                    },
                    error: function() {
                        alert('Error deleting supplier');
                    }
                });
            }
        });

        // Reset form on modal close
        $('#supplierModal').on('hidden.bs.modal', resetForm);

        function resetForm() {
            $('#supplierId').val('0');
            $('#supplierCode').val('');
            $('#supplierName').val('');
            $('#supplierContact').val('');
            $('#supplierEmail').val('');
            $('#supplierPhone').val('');
            $('#supplierAddress').val('');
            $('#supplierStatus').val('active');
            $('#supplierAlert').html('');
        }

        function loadSuppliers() {
            $.ajax({
                url: '../api/suppliers.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data && res.data.length > 0) {
                        res.data.forEach(function(s) {
                            const statusBadge = s.status === 'active' ?
                                '<span class="badge bg-success">Active</span>' :
                                '<span class="badge bg-danger">Inactive</span>';
                            html += `<tr>
                                <td>${s.id}</td>
                                <td>${s.code || '-'}</td>
                                <td><strong>${s.name}</strong></td>
                                <td>${s.contact_person || '-'}</td>
                                <td>${s.email || '-'}</td>
                                <td>${s.phone || '-'}</td>
                                <td>${statusBadge}</td>
                                <td>
                                    <button class="btn btn-sm btn-warning edit-supplier" data-id="${s.id}" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-supplier" data-id="${s.id}" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = '<tr><td colspan="8" class="text-center">No suppliers found</td></tr>';
                    }
                    $('#suppliersBody').html(html);
                },
                error: function() {
                    $('#suppliersBody').html('<tr><td colspan="8" class="text-center text-danger">Failed to load suppliers</td></tr>');
                }
            });
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#supplierAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#supplierAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }
    });
    </script>
</body>
</html>