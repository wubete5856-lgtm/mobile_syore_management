<?php
require_once '../config/config.php';
requireRole('admin');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Roles - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h2><i class="fas fa-user-tag"></i> Manage Roles</h2>
            <button class="btn btn-primary" onclick="openAddModal()">
                <i class="fas fa-plus-circle"></i> Add Role
            </button>
        </div>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Role</th>
                                <th>Description</th>
                                <th>Permissions</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="rolesBody">
                            <tr><td colspan="5" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit Role Modal -->
    <div class="modal fade" id="roleModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">
                        <i class="fas fa-plus-circle"></i> Add Role
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="roleForm">
                        <input type="hidden" id="roleId" value="0">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Role Name *</label>
                            <input type="text" class="form-control" id="roleName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea class="form-control" id="roleDescription" rows="2"></textarea>
                        </div>
                        <hr>
                        <h6 class="fw-bold">Permissions</h6>
                        <div class="row" id="permissionsContainer">
                            <!-- Checkboxes will be generated here -->
                        </div>
                        <div id="formAlert"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveRoleBtn">
                        <i class="fas fa-save"></i> Save Role
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Permission list (define all available permissions)
    const PERMISSIONS = [
        'manage_users',
        'manage_roles',
        'system_settings',
        'backup_restore',
        'view_audit',
        'approve_requests',
        'view_reports',
        'monitor_inventory',
        'manage_suppliers',
        'manage_stock',
        'record_transactions',
        'update_inventory'
    ];

    $(document).ready(function() {
        loadRoles();
        buildPermissionCheckboxes();

        // Open Add Modal
        window.openAddModal = function() {
            resetForm();
            $('#modalTitle').html('<i class="fas fa-plus-circle"></i> Add Role');
            $('#roleModal').modal('show');
        };

        // Save Role
        $('#saveRoleBtn').on('click', function() {
            const id = $('#roleId').val();
            const name = $('#roleName').val().trim();
            const description = $('#roleDescription').val().trim();

            if (!name) {
                showAlert('danger', 'Role name is required');
                $('#roleName').focus();
                return;
            }

            // Gather checked permissions
            const permissions = {};
            PERMISSIONS.forEach(function(p) {
                permissions[p] = $(`#perm_${p}`).prop('checked');
            });

            const data = {
                action: id > 0 ? 'update' : 'create',
                id: id,
                name: name,
                description: description,
                permissions: JSON.stringify(permissions)
            };

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Saving...').prop('disabled', true);

            $.ajax({
                url: '../api/roles.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        setTimeout(function() {
                            $('#roleModal').modal('hide');
                            loadRoles();
                            resetForm();
                        }, 1000);
                    } else {
                        showAlert('danger', res.message);
                    }
                },
                error: function(xhr) {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error: ' + xhr.status + ' - ' + xhr.statusText);
                }
            });
        });

        // Edit Role
        $(document).on('click', '.edit-role', function() {
            const id = $(this).data('id');
            $.ajax({
                url: '../api/roles.php',
                type: 'GET',
                data: { id: id },
                dataType: 'json',
                success: function(res) {
                    if (res.success && res.data) {
                        const r = res.data;
                        $('#roleId').val(r.id);
                        $('#roleName').val(r.role_name);
                        $('#roleDescription').val(r.description || '');

                        // Set permissions checkboxes
                        const perms = JSON.parse(r.permissions || '{}');
                        PERMISSIONS.forEach(function(p) {
                            $(`#perm_${p}`).prop('checked', perms[p] === true);
                        });

                        $('#modalTitle').html('<i class="fas fa-edit"></i> Edit Role');
                        $('#roleModal').modal('show');
                    } else {
                        alert('Failed to load role data');
                    }
                },
                error: function() {
                    alert('Error loading role data');
                }
            });
        });

        // Delete Role
        $(document).on('click', '.delete-role', function() {
            const id = $(this).data('id');
            const name = $(this).data('name');
            if (name === 'admin' || name === 'manager' || name === 'store_keeper') {
                alert('Cannot delete system roles.');
                return;
            }
            if (confirm('Delete role "' + name + '"? This cannot be undone.')) {
                $.ajax({
                    url: '../api/roles.php',
                    type: 'POST',
                    data: { action: 'delete', id: id },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            loadRoles();
                            showAlert('success', res.message);
                        } else {
                            alert(res.message);
                        }
                    },
                    error: function() {
                        alert('Error deleting role');
                    }
                });
            }
        });

        // Build permission checkboxes
        function buildPermissionCheckboxes() {
            let html = '';
            PERMISSIONS.forEach(function(p) {
                const label = p.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                html += `
                    <div class="col-md-4">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="perm_${p}" value="${p}">
                            <label class="form-check-label" for="perm_${p}">${label}</label>
                        </div>
                    </div>
                `;
            });
            $('#permissionsContainer').html(html);
        }

        function loadRoles() {
            $.ajax({
                url: '../api/roles.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data.length) {
                        res.data.forEach(function(r) {
                            const perms = JSON.parse(r.permissions || '{}');
                            const permList = Object.keys(perms).filter(k => perms[k] === true).join(', ') || 'None';
                            html += `<tr>
                                <td>${r.id}</td>
                                <td><strong>${r.role_name}</strong></td>
                                <td>${r.description || '-'}</td>
                                <td><small>${permList}</small></td>
                                <td>
                                    <button class="btn btn-sm btn-warning edit-role" data-id="${r.id}" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-role" data-id="${r.id}" data-name="${r.role_name}" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = `<tr><td colspan="5" class="text-center">No roles found</td></tr>`;
                    }
                    $('#rolesBody').html(html);
                },
                error: function() {
                    $('#rolesBody').html('<tr><td colspan="5" class="text-center text-danger">Failed to load roles</td></tr>');
                }
            });
        }

        function resetForm() {
            $('#roleId').val('0');
            $('#roleName').val('');
            $('#roleDescription').val('');
            PERMISSIONS.forEach(function(p) {
                $(`#perm_${p}`).prop('checked', false);
            });
            $('#formAlert').html('');
            $('#modalTitle').html('<i class="fas fa-plus-circle"></i> Add Role');
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#formAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#formAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }

        // Reset on modal close
        $('#roleModal').on('hidden.bs.modal', resetForm);
    });
    </script>
</body>
</html>