<?php require_once '../config/config.php'; requireLogin(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Transaction History - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-history"></i> Transaction History</h2>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Model</th>
                                <th>Qty</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>User</th>
                            </tr>
                        </thead>
                        <tbody id="txBody"><tr><td colspan="8" class="text-center">Loading...</td></tr></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        $.get('../api/transactions.php', function(data) {
            let html = '';
            if (data.success && data.data.length) {
                data.data.forEach(tx => {
                    const typeClass = tx.transaction_type === 'IN' ? 'success' : 
                                     (tx.transaction_type === 'OUT' ? 'warning' : 
                                     (tx.transaction_type === 'RETURN' ? 'info' : 'secondary'));
                    html += `<tr>
                        <td>${new Date(tx.transaction_date).toLocaleString()}</td>
                        <td><span class="badge bg-${typeClass}">${tx.transaction_type}</span></td>
                        <td>${tx.model_name || 'N/A'}</td>
                        <td>${tx.quantity}</td>
                        <td>$${parseFloat(tx.unit_price).toFixed(2)}</td>
                        <td>$${parseFloat(tx.total_amount).toFixed(2)}</td>
                        <td>${getStatusBadge(tx.status)}</td>
                        <td>${tx.full_name || 'System'}</td>
                    </tr>`;
                });
            } else {
                html = '<tr><td colspan="8" class="text-center">No transactions found</td></tr>';
            }
            $('#txBody').html(html);
        }, 'json');
    });
    function getStatusBadge(status) {
        const map = {
            'PENDING': '<span class="badge bg-warning">Pending</span>',
            'APPROVED': '<span class="badge bg-success">Approved</span>',
            'REJECTED': '<span class="badge bg-danger">Rejected</span>',
            'COMPLETED': '<span class="badge bg-info">Completed</span>'
        };
        return map[status] || '<span class="badge bg-secondary">Unknown</span>';
    }
    </script>
</body>
</html>