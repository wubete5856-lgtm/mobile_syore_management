<?php
require_once '../config/config.php';
requireRole('admin');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Backup & Restore - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .backup-card { transition: transform 0.2s; cursor: pointer; }
        .backup-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.15); }
        .backup-icon { font-size: 3rem; opacity: 0.7; }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-database text-primary"></i> Backup & Restore</h2>
        <hr>

        <div class="row">
            <!-- Create Backup Card -->
            <div class="col-md-4 mb-4">
                <div class="card backup-card shadow h-100">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-cloud-upload-alt backup-icon text-success"></i>
                        <h5 class="mt-3">Create Backup</h5>
                        <p class="text-muted small">Create a full database backup</p>
                        <button class="btn btn-success" id="createBackupBtn">
                            <i class="fas fa-plus-circle"></i> Create Backup Now
                        </button>
                    </div>
                </div>
            </div>

            <!-- Restore Info Card -->
            <div class="col-md-4 mb-4">
                <div class="card backup-card shadow h-100">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-undo-alt backup-icon text-warning"></i>
                        <h5 class="mt-3">Restore Backup</h5>
                        <p class="text-muted small">Restore from a previous backup</p>
                        <p class="small text-muted">Select a backup file from the list below</p>
                    </div>
                </div>
            </div>

            <!-- Info Card -->
            <div class="col-md-4 mb-4">
                <div class="card backup-card shadow h-100">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-info-circle backup-icon text-primary"></i>
                        <h5 class="mt-3">Backup Info</h5>
                        <p class="text-muted small">Backups are stored in the /backups folder</p>
                        <p class="small text-muted">Each backup contains your entire database</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Backup List -->
        <div class="card shadow mt-3">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-list"></i> Available Backups</h5>
            </div>
            <div class="card-body">
                <div id="backupAlert"></div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Filename</th>
                                <th>Size</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="backupList">
                            <tr><td colspan="5" class="text-center">Loading backups...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        loadBackups();

        $('#createBackupBtn').on('click', function() {
            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Creating...').prop('disabled', true);

            $.ajax({
                url: '../api/backup.php',
                type: 'POST',
                data: { action: 'create' },
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        loadBackups();
                    } else {
                        showAlert('danger', res.message);
                    }
                },
                error: function(xhr) {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error: ' + xhr.status + ' - ' + xhr.statusText);
                }
            });
        });

        $(document).on('click', '.restore-btn', function() {
            const filename = $(this).data('file');
            if (confirm('Restore backup "' + filename + '"? This will overwrite your current database!')) {
                if (confirm('Are you absolutely sure? This cannot be undone!')) {
                    $.ajax({
                        url: '../api/backup.php',
                        type: 'POST',
                        data: { action: 'restore', filename: filename },
                        dataType: 'json',
                        success: function(res) {
                            if (res.success) {
                                showAlert('success', res.message);
                                loadBackups();
                            } else {
                                showAlert('danger', res.message);
                            }
                        },
                        error: function() {
                            showAlert('danger', 'Error restoring backup');
                        }
                    });
                }
            }
        });

        $(document).on('click', '.delete-backup-btn', function() {
            const filename = $(this).data('file');
            if (confirm('Delete backup "' + filename + '"? This cannot be undone.')) {
                $.ajax({
                    url: '../api/backup.php',
                    type: 'POST',
                    data: { action: 'delete', filename: filename },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            showAlert('success', res.message);
                            loadBackups();
                        } else {
                            showAlert('danger', res.message);
                        }
                    },
                    error: function() {
                        showAlert('danger', 'Error deleting backup');
                    }
                });
            }
        });

        $(document).on('click', '.download-btn', function() {
            const filename = $(this).data('file');
            window.location.href = '../api/backup.php?action=download&filename=' + encodeURIComponent(filename);
        });

        function loadBackups() {
            $.ajax({
                url: '../api/backup.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data && res.data.length > 0) {
                        res.data.forEach(function(b, index) {
                            const size = (b.size / 1024).toFixed(2) + ' KB';
                            const date = new Date(b.created).toLocaleString();
                            html += `<tr>
                                <td>${index + 1}</td>
                                <td><strong>${b.filename}</strong></td>
                                <td>${size}</td>
                                <td>${date}</td>
                                <td>
                                    <button class="btn btn-sm btn-success restore-btn" data-file="${b.filename}" title="Restore">
                                        <i class="fas fa-undo"></i>
                                    </button>
                                    <button class="btn btn-sm btn-info download-btn" data-file="${b.filename}" title="Download">
                                        <i class="fas fa-download"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-backup-btn" data-file="${b.filename}" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = '<tr><td colspan="5" class="text-center text-muted">No backups found. Click "Create Backup" to create one.</td></tr>';
                    }
                    $('#backupList').html(html);
                },
                error: function() {
                    $('#backupList').html('<tr><td colspan="5" class="text-center text-danger">Failed to load backups</td></tr>');
                }
            });
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#backupAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#backupAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }
    });
    </script>
</body>
</html>