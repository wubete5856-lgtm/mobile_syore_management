<?php
require_once '../config/config.php';
requireLogin();

// Only Admin and Manager can access this page
if (!hasRole('admin') && !hasRole('manager')) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Low Stock Alerts - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-exclamation-triangle text-warning"></i> Low Stock Alerts</h2>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Current Stock</th>
                                <th>Reorder Point</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="lowBody">
                            <tr><td colspan="7" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        $.ajax({
            url: '../api/low_stock.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                let html = '';
                if (data.success && data.data.length) {
                    data.data.forEach(function(m) {
                        const status = m.current_stock <= 0 ? 'danger' : 'warning';
                        const statusText = m.current_stock <= 0 ? 'Out of Stock' : 'Low Stock';
                        html += `<tr class="table-${status}">
                            <td><strong>${m.code}</strong></td>
                            <td>${m.name}</td>
                            <td>${m.category_name || '-'}</td>
                            <td><strong>${m.current_stock}</strong></td>
                            <td>${m.reorder_point}</td>
                            <td><span class="badge bg-${status}">${statusText}</span></td>
                            <td>
                                <a href="stock_in.php" class="btn btn-sm btn-success">
                                    <i class="fas fa-plus"></i> Restock
                                </a>
                            </td>
                        </tr>`;
                    });
                } else {
                    html = `<tr>
                        <td colspan="7" class="text-center text-success">
                            <i class="fas fa-check-circle"></i> All items are well stocked!
                        </td>
                    </tr>`;
                }
                $('#lowBody').html(html);
            },
            error: function(xhr) {
                $('#lowBody').html(`
                    <tr><td colspan="7" class="text-center text-danger">
                        Failed to load low stock items. Error: ${xhr.status} - ${xhr.statusText}
                    </td></tr>
                `);
            }
        });
    });
    </script>
</body>
</html>