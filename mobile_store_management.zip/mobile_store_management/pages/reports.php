<?php
require_once '../config/config.php';
requireLogin();

if (!hasRole('manager') && !hasRole('store_keeper')) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reports - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-card { transition: transform 0.2s; cursor: pointer; }
        .report-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.15); }
        .report-icon { font-size: 3rem; opacity: 0.7; }
        .chart-container { position: relative; height: 250px; width: 100%; }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-chart-bar text-primary"></i> Reports</h2>
        <hr>

        <div class="row g-4">
            <!-- Stock Report -->
            <div class="col-md-3">
                <div class="card report-card shadow h-100" onclick="generateReport('stock')">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-boxes report-icon text-success"></i>
                        <h5 class="mt-3">Stock Report</h5>
                        <p class="text-muted small">Current inventory levels</p>
                    </div>
                </div>
            </div>
            <!-- Movement Report -->
            <div class="col-md-3">
                <div class="card report-card shadow h-100" onclick="generateReport('movement')">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-exchange-alt report-icon text-primary"></i>
                        <h5 class="mt-3">Movement Report</h5>
                        <p class="text-muted small">Stock in/out history</p>
                    </div>
                </div>
            </div>
            <!-- Supplier Report -->
            <div class="col-md-3">
                <div class="card report-card shadow h-100" onclick="generateReport('supplier')">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-truck report-icon text-warning"></i>
                        <h5 class="mt-3">Supplier Report</h5>
                        <p class="text-muted small">Supplier wise stock</p>
                    </div>
                </div>
            </div>
            <!-- Low Stock Report -->
            <div class="col-md-3">
                <div class="card report-card shadow h-100" onclick="generateReport('low_stock')">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-exclamation-triangle report-icon text-danger"></i>
                        <h5 class="mt-3">Low Stock Report</h5>
                        <p class="text-muted small">Items below reorder level</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Report Output Area -->
        <div class="mt-4" id="reportOutput">
            <div class="card shadow">
                <div class="card-header bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-file-alt"></i> Report Preview</h5>
                        <div>
                            <button class="btn btn-sm btn-success me-2" id="exportPdfBtn" style="display:none;" onclick="exportPDF()">
                                <i class="fas fa-file-pdf"></i> PDF
                            </button>
                            <button class="btn btn-sm btn-info" id="exportCsvBtn" style="display:none;" onclick="exportCSV()">
                                <i class="fas fa-file-csv"></i> CSV
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body" id="reportContent">
                    <p class="text-muted text-center py-5">
                        <i class="fas fa-hand-pointer fa-3x d-block mb-3"></i>
                        Click a report card above to generate a report
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    let currentReportType = '';
    let reportData = [];
    let chartInstance = null;

    function generateReport(type) {
        currentReportType = type;
        $('#reportContent').html('<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">Loading report...</p></div>');
        $('#exportPdfBtn, #exportCsvBtn').hide();

        $.ajax({
            url: '../api/reports.php',
            type: 'GET',
            data: { type: type },
            dataType: 'json',
            success: function(res) {
                if (res.success && res.data) {
                    reportData = res.data;
                    renderReport(type, res.data);
                    renderCharts(type, res.data);
                    $('#exportPdfBtn, #exportCsvBtn').show();
                } else {
                    $('#reportContent').html('<div class="alert alert-danger">' + (res.message || 'Failed to generate report') + '</div>');
                }
            },
            error: function(xhr) {
                $('#reportContent').html('<div class="alert alert-danger">AJAX Error: ' + xhr.status + ' - ' + xhr.statusText + '</div>');
            }
        });
    }

    function renderReport(type, data) {
        let html = '';
        let headers = [];
        let rows = [];

        switch(type) {
            case 'stock':
                headers = ['Code', 'Name', 'Brand', 'Stock', 'Min Stock', 'Unit Price', 'Total Value'];
                rows = data.map(m => [
                    m.code, m.name, m.brand_name || '-', m.current_stock,
                    m.min_stock_level, '$' + parseFloat(m.unit_price).toFixed(2),
                    '$' + (m.current_stock * m.unit_price).toFixed(2)
                ]);
                break;
            case 'movement':
                headers = ['Date', 'Type', 'Model', 'Qty', 'Unit Price', 'Total', 'Status'];
                rows = data.map(t => [
                    new Date(t.transaction_date).toLocaleString(),
                    t.transaction_type, t.model_name || '-', t.quantity,
                    '$' + parseFloat(t.unit_price).toFixed(2),
                    '$' + parseFloat(t.total_amount).toFixed(2),
                    t.status
                ]);
                break;
            case 'supplier':
                headers = ['Supplier', 'Contact', 'Email', 'Total Models', 'Total Value'];
                rows = data.map(s => [
                    s.name, s.contact_person || '-', s.email || '-',
                    s.total_models || 0, '$' + parseFloat(s.total_value || 0).toFixed(2)
                ]);
                break;
            case 'low_stock':
                headers = ['Code', 'Name', 'Brand', 'Stock', 'Reorder Point', 'Status'];
                rows = data.map(m => [
                    m.code, m.name, m.brand_name || '-', m.current_stock,
                    m.reorder_point, m.current_stock <= 0 ? 'Out of Stock' : 'Low'
                ]);
                break;
            default:
                html = '<div class="alert alert-warning">Unknown report type</div>';
                $('#reportContent').html(html);
                return;
        }

        html += '<div class="table-responsive"><table class="table table-striped table-hover" id="reportTable">';
        html += '<thead><tr>';
        headers.forEach(h => html += '<th>' + h + '</th>');
        html += '</tr></thead><tbody>';

        if (rows.length === 0) {
            html += '<tr><td colspan="' + headers.length + '" class="text-center">No data found</td></tr>';
        } else {
            rows.forEach(row => {
                html += '<tr>';
                row.forEach(cell => html += '<td>' + cell + '</td>');
                html += '</tr>';
            });
        }

        html += '</tbody></table></div>';
        $('#reportContent').html(html);
    }

    function renderCharts(type, data) {
        if (chartInstance) { chartInstance.destroy(); chartInstance = null; }

        let chartHtml = '<div class="row mt-4"><div class="col-md-6"><h6>Pie Chart</h6><div class="chart-container"><canvas id="pieChart"></canvas></div></div>';
        chartHtml += '<div class="col-md-6"><h6>Line Chart</h6><div class="chart-container"><canvas id="lineChart"></canvas></div></div></div>';
        $('#reportContent').append(chartHtml);

        let pieData = null, lineData = null;

        switch(type) {
            case 'stock':
                pieData = getPieDataByBrand(data);
                lineData = getLineDataStock(data);
                break;
            case 'movement':
                pieData = getPieDataByTransactionType(data);
                lineData = getLineDataMovement(data);
                break;
            case 'supplier':
                pieData = getPieDataBySupplierValue(data);
                lineData = getLineDataSupplier(data);
                break;
            case 'low_stock':
                pieData = getPieDataLowStock(data);
                lineData = getLineDataLowStock(data);
                break;
            default: return;
        }

        if (pieData) {
            new Chart(document.getElementById('pieChart'), {
                type: 'pie',
                data: pieData,
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
            });
        }
        if (lineData) {
            chartInstance = new Chart(document.getElementById('lineChart'), {
                type: 'line',
                data: lineData,
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }
            });
        }
    }

    // ---- Chart helper functions (same as dashboard) ----
    function getPieDataByBrand(data) {
        const brandMap = {};
        data.forEach(m => { const b = m.brand_name || 'Unknown'; brandMap[b] = (brandMap[b] || 0) + parseInt(m.current_stock); });
        const sorted = Object.entries(brandMap).sort((a, b) => b[1] - a[1]);
        const top = sorted.slice(0, 5);
        const others = sorted.slice(5).reduce((sum, item) => sum + item[1], 0);
        if (others > 0) top.push(['Others', others]);
        return { labels: top.map(item => item[0]), datasets: [{ data: top.map(item => item[1]), backgroundColor: ['#4e73df','#1cc88a','#36b9cc','#f6c23e','#e74a3b','#858796'] }] };
    }

    function getLineDataStock(data) {
        const sorted = data.slice().sort((a, b) => b.current_stock - a.current_stock).slice(0, 10);
        return { labels: sorted.map(m => m.name.length > 20 ? m.name.slice(0,20)+'...' : m.name), datasets: [{ label: 'Current Stock', data: sorted.map(m => m.current_stock), borderColor: '#4e73df', backgroundColor: 'rgba(78,115,223,0.1)', fill: true, tension: 0.4 }] };
    }

    function getPieDataByTransactionType(data) {
        const count = {};
        data.forEach(t => { count[t.transaction_type] = (count[t.transaction_type] || 0) + 1; });
        return { labels: Object.keys(count), datasets: [{ data: Object.values(count), backgroundColor: ['#4e73df','#1cc88a','#f6c23e','#e74a3b','#36b9cc'] }] };
    }

    function getLineDataMovement(data) {
        const dateMap = {};
        data.forEach(t => { const d = new Date(t.transaction_date).toISOString().split('T')[0]; dateMap[d] = (dateMap[d] || 0) + 1; });
        const sortedDates = Object.keys(dateMap).sort();
        return { labels: sortedDates, datasets: [{ label: 'Transactions per Day', data: sortedDates.map(d => dateMap[d]), borderColor: '#36b9cc', backgroundColor: 'rgba(54,185,204,0.1)', fill: true, tension: 0.4 }] };
    }

    function getPieDataBySupplierValue(data) {
        const supplierMap = {};
        data.forEach(s => { supplierMap[s.name] = parseFloat(s.total_value || 0); });
        const sorted = Object.entries(supplierMap).sort((a, b) => b[1] - a[1]).slice(0, 5);
        return { labels: sorted.map(item => item[0]), datasets: [{ data: sorted.map(item => item[1]), backgroundColor: ['#f6c23e','#4e73df','#1cc88a','#e74a3b','#36b9cc'] }] };
    }

    function getLineDataSupplier(data) {
        return { labels: data.map(s => s.name.length > 15 ? s.name.slice(0,15)+'...' : s.name), datasets: [{ label: 'Number of Models', data: data.map(s => s.total_models || 0), borderColor: '#1cc88a', backgroundColor: 'rgba(28,200,138,0.1)', fill: true, tension: 0.4 }] };
    }

    function getPieDataLowStock(data) {
        const low = data.filter(m => m.current_stock <= m.reorder_point).length;
        const ok = data.length - low;
        return { labels: ['Low Stock', 'OK Stock'], datasets: [{ data: [low, ok], backgroundColor: ['#e74a3b','#1cc88a'] }] };
    }

    function getLineDataLowStock(data) {
        const sorted = data.slice().sort((a, b) => a.current_stock - b.current_stock);
        return { labels: sorted.map(m => m.code), datasets: [{ label: 'Current Stock', data: sorted.map(m => m.current_stock), borderColor: '#e74a3b', backgroundColor: 'rgba(231,74,59,0.1)', fill: true, tension: 0.4 }, { label: 'Reorder Point', data: sorted.map(m => m.reorder_point), borderColor: '#f6c23e', borderDash: [5,5], fill: false, tension: 0.4 }] };
    }

    function exportCSV() {
        if (!reportData || reportData.length === 0) { alert('No data to export'); return; }
        let csv = '';
        const headers = $('#reportTable thead th').map(function() { return $(this).text(); }).get();
        csv += headers.join(',') + '\n';
        $('#reportTable tbody tr').each(function() {
            const row = $(this).find('td').map(function() { return '"' + $(this).text().trim() + '"'; }).get();
            csv += row.join(',') + '\n';
        });
        const blob = new Blob([csv], { type: 'text/csv' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = currentReportType + '_report_' + new Date().toISOString().slice(0,10) + '.csv';
        link.click();
        URL.revokeObjectURL(link.href);
    }

    function exportPDF() {
        alert('PDF export requires a library. Download the CSV and convert it.\n\nOr use browser print (Ctrl+P) and "Save as PDF".');
    }
    </script>
</body>
</html>