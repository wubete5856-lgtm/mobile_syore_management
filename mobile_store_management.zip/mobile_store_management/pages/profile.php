<?php
require_once '../config/config.php';
requireLogin();

$userId = $_SESSION['user_id'];
$role = $_SESSION['role'];
$userName = $_SESSION['full_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: white;
            margin: 0 auto 20px;
        }
        .info-label { font-weight: 600; color: #4e73df; width: 120px; display: inline-block; }
        .info-value { color: #333; }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-user-circle text-primary"></i> My Profile</h2>
        <hr>
        
        <div class="row">
            <!-- Left: Profile Info -->
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body text-center py-4">
                        <div class="profile-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <h4 id="display_full_name">Loading...</h4>
                        <p class="text-muted" id="display_role">Loading...</p>
                        <hr>
                        <div class="text-start">
                            <p><span class="info-label">Username:</span> <span class="info-value" id="display_username">-</span></p>
                            <p><span class="info-label">Email:</span> <span class="info-value" id="display_email">-</span></p>
                            <p><span class="info-label">Department:</span> <span class="info-value" id="display_department">-</span></p>
                            <p><span class="info-label">Joined:</span> <span class="info-value" id="display_joined">-</span></p>
                            <p><span class="info-label">Last Login:</span> <span class="info-value" id="display_lastlogin">-</span></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right: Edit Profile Form -->
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-edit"></i> Edit Profile</h5>
                    </div>
                    <div class="card-body">
                        <div id="profileAlert"></div>
                        <form id="profileForm" autocomplete="off">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                                            <input type="text" class="form-control" id="full_name" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Email</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                            <input type="email" class="form-control" id="email">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Department</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-building"></i></span>
                                    <input type="text" class="form-control" id="department" placeholder="e.g., IT, HR, Store">
                                </div>
                            </div>
                            <hr>
                            <h6><i class="fas fa-lock"></i> Change Password (optional)</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">New Password</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-key"></i></span>
                                            <input type="password" class="form-control" id="new_password" placeholder="Leave blank to keep current">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Confirm Password</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-check-circle"></i></span>
                                            <input type="password" class="form-control" id="confirm_password" placeholder="Confirm new password">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" id="updateProfileBtn">
                                <i class="fas fa-save"></i> Update Profile
                            </button>
                            <button type="reset" class="btn btn-secondary" id="resetFormBtn">
                                <i class="fas fa-undo"></i> Reset
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        // Load profile data on page load
        loadProfile();

        // ========== RESET BUTTON ==========
        $('#resetFormBtn').on('click', function(e) {
            e.preventDefault();
            // Reset form fields to their original values (from loaded profile)
            loadProfile();
            $('#profileAlert').html('');
            $('#new_password').val('');
            $('#confirm_password').val('');
            showAlert('info', 'Form has been reset to your current profile data.');
        });

        // ========== UPDATE PROFILE ==========
        $('#profileForm').on('submit', function(e) {
            e.preventDefault();
            
            const full_name = $('#full_name').val().trim();
            const email = $('#email').val().trim();
            const department = $('#department').val().trim();
            const new_password = $('#new_password').val();
            const confirm_password = $('#confirm_password').val();

            // Validate
            if (!full_name) {
                showAlert('danger', 'Full name is required!');
                $('#full_name').focus();
                return;
            }

            if (new_password && new_password.length < 6) {
                showAlert('danger', 'Password must be at least 6 characters!');
                $('#new_password').focus();
                return;
            }

            if (new_password && new_password !== confirm_password) {
                showAlert('danger', 'Passwords do not match!');
                $('#confirm_password').focus();
                return;
            }

            // Prepare data
            const data = {
                full_name: full_name,
                email: email,
                department: department,
                new_password: new_password || ''
            };

            // Disable button
            const $btn = $('#updateProfileBtn');
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Updating...').prop('disabled', true);

            // Send AJAX
            $.ajax({
                url: '../api/profile.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                timeout: 10000,
                success: function(response) {
                    $btn.html(originalText).prop('disabled', false);
                    if (response.success) {
                        showAlert('success', response.message || 'Profile updated successfully!');
                        // Update displayed name in navbar
                        loadProfile();
                        $('#new_password').val('');
                        $('#confirm_password').val('');
                        // Update session name in navbar (refresh page)
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAlert('danger', response.message || 'Failed to update profile');
                    }
                },
                error: function(xhr, status, error) {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error: ' + status + ' - ' + error);
                }
            });
        });

        // ========== LOAD PROFILE ==========
        function loadProfile() {
            $.ajax({
                url: '../api/profile.php',
                type: 'GET',
                dataType: 'json',
                timeout: 10000,
                success: function(response) {
                    if (response.success && response.data) {
                        const u = response.data;
                        $('#display_full_name').text(u.full_name || 'N/A');
                        $('#display_role').text(u.role || 'N/A');
                        $('#display_username').text(u.username || 'N/A');
                        $('#display_email').text(u.email || 'N/A');
                        $('#display_department').text(u.department || 'N/A');
                        $('#display_joined').text(u.created_at ? new Date(u.created_at).toLocaleDateString() : 'N/A');
                        $('#display_lastlogin').text(u.last_login ? new Date(u.last_login).toLocaleString() : 'Never');
                        
                        // Fill form fields
                        $('#full_name').val(u.full_name || '');
                        $('#email').val(u.email || '');
                        $('#department').val(u.department || '');
                        $('#new_password').val('');
                        $('#confirm_password').val('');
                    } else {
                        showAlert('danger', 'Failed to load profile data');
                    }
                },
                error: function(xhr, status, error) {
                    showAlert('danger', 'Failed to load profile. Please refresh the page.');
                }
            });
        }

        // ========== SHOW ALERT ==========
        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : (type === 'info' ? 'alert-info' : 'alert-danger');
            $('#profileAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#profileAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }
    });
    </script>
</body>
</html>