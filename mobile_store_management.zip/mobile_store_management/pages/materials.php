<?php
require_once '../config/config.php';
requireLogin();

$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mobile Models - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h2><i class="fas fa-mobile-alt"></i> Mobile Models</h2>
            <?php if ($role === 'admin'): ?>
            <button class="btn btn-primary" onclick="openAddModal()">
                <i class="fas fa-plus-circle"></i> Add Model
            </button>
            <?php endif; ?>
        </div>
        <hr>
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Supplier</th>
                                <th>Stock</th>
                                <th>Price</th>
                                <th>Status</th>
                                <?php if ($role === 'admin'): ?>
                                <th>Actions</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody id="modelsBody">
                            <tr><td colspan="<?php echo ($role === 'admin') ? 8 : 7; ?>" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php if ($role === 'admin'): ?>
    <!-- Add/Edit Modal (Admin only) -->
    <div class="modal fade" id="modelModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle"><i class="fas fa-mobile-alt"></i> Add Mobile Model</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="modelForm">
                        <input type="hidden" id="modelId" value="0">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label>Code *</label>
                                    <input type="text" class="form-control" id="modelCode" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label>Name *</label>
                                    <input type="text" class="form-control" id="modelName" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label>Description</label>
                            <textarea class="form-control" id="modelDesc" rows="2"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label>Category *</label>
                                    <select class="form-control" id="modelCategory" required></select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label>Supplier</label>
                                    <select class="form-control" id="modelSupplier"></select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label>Unit</label>
                                    <input type="text" class="form-control" id="modelUnit" value="Pcs">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label>Price ($)</label>
                                    <input type="number" step="0.01" class="form-control" id="modelPrice">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label>Reorder Point</label>
                                    <input type="number" class="form-control" id="modelReorder" value="10">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label>Status</label>
                                    <select class="form-control" id="modelStatus">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label>Location</label>
                                    <input type="text" class="form-control" id="modelLocation">
                                </div>
                            </div>
                        </div>
                        <div id="modelAlert"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveModelBtn">
                        <i class="fas fa-save"></i> Save Model
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    <?php if ($role === 'admin'): ?>
    // ===== ADMIN: FULL CRUD =====
    $(function() {
        loadModels();
        loadCategories();
        loadSuppliers();

        window.openAddModal = function() {
            resetForm();
            $('#modalTitle').html('<i class="fas fa-mobile-alt"></i> Add Mobile Model');
            $('#modelModal').modal('show');
        };

        $('#saveModelBtn').click(function() {
            const id = $('#modelId').val();
            const code = $('#modelCode').val().trim();
            const name = $('#modelName').val().trim();
            const category = $('#modelCategory').val();
            const supplier = $('#modelSupplier').val();

            if (!code || !name || !category) {
                showAlert('danger', 'Code, Name, and Category are required');
                return;
            }

            const data = {
                action: id > 0 ? 'update' : 'create',
                id: id,
                code: code,
                name: name,
                description: $('#modelDesc').val().trim(),
                category_id: category,
                supplier_id: supplier || '',
                unit: $('#modelUnit').val().trim(),
                unit_price: $('#modelPrice').val(),
                reorder_point: $('#modelReorder').val(),
                status: $('#modelStatus').val(),
                location: $('#modelLocation').val().trim()
            };

            const $btn = $(this);
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Saving...').prop('disabled', true);

            $.ajax({
                url: '../api/materials.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        setTimeout(function() {
                            $('#modelModal').modal('hide');
                            loadModels();
                            resetForm();
                        }, 1000);
                    } else {
                        showAlert('danger', res.message);
                    }
                },
                error: function() {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error saving model');
                }
            });
        });

        $(document).on('click', '.edit-model', function() {
            const id = $(this).data('id');
            $.ajax({
                url: '../api/materials.php',
                type: 'GET',
                data: { id: id },
                dataType: 'json',
                success: function(res) {
                    if (res.success && res.data) {
                        const m = res.data;
                        $('#modelId').val(m.id);
                        $('#modelCode').val(m.code);
                        $('#modelName').val(m.name);
                        $('#modelDesc').val(m.description || '');
                        $('#modelCategory').val(m.category_id || '');
                        $('#modelSupplier').val(m.supplier_id || '');
                        $('#modelUnit').val(m.unit || 'Pcs');
                        $('#modelPrice').val(m.unit_price);
                        $('#modelReorder').val(m.reorder_point || 10);
                        $('#modelStatus').val(m.status || 'active');
                        $('#modelLocation').val(m.location || '');
                        $('#modalTitle').html('<i class="fas fa-edit"></i> Edit Mobile Model');
                        $('#modelModal').modal('show');
                    } else {
                        alert('Failed to load model data');
                    }
                },
                error: function() {
                    alert('Error loading model data');
                }
            });
        });

        $(document).on('click', '.delete-model', function() {
            const id = $(this).data('id');
            if (confirm('Delete this model?')) {
                $.ajax({
                    url: '../api/materials.php',
                    type: 'POST',
                    data: { action: 'delete', id: id },
                    dataType: 'json',
                    success: function(res) {
                        if (res.success) {
                            showAlert('success', res.message);
                            loadModels();
                        } else {
                            alert(res.message);
                        }
                    },
                    error: function() {
                        alert('Error deleting model');
                    }
                });
            }
        });

        $('#modelModal').on('hidden.bs.modal', resetForm);

        function resetForm() {
            $('#modelId').val('0');
            $('#modelCode').val('');
            $('#modelName').val('');
            $('#modelDesc').val('');
            $('#modelCategory').val('');
            $('#modelSupplier').val('');
            $('#modelUnit').val('Pcs');
            $('#modelPrice').val('');
            $('#modelReorder').val('10');
            $('#modelStatus').val('active');
            $('#modelLocation').val('');
            $('#modelAlert').html('');
            $('#modalTitle').html('<i class="fas fa-mobile-alt"></i> Add Mobile Model');
        }

        function loadCategories() {
            $.ajax({
                url: '../api/categories.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let opts = '<option value="">Select Category</option>';
                    if (res.success) {
                        res.data.forEach(function(c) {
                            opts += `<option value="${c.id}">${c.name}</option>`;
                        });
                    }
                    $('#modelCategory').html(opts);
                },
                error: function() {
                    $('#modelCategory').html('<option value="">Error loading categories</option>');
                }
            });
        }

        function loadSuppliers() {
            $.ajax({
                url: '../api/suppliers.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let opts = '<option value="">Select Supplier</option>';
                    if (res.success) {
                        res.data.forEach(function(s) {
                            opts += `<option value="${s.id}">${s.name}</option>`;
                        });
                    }
                    $('#modelSupplier').html(opts);
                },
                error: function() {
                    $('#modelSupplier').html('<option value="">Error loading suppliers</option>');
                }
            });
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#modelAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(function() {
                $('#modelAlert .alert').fadeOut(500, function() { $(this).remove(); });
            }, 5000);
        }
    });
    <?php else: ?>
    // ===== MANAGER & STOREKEEPER: VIEW ONLY =====
    $(function() {
        loadModels();
    });
    <?php endif; ?>

    // ===== SHARED: LOAD MODELS (for all roles) =====
    function loadModels() {
        $.ajax({
            url: '../api/materials.php',
            type: 'GET',
            dataType: 'json',
            success: function(res) {
                let html = '';
                if (res.success && res.data && res.data.length > 0) {
                    res.data.forEach(function(m) {
                        const statusBadge = m.status === 'active' ?
                            '<span class="badge bg-success">Active</span>' :
                            '<span class="badge bg-danger">Inactive</span>';
                        html += `<tr>
                            <td><strong>${m.code}</strong></td>
                            <td>${m.name}</td>
                            <td>${m.category_name || '-'}</td>
                            <td>${m.supplier_name || '-'}</td>
                            <td>${m.current_stock}</td>
                            <td>$${parseFloat(m.unit_price).toFixed(2)}</td>
                            <td>${statusBadge}</td>`;
                        <?php if ($role === 'admin'): ?>
                        html += `<td>
                            <button class="btn btn-sm btn-warning edit-model" data-id="${m.id}"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-sm btn-danger delete-model" data-id="${m.id}"><i class="fas fa-trash"></i></button>
                        </td>`;
                        <?php endif; ?>
                        html += `</tr>`;
                    });
                } else {
                    const colCount = <?php echo ($role === 'admin') ? 8 : 7; ?>;
                    html = `<tr><td colspan="${colCount}" class="text-center">No models found</td></tr>`;
                }
                $('#modelsBody').html(html);
            },
            error: function() {
                const colCount = <?php echo ($role === 'admin') ? 8 : 7; ?>;
                $('#modelsBody').html(`<tr><td colspan="${colCount}" class="text-center text-danger">Failed to load models</td></tr>`);
            }
        });
    }
    </script>
</body>
</html>