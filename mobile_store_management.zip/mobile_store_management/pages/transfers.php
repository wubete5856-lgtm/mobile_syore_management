<?php
require_once '../config/config.php';
requireLogin();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Material Transfer - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-exchange-alt"></i> Material Transfer</h2>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Transfer Form</h5></div>
                    <div class="card-body">
                        <form id="transferForm">
                            <div class="mb-3">
                                <label>Model *</label>
                                <select class="form-control" id="trModel" required>
                                    <option value="">Loading models...</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Quantity *</label>
                                <input type="number" class="form-control" id="trQty" min="1" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label>From Location *</label>
                                        <input type="text" class="form-control" id="trFrom" placeholder="e.g., Shelf A-1" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label>To Location *</label>
                                        <input type="text" class="form-control" id="trTo" placeholder="e.g., Shelf B-2" required>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label>Notes</label>
                                <textarea class="form-control" id="trNotes" rows="2"></textarea>
                            </div>
                            <div id="trAlert"></div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-exchange-alt"></i> Transfer</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Transfer History</h5></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead><tr><th>Date</th><th>Model</th><th>Qty</th><th>From</th><th>To</th></tr></thead>
                                <tbody id="trHistory">
                                    <tr><td colspan="5" class="text-center">Loading...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadModels();
        loadHistory();

        $('#transferForm').on('submit', function(e) {
            e.preventDefault();

            const model = $('#trModel').val();
            const qty = $('#trQty').val();
            const from = $('#trFrom').val().trim();
            const to = $('#trTo').val().trim();
            const notes = $('#trNotes').val().trim();

            if (!model || !qty || !from || !to) {
                showAlert('danger', 'Please fill all required fields');
                return;
            }

            const data = {
                model_id: model,
                quantity: qty,
                from_location: from,
                to_location: to,
                notes: notes
            };

            const $btn = $(this).find('button[type="submit"]');
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Transferring...').prop('disabled', true);

            $.ajax({
                url: '../api/transfers.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        $('#transferForm')[0].reset();
                        loadHistory();
                    } else {
                        showAlert('danger', res.message || 'Transfer failed');
                    }
                },
                error: function(xhr) {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error: ' + xhr.status + ' - ' + xhr.statusText);
                }
            });
        });

        function loadModels() {
            $.get('../api/materials.php', function(res) {
                let opts = '<option value="">Select Model</option>';
                if (res.success && res.data) {
                    res.data.forEach(m => opts += `<option value="${m.id}">${m.code} - ${m.name}</option>`);
                }
                $('#trModel').html(opts);
            }, 'json');
        }

        function loadHistory() {
            $.ajax({
                url: '../api/transfers.php',
                type: 'GET',
                dataType: 'json',
                success: function(res) {
                    let html = '';
                    if (res.success && res.data && res.data.length) {
                        res.data.forEach(t => {
                            // Format date properly
                            const date = t.transaction_date ? new Date(t.transaction_date) : null;
                            const dateStr = date ? date.toLocaleDateString() + ' ' + date.toLocaleTimeString() : 'N/A';
                            html += `<tr>
                                <td>${dateStr}</td>
                                <td>${t.model_name || ''}</td>
                                <td>${t.quantity}</td>
                                <td>${t.from_location || '-'}</td>
                                <td>${t.to_location || '-'}</td>
                            </tr>`;
                        });
                    } else {
                        html = '<tr><td colspan="5" class="text-center">No transfers</td></tr>';
                    }
                    $('#trHistory').html(html);
                },
                error: function() {
                    $('#trHistory').html('<tr><td colspan="5" class="text-center text-danger">Failed to load history</td></tr>');
                }
            });
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#trAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(() => { $('#trAlert .alert').fadeOut(500, function() { $(this).remove(); }); }, 5000);
        }
    });
    </script>
</body>
</html>