<?php
require_once '../config/config.php';
requireLogin();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receive Stock - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-arrow-down"></i> Receive Stock</h2>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Stock In Form</h5></div>
                    <div class="card-body">
                        <form id="stockInForm">
                            <div class="mb-3">
                                <label>Model *</label>
                                <select class="form-control" id="siModel" required>
                                    <option value="">Loading models...</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Quantity *</label>
                                <input type="number" class="form-control" id="siQty" min="1" required>
                            </div>
                            <div class="mb-3">
                                <label>Unit Price ($) *</label>
                                <input type="number" step="0.01" class="form-control" id="siPrice" required>
                            </div>
                            <div class="mb-3">
                                <label>Supplier</label>
                                <select class="form-control" id="siSupplier">
                                    <option value="">Select Supplier</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Invoice No.</label>
                                <input type="text" class="form-control" id="siInvoice">
                            </div>
                            <div class="mb-3">
                                <label>Notes</label>
                                <textarea class="form-control" id="siNotes" rows="2"></textarea>
                            </div>
                            <div id="siAlert"></div>
                            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Receive Stock</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header"><h5>Recent Stock In</h5></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead><tr><th>Date</th><th>Model</th><th>Qty</th><th>Price</th><th>Supplier</th></tr></thead>
                                <tbody id="stockInHistory">
                                    <tr><td colspan="5" class="text-center">Loading...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadModels();
        loadSuppliers();
        loadHistory();

        $('#stockInForm').on('submit', function(e) {
            e.preventDefault();

            const model = $('#siModel').val();
            const qty = $('#siQty').val();
            const price = $('#siPrice').val();

            if (!model || !qty || !price) {
                showAlert('danger', 'Please fill all required fields');
                return;
            }

            const data = {
                model_id: model,
                quantity: qty,
                unit_price: price,
                supplier_id: $('#siSupplier').val() || '',
                invoice_no: $('#siInvoice').val().trim(),
                notes: $('#siNotes').val().trim()
            };

            const $btn = $(this).find('button[type="submit"]');
            const originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin"></i> Processing...').prop('disabled', true);

            $.ajax({
                url: '../api/stock_in.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(res) {
                    $btn.html(originalText).prop('disabled', false);
                    if (res.success) {
                        showAlert('success', res.message);
                        $('#stockInForm')[0].reset();
                        loadHistory();
                    } else {
                        showAlert('danger', res.message || 'Failed to receive stock');
                    }
                },
                error: function(xhr) {
                    $btn.html(originalText).prop('disabled', false);
                    showAlert('danger', 'Error: ' + xhr.status + ' - ' + xhr.statusText);
                }
            });
        });

        function loadModels() {
            $.get('../api/materials.php', function(res) {
                let opts = '<option value="">Select Model</option>';
                if (res.success && res.data) {
                    res.data.forEach(m => opts += `<option value="${m.id}">${m.code} - ${m.name}</option>`);
                }
                $('#siModel').html(opts);
            }, 'json');
        }

        function loadSuppliers() {
            $.get('../api/suppliers.php', function(res) {
                let opts = '<option value="">Select Supplier</option>';
                if (res.success && res.data) {
                    res.data.forEach(s => opts += `<option value="${s.id}">${s.name}</option>`);
                }
                $('#siSupplier').html(opts);
            }, 'json');
        }

        function loadHistory() {
            $.get('../api/stock_in.php', function(res) {
                let html = '';
                if (res.success && res.data && res.data.length) {
                    res.data.forEach(item => {
                        const date = item.transaction_date ? new Date(item.transaction_date) : null;
                        const dateStr = date ? date.toLocaleDateString() : 'N/A';
                        html += `<tr>
                            <td>${dateStr}</td>
                            <td>${item.model_name || ''}</td>
                            <td>${item.quantity}</td>
                            <td>$${parseFloat(item.unit_price).toFixed(2)}</td>
                            <td>${item.supplier_name || '-'}</td>
                        </tr>`;
                    });
                } else {
                    html = '<tr><td colspan="5" class="text-center">No entries</td></tr>';
                }
                $('#stockInHistory').html(html);
            }, 'json');
        }

        function showAlert(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            $('#siAlert').html(`
                <div class="alert ${alertClass} alert-dismissible fade show">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `);
            setTimeout(() => { $('#siAlert .alert').fadeOut(500, function() { $(this).remove(); }); }, 5000);
        }
    });
    </script>
</body>
</html>