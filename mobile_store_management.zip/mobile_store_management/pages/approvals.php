<?php
require_once '../config/config.php';
requireRole('manager');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Approvals - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-check-double"></i> Approve Requests</h2>
        <hr>
        <div class="card shadow">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-clock"></i> Pending Stock Out Requests</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Model</th>
                                <th>Qty</th>
                                <th>Department</th>
                                <th>Employee</th>
                                <th>Requested By</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="approveBody">
                            <tr><td colspan="7" class="text-center">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        loadPending();
        setInterval(loadPending, 30000);
    });

    function loadPending() {
        $.get('../api/stock_out.php', { status: 'pending' }, function(res) {
            let html = '';
            if (res.success && res.data && res.data.length > 0) {
                res.data.forEach(function(r) {
                    const date = r.transaction_date ? new Date(r.transaction_date) : null;
                    const dateStr = date ? date.toLocaleDateString() + ' ' + date.toLocaleTimeString() : 'N/A';
                    html += `<tr>
                        <td>${dateStr}</td>
                        <td>${r.model_name || ''}</td>
                        <td>${r.quantity}</td>
                        <td>${r.department || ''}</td>
                        <td>${r.employee_name || ''}</td>
                        <td>${r.full_name || ''}</td>
                        <td>
                            <button class="btn btn-sm btn-success approve-btn" data-id="${r.id}">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button class="btn btn-sm btn-danger reject-btn" data-id="${r.id}">
                                <i class="fas fa-times"></i> Reject
                            </button>
                        </td>
                    </tr>`;
                });
            } else {
                html = '<tr><td colspan="7" class="text-center text-muted">No pending requests</td></tr>';
            }
            $('#approveBody').html(html);
        }, 'json');
    }

    $(document).on('click', '.approve-btn', function() {
        const id = $(this).data('id');
        if (confirm('Approve this request?')) {
            $.post('../api/stock_out.php', { action: 'approve', id: id }, function(res) {
                if (res.success) { loadPending(); alert(res.message); } else { alert(res.message); }
            }, 'json');
        }
    });

    $(document).on('click', '.reject-btn', function() {
        const id = $(this).data('id');
        const reason = prompt('Rejection reason:');
        if (reason !== null) {
            $.post('../api/stock_out.php', { action: 'reject', id: id, reason: reason }, function(res) {
                if (res.success) { loadPending(); alert(res.message); } else { alert(res.message); }
            }, 'json');
        }
    });
    </script>
</body>
</html>