-- Backup created on 2026-08-29 04:44:56

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `audit_logs` VALUES ('19','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:16:00');
INSERT INTO `audit_logs` VALUES ('20','1','CREATE_USER','User Management','Created user: alemitu','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:17:21');
INSERT INTO `audit_logs` VALUES ('21','1','CREATE_CATEGORY','Categories','Created category: earphone (ID: 5)','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:22:38');
INSERT INTO `audit_logs` VALUES ('22','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:22:53');
INSERT INTO `audit_logs` VALUES ('23','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:24:59');
INSERT INTO `audit_logs` VALUES ('24','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:02');
INSERT INTO `audit_logs` VALUES ('25','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:04');
INSERT INTO `audit_logs` VALUES ('26','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:04');
INSERT INTO `audit_logs` VALUES ('27','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:05');
INSERT INTO `audit_logs` VALUES ('28','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:05');
INSERT INTO `audit_logs` VALUES ('29','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:06');
INSERT INTO `audit_logs` VALUES ('30','2','STOCK_OUT_APPROVE','Stock','Approved request ID 10','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:22');
INSERT INTO `audit_logs` VALUES ('31','2','STOCK_OUT_APPROVE','Stock','Approved request ID 15','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:32');
INSERT INTO `audit_logs` VALUES ('32','2','STOCK_OUT_APPROVE','Stock','Approved request ID 16','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:25:42');
INSERT INTO `audit_logs` VALUES ('33','2','CREATE_MODEL','Inventory','Created model: TECNO SPARK','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:28:42');
INSERT INTO `audit_logs` VALUES ('34','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:29:37');
INSERT INTO `audit_logs` VALUES ('35','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:29:45');
INSERT INTO `audit_logs` VALUES ('36','3','STOCK_IN','Stock','Received 34 of model ID 3','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:30:27');
INSERT INTO `audit_logs` VALUES ('37','3','STOCK_OUT_REQUEST','Stock','Requested 34 of model ID 2','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:31:05');
INSERT INTO `audit_logs` VALUES ('38','3','STOCK_RETURN','Stock','Returned 2 of model ID 1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:31:44');
INSERT INTO `audit_logs` VALUES ('39','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:34:18');
INSERT INTO `audit_logs` VALUES ('40','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:34:24');
INSERT INTO `audit_logs` VALUES ('41','2','CREATE_SUPPLIER','Suppliers','Created supplier: ZTE distribution','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:35:34');
INSERT INTO `audit_logs` VALUES ('42','2','CREATE_SUPPLIER','Suppliers','Created supplier: TECNO distribution','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 09:36:55');
INSERT INTO `audit_logs` VALUES ('43','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 14:35:39');
INSERT INTO `audit_logs` VALUES ('44','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 14:35:55');
INSERT INTO `audit_logs` VALUES ('45','1','CREATE_ROLE','Roles','Created role: users','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-08-29 14:44:11');

DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` VALUES ('1','Smartphones','Mobile phones and smartphones',NULL,'active','2026-08-28 17:12:37','2026-08-28 17:12:37');
INSERT INTO `categories` VALUES ('2','Tablets','Tablet computers',NULL,'active','2026-08-28 17:12:37','2026-08-28 17:12:37');
INSERT INTO `categories` VALUES ('3','Accessories','Phone cases, chargers, screen protectors',NULL,'active','2026-08-28 17:12:37','2026-08-28 17:12:37');
INSERT INTO `categories` VALUES ('4','Wearables','Smartwatches, fitness bands',NULL,'active','2026-08-28 17:12:37','2026-08-28 17:12:37');
INSERT INTO `categories` VALUES ('5','earphone','listening material',NULL,'active','2026-08-29 09:22:38','2026-08-29 09:22:38');

DROP TABLE IF EXISTS `mobile_models`;
CREATE TABLE `mobile_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'Pcs',
  `unit_price` decimal(10,2) DEFAULT 0.00,
  `purchase_price` decimal(10,2) DEFAULT 0.00,
  `selling_price` decimal(10,2) DEFAULT 0.00,
  `current_stock` int(11) DEFAULT 0,
  `min_stock_level` int(11) DEFAULT 5,
  `max_stock_level` int(11) DEFAULT 100,
  `reorder_point` int(11) DEFAULT 10,
  `location` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `mobile_models_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mobile_models_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mobile_models` VALUES ('1','APP-001','iPhone 15 Pro Max','Apple iPhone 15 Pro Max 256GB','1','1','Pcs','1199.00','0.00','1199.00','13','5','100','5',NULL,'active','2026-08-28 17:12:37','2026-08-29 09:31:43');
INSERT INTO `mobile_models` VALUES ('2','APP-002','iPhone 15 Pro','Apple iPhone 15 Pro 128GB','1','1','Pcs','999.00','0.00','999.00','817','5','100','5',NULL,'active','2026-08-28 17:12:37','2026-08-29 09:25:42');
INSERT INTO `mobile_models` VALUES ('3','SAM-001','Samsung Galaxy S24 Ultra','Samsung Galaxy S24 Ultra 256GB','1','2','Pcs','1199.00','0.00','1199.00','46','5','100','5',NULL,'active','2026-08-28 17:12:37','2026-08-29 09:30:27');
INSERT INTO `mobile_models` VALUES ('4','ZTE-001','ZTE 8085','zte phone','1','2','Pcs','45.96','0.00','0.00','4','5','100','1000','arbaminch','active','2026-08-28 20:41:27','2026-08-28 21:07:22');
INSERT INTO `mobile_models` VALUES ('8','TECNO-001','TECNO SPARK','smartphone good','1','2','Pcs','340.00','0.00','0.00','0','5','100','100','mintamir','active','2026-08-29 09:28:42','2026-08-29 09:28:42');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `roles` VALUES ('1','admin','System Administrator','{\"all\":true}','2026-08-28 17:12:36','2026-08-28 17:12:36');
INSERT INTO `roles` VALUES ('2','manager','Store Manager','{\"approve_requests\":true,\"view_reports\":true,\"monitor_inventory\":true,\"manage_suppliers\":true}','2026-08-28 17:12:36','2026-08-28 17:12:36');
INSERT INTO `roles` VALUES ('3','store_keeper','Store Keeper','{\"manage_stock\":true,\"record_transactions\":true,\"update_inventory\":true}','2026-08-28 17:12:36','2026-08-28 17:12:36');
INSERT INTO `roles` VALUES ('4','users','person of get service','{\"manage_users\":false,\"manage_roles\":false,\"system_settings\":false,\"backup_restore\":false,\"view_audit\":true,\"approve_requests\":false,\"view_reports\":true,\"monitor_inventory\":false,\"manage_suppliers\":false,\"manage_stock\":false,\"record_transactions\":false,\"update_inventory\":false}','2026-08-29 14:44:11','2026-08-29 14:44:11');

DROP TABLE IF EXISTS `stock_transactions`;
CREATE TABLE `stock_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_type` enum('IN','OUT','RETURN','ADJUSTMENT','TRANSFER') NOT NULL,
  `model_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `transaction_date` datetime DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('PENDING','APPROVED','REJECTED','COMPLETED') DEFAULT 'PENDING',
  `department` varchar(100) DEFAULT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `from_location` varchar(100) DEFAULT NULL,
  `to_location` varchar(100) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `stock_transactions_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `mobile_models` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_transactions_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_transactions_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_transactions_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `stock_transactions` VALUES ('9','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:19',NULL,NULL,NULL,'PENDING','cs','alem','sdfd',NULL,NULL,NULL,NULL,'2026-08-28 20:54:19','2026-08-28 20:54:19');
INSERT INTO `stock_transactions` VALUES ('10','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:24',NULL,NULL,NULL,'APPROVED','cs','alem','sdfd',NULL,NULL,'2','2026-08-29 09:25:21','2026-08-28 20:54:24','2026-08-29 09:25:21');
INSERT INTO `stock_transactions` VALUES ('11','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:32',NULL,NULL,NULL,'PENDING','cs','alem','sdfd',NULL,NULL,NULL,NULL,'2026-08-28 20:54:32','2026-08-28 20:54:32');
INSERT INTO `stock_transactions` VALUES ('12','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:32',NULL,NULL,NULL,'PENDING','cs','alem','sdfd',NULL,NULL,NULL,NULL,'2026-08-28 20:54:32','2026-08-28 20:54:32');
INSERT INTO `stock_transactions` VALUES ('13','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:35',NULL,NULL,NULL,'PENDING','cs','alem','sdfd',NULL,NULL,NULL,NULL,'2026-08-28 20:54:35','2026-08-28 20:54:35');
INSERT INTO `stock_transactions` VALUES ('14','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:35',NULL,NULL,NULL,'PENDING','cs','alem','sdfd',NULL,NULL,NULL,NULL,'2026-08-28 20:54:35','2026-08-28 20:54:35');
INSERT INTO `stock_transactions` VALUES ('15','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:47',NULL,NULL,NULL,'APPROVED','cs','alem','sell',NULL,NULL,'2','2026-08-29 09:25:32','2026-08-28 20:54:47','2026-08-29 09:25:32');
INSERT INTO `stock_transactions` VALUES ('16','OUT','2',NULL,'1',NULL,NULL,'2026-08-28 20:54:51',NULL,NULL,NULL,'APPROVED','cs','alem','sell',NULL,NULL,'2','2026-08-29 09:25:42','2026-08-28 20:54:51','2026-08-29 09:25:42');
INSERT INTO `stock_transactions` VALUES ('17','TRANSFER','1',NULL,'-2',NULL,NULL,'2026-08-28 20:55:20',NULL,NULL,'pass','COMPLETED',NULL,NULL,NULL,'shelf A-2','shelf B-2',NULL,NULL,'2026-08-28 20:55:20','2026-08-28 20:55:20');
INSERT INTO `stock_transactions` VALUES ('18','TRANSFER','1',NULL,'-2',NULL,NULL,'2026-08-28 20:55:23',NULL,NULL,'pass','COMPLETED',NULL,NULL,NULL,'shelf A-2','shelf B-2',NULL,NULL,'2026-08-28 20:55:23','2026-08-28 20:55:23');
INSERT INTO `stock_transactions` VALUES ('19','ADJUSTMENT','2',NULL,'399',NULL,NULL,'2026-08-28 20:57:35',NULL,NULL,'stock count correction','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-28 20:57:35','2026-08-28 20:57:35');
INSERT INTO `stock_transactions` VALUES ('20','ADJUSTMENT','2',NULL,'399',NULL,NULL,'2026-08-28 20:57:44',NULL,NULL,'stock count correction','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-28 20:57:44','2026-08-28 20:57:44');
INSERT INTO `stock_transactions` VALUES ('21','IN','2','1','2','24.00','48.00','2026-08-28 21:01:51',NULL,'56789','i want','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-28 21:01:51','2026-08-28 21:01:51');
INSERT INTO `stock_transactions` VALUES ('22','RETURN','4',NULL,'1',NULL,NULL,'2026-08-28 21:07:17',NULL,NULL,'byhkaj','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-28 21:07:17','2026-08-28 21:07:17');
INSERT INTO `stock_transactions` VALUES ('23','RETURN','4',NULL,'1',NULL,NULL,'2026-08-28 21:07:21',NULL,NULL,'byhkaj','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-28 21:07:21','2026-08-28 21:07:21');
INSERT INTO `stock_transactions` VALUES ('24','RETURN','4',NULL,'1',NULL,NULL,'2026-08-28 21:07:22',NULL,NULL,'byhkaj','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-28 21:07:22','2026-08-28 21:07:22');
INSERT INTO `stock_transactions` VALUES ('25','RETURN','4',NULL,'1',NULL,NULL,'2026-08-28 21:07:22',NULL,NULL,'byhkaj','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-28 21:07:22','2026-08-28 21:07:22');
INSERT INTO `stock_transactions` VALUES ('26','IN','3','2','34','35.00','1190.00','2026-08-29 09:30:27','3','567','to be wants','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-29 09:30:27','2026-08-29 09:30:27');
INSERT INTO `stock_transactions` VALUES ('27','OUT','2',NULL,'34',NULL,NULL,'2026-08-29 09:31:05','3',NULL,NULL,'PENDING','arc','gezimu','wants',NULL,NULL,NULL,NULL,'2026-08-29 09:31:05','2026-08-29 09:31:05');
INSERT INTO `stock_transactions` VALUES ('28','RETURN','1',NULL,'2',NULL,NULL,'2026-08-29 09:31:43','3',NULL,'get failure','COMPLETED',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-29 09:31:43','2026-08-29 09:31:43');

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `suppliers` VALUES ('1','SUP-001','Apple Direct','John Smith','john@apple.com','1-800-692-7753','1 Apple Park Way, Cupertino, CA','active','2026-08-28 17:12:37','2026-08-28 17:12:37');
INSERT INTO `suppliers` VALUES ('2','SUP-002','Samsung Distribution','Sarah Johnson','sarah@samsung.com','1-800-726-7864','85 Challenger Road, Ridgefield Park, NJ','active','2026-08-28 17:12:37','2026-08-28 17:12:37');
INSERT INTO `suppliers` VALUES ('3','ZTE-003','ZTE distribution','tigist tayework','wub@store.com','0949796379','mintamir','active','2026-08-29 09:35:34','2026-08-29 09:35:34');
INSERT INTO `suppliers` VALUES ('4','-','TECNO distribution','samri alemu','','0901749823','minjar','active','2026-08-29 09:36:55','2026-08-29 09:36:55');

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_settings` VALUES ('1','company_name','Mobile Store Management System','Company Name','2026-08-28 17:12:37');
INSERT INTO `system_settings` VALUES ('2','currency_symbol','$','Currency Symbol','2026-08-28 17:12:37');
INSERT INTO `system_settings` VALUES ('3','low_stock_threshold','5','Low Stock Alert Threshold','2026-08-28 17:12:37');
INSERT INTO `system_settings` VALUES ('4','date_format','Y-m-d H:i:s','Date Format','2026-08-28 17:12:37');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `role` enum('admin','manager','store_keeper') DEFAULT 'store_keeper',
  `status` enum('active','inactive') DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES ('1','admin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin@store.com','System Administrator',NULL,'admin','active','2026-08-29 14:35:54','2026-08-28 17:12:37','2026-08-29 14:35:54');
INSERT INTO `users` VALUES ('2','manager','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','manager@store.com','Store Manager',NULL,'manager','active','2026-08-29 09:34:24','2026-08-28 17:12:37','2026-08-29 09:34:24');
INSERT INTO `users` VALUES ('3','storekeeper','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','keeper@store.com','Store Keeper',NULL,'store_keeper','active','2026-08-29 09:29:45','2026-08-28 17:12:37','2026-08-29 09:29:45');
INSERT INTO `users` VALUES ('4','alemitu','$2y$10$44v.TQi.Afr.LKA73vgmh.MT/MyzJIcbbto.yOS0iCit0sBFDQ1y2','alem@store.com','abebe',NULL,'manager','active',NULL,'2026-08-29 09:17:20','2026-08-29 09:17:20');

SET FOREIGN_KEY_CHECKS=1;
