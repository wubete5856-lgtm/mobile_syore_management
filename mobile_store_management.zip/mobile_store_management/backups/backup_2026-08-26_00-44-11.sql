-- Backup created on 2026-08-26 00:44:11

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `audit_logs` VALUES ('1','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 17:52:11');
INSERT INTO `audit_logs` VALUES ('2','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:02:40');
INSERT INTO `audit_logs` VALUES ('3','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:02:54');
INSERT INTO `audit_logs` VALUES ('4','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:03:34');
INSERT INTO `audit_logs` VALUES ('5','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:25:48');
INSERT INTO `audit_logs` VALUES ('6','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:26:21');
INSERT INTO `audit_logs` VALUES ('7','3','STOCK_OUT_REQUEST','Stock','Requested 1 of model ID 1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:28:38');
INSERT INTO `audit_logs` VALUES ('8','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:29:04');
INSERT INTO `audit_logs` VALUES ('9','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:29:10');
INSERT INTO `audit_logs` VALUES ('10','2','STOCK_OUT_APPROVE','Stock','Approved request ID 1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:29:39');
INSERT INTO `audit_logs` VALUES ('11','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:30:25');
INSERT INTO `audit_logs` VALUES ('12','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:30:31');
INSERT INTO `audit_logs` VALUES ('13','3','STOCK_IN','Stock','Received 20 of model ID 3','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:32:31');
INSERT INTO `audit_logs` VALUES ('14','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:33:04');
INSERT INTO `audit_logs` VALUES ('15','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:33:10');
INSERT INTO `audit_logs` VALUES ('16','2','CREATE_BRAND','Brands','Created brand ZTE Bland','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:36:03');
INSERT INTO `audit_logs` VALUES ('17','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:36:24');
INSERT INTO `audit_logs` VALUES ('18','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:36:30');
INSERT INTO `audit_logs` VALUES ('19','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:37:56');
INSERT INTO `audit_logs` VALUES ('20','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:38:01');
INSERT INTO `audit_logs` VALUES ('21','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:51:18');
INSERT INTO `audit_logs` VALUES ('22','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 18:51:24');
INSERT INTO `audit_logs` VALUES ('23','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:13:04');
INSERT INTO `audit_logs` VALUES ('24','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:13:11');
INSERT INTO `audit_logs` VALUES ('25','1','UPDATE_SETTINGS','Settings','Updated system settings','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:25:46');
INSERT INTO `audit_logs` VALUES ('26','1','UPDATE_SETTINGS','Settings','Updated system settings','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:25:54');
INSERT INTO `audit_logs` VALUES ('27','1','UPDATE_SETTINGS','Settings','Updated system settings','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:25:56');
INSERT INTO `audit_logs` VALUES ('28','1','UPDATE_SETTINGS','Settings','Updated system settings','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:25:58');
INSERT INTO `audit_logs` VALUES ('29','1','UPDATE_SETTINGS','Settings','Updated system settings','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:25:58');
INSERT INTO `audit_logs` VALUES ('30','1','CREATE_USER','User Management','Created user: nsr/t/010/16 (ID: 4)','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:37:07');
INSERT INTO `audit_logs` VALUES ('31','1','UPDATE_USER','User Management','Updated user: wubete (ID: 4)','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:37:44');
INSERT INTO `audit_logs` VALUES ('32','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:38:35');
INSERT INTO `audit_logs` VALUES ('33','4','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:38:43');
INSERT INTO `audit_logs` VALUES ('34','4','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:38:55');
INSERT INTO `audit_logs` VALUES ('35','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:39:11');
INSERT INTO `audit_logs` VALUES ('36','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:40:43');
INSERT INTO `audit_logs` VALUES ('37','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:40:52');
INSERT INTO `audit_logs` VALUES ('38','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:43:09');
INSERT INTO `audit_logs` VALUES ('39','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:43:15');
INSERT INTO `audit_logs` VALUES ('40','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:48:47');
INSERT INTO `audit_logs` VALUES ('41','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:48:53');
INSERT INTO `audit_logs` VALUES ('42','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:57:43');
INSERT INTO `audit_logs` VALUES ('43','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:57:48');
INSERT INTO `audit_logs` VALUES ('44','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:58:17');
INSERT INTO `audit_logs` VALUES ('45','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 20:58:33');
INSERT INTO `audit_logs` VALUES ('46','1','CREATE_BRAND','Brands','Created brand ddfgh','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:01:41');
INSERT INTO `audit_logs` VALUES ('47','1','STOCK_RETURN','Stock','Returned 3 of model ID 2','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:02:57');
INSERT INTO `audit_logs` VALUES ('48','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:03:36');
INSERT INTO `audit_logs` VALUES ('49','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:03:41');
INSERT INTO `audit_logs` VALUES ('50','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:03:50');
INSERT INTO `audit_logs` VALUES ('51','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:03:55');
INSERT INTO `audit_logs` VALUES ('52','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:05:36');
INSERT INTO `audit_logs` VALUES ('53','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:05:41');
INSERT INTO `audit_logs` VALUES ('54','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:20:42');
INSERT INTO `audit_logs` VALUES ('55','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:20:47');
INSERT INTO `audit_logs` VALUES ('56','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:23:06');
INSERT INTO `audit_logs` VALUES ('57','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:24:39');
INSERT INTO `audit_logs` VALUES ('58','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:24:49');
INSERT INTO `audit_logs` VALUES ('59','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:24:55');
INSERT INTO `audit_logs` VALUES ('60','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:25:04');
INSERT INTO `audit_logs` VALUES ('61','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:25:10');
INSERT INTO `audit_logs` VALUES ('62','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:25:30');
INSERT INTO `audit_logs` VALUES ('63','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-19 21:25:50');
INSERT INTO `audit_logs` VALUES ('64','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 11:44:10');
INSERT INTO `audit_logs` VALUES ('65','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:14:42');
INSERT INTO `audit_logs` VALUES ('66','1','STOCK_ADJUST','Stock','Adjusted stock: increase 50 for model ID 3','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:27:33');
INSERT INTO `audit_logs` VALUES ('67','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:34:54');
INSERT INTO `audit_logs` VALUES ('68','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:35:06');
INSERT INTO `audit_logs` VALUES ('69','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:45:59');
INSERT INTO `audit_logs` VALUES ('70','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:46:08');
INSERT INTO `audit_logs` VALUES ('71','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:48:55');
INSERT INTO `audit_logs` VALUES ('72','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 17:49:02');
INSERT INTO `audit_logs` VALUES ('73','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:06:14');
INSERT INTO `audit_logs` VALUES ('74','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:06:20');
INSERT INTO `audit_logs` VALUES ('75','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:11:32');
INSERT INTO `audit_logs` VALUES ('76','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:11:38');
INSERT INTO `audit_logs` VALUES ('77','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:18:20');
INSERT INTO `audit_logs` VALUES ('78','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:18:25');
INSERT INTO `audit_logs` VALUES ('79','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:19:28');
INSERT INTO `audit_logs` VALUES ('80','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:19:33');
INSERT INTO `audit_logs` VALUES ('81','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:27:58');
INSERT INTO `audit_logs` VALUES ('82','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:28:02');
INSERT INTO `audit_logs` VALUES ('83','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:31:30');
INSERT INTO `audit_logs` VALUES ('84','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:31:39');
INSERT INTO `audit_logs` VALUES ('85','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:35:22');
INSERT INTO `audit_logs` VALUES ('86','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:35:27');
INSERT INTO `audit_logs` VALUES ('87','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:38:46');
INSERT INTO `audit_logs` VALUES ('88','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:38:54');
INSERT INTO `audit_logs` VALUES ('89','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:55:12');
INSERT INTO `audit_logs` VALUES ('90','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 18:55:18');
INSERT INTO `audit_logs` VALUES ('91','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 19:49:02');
INSERT INTO `audit_logs` VALUES ('92','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 19:49:09');
INSERT INTO `audit_logs` VALUES ('93','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 20:03:12');
INSERT INTO `audit_logs` VALUES ('94','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 20:03:18');
INSERT INTO `audit_logs` VALUES ('95','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 20:05:48');
INSERT INTO `audit_logs` VALUES ('96','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-20 20:06:01');
INSERT INTO `audit_logs` VALUES ('97','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 09:01:47');
INSERT INTO `audit_logs` VALUES ('98','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 09:01:52');
INSERT INTO `audit_logs` VALUES ('99','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 09:01:57');
INSERT INTO `audit_logs` VALUES ('100','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 09:02:01');
INSERT INTO `audit_logs` VALUES ('101','1','CREATE_CATEGORY','Categories','Created category: fgjhjhjk (ID: 5)','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 09:41:36');
INSERT INTO `audit_logs` VALUES ('102','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 10:01:27');
INSERT INTO `audit_logs` VALUES ('103','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 10:01:33');
INSERT INTO `audit_logs` VALUES ('104','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 08:57:26');
INSERT INTO `audit_logs` VALUES ('105','3','STOCK_OUT_REQUEST','Stock','Requested 23 of model ID 2','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:13:21');
INSERT INTO `audit_logs` VALUES ('106','3','STOCK_RETURN','Stock','Returned 2 of model ID 1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:13:54');
INSERT INTO `audit_logs` VALUES ('107','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:20:56');
INSERT INTO `audit_logs` VALUES ('108','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:21:03');
INSERT INTO `audit_logs` VALUES ('109','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:21:07');
INSERT INTO `audit_logs` VALUES ('110','1','CREATE_USER','User Management','Created user: tibeb (ID: 5)','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:23:00');
INSERT INTO `audit_logs` VALUES ('111','1','CREATE_ROLE','Roles','Created role: user','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:24:54');
INSERT INTO `audit_logs` VALUES ('112','1','DELETE_ROLE','Roles','Deleted role: user (ID: 4)','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:25:02');
INSERT INTO `audit_logs` VALUES ('113','1','DELETE_CATEGORY','Categories','Deleted category ID 5','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:25:57');
INSERT INTO `audit_logs` VALUES ('114','1','UPDATE_SETTINGS','Settings','Updated system settings','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:27:46');
INSERT INTO `audit_logs` VALUES ('115','1','UPDATE_SETTINGS','Settings','Updated system settings','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:27:52');
INSERT INTO `audit_logs` VALUES ('116','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:28:07');
INSERT INTO `audit_logs` VALUES ('117','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:28:28');
INSERT INTO `audit_logs` VALUES ('118','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:47:48');
INSERT INTO `audit_logs` VALUES ('119','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:47:54');
INSERT INTO `audit_logs` VALUES ('120','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:52:53');
INSERT INTO `audit_logs` VALUES ('121','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 11:53:00');
INSERT INTO `audit_logs` VALUES ('122','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:03:44');
INSERT INTO `audit_logs` VALUES ('123','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:03:53');
INSERT INTO `audit_logs` VALUES ('124','1','CREATE_BACKUP','Backup','Created backup: backup_2026-08-24_02-03-59.sql','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:03:59');
INSERT INTO `audit_logs` VALUES ('125','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:04:51');
INSERT INTO `audit_logs` VALUES ('126','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:04:57');
INSERT INTO `audit_logs` VALUES ('127','2','CREATE_MODEL','Inventory','Created model ZTE 8085','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:08:13');
INSERT INTO `audit_logs` VALUES ('128','2','UPDATE_MODEL','Inventory','Updated model ZTE 8085','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:08:30');
INSERT INTO `audit_logs` VALUES ('129','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:09:23');
INSERT INTO `audit_logs` VALUES ('130','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:09:28');
INSERT INTO `audit_logs` VALUES ('131','1','CREATE_SUPPLIER','Suppliers','Created supplier: earpad','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:14:21');
INSERT INTO `audit_logs` VALUES ('132','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:15:30');
INSERT INTO `audit_logs` VALUES ('133','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:15:43');
INSERT INTO `audit_logs` VALUES ('134','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:25:01');
INSERT INTO `audit_logs` VALUES ('135','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:25:07');
INSERT INTO `audit_logs` VALUES ('136','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:27:29');
INSERT INTO `audit_logs` VALUES ('137','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:27:34');
INSERT INTO `audit_logs` VALUES ('138','3','DELETE_BRAND','Brands','Deleted brand ID: 6','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 12:28:54');
INSERT INTO `audit_logs` VALUES ('139','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:34:58');
INSERT INTO `audit_logs` VALUES ('140','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:35:03');
INSERT INTO `audit_logs` VALUES ('141','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:36:31');
INSERT INTO `audit_logs` VALUES ('142','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:36:37');
INSERT INTO `audit_logs` VALUES ('143','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:45:26');
INSERT INTO `audit_logs` VALUES ('144','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:45:30');
INSERT INTO `audit_logs` VALUES ('145','3','STOCK_ADJUST','Stock','Adjusted stock: increase 200 for model ID 9. Reason: stock count increase','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:46:13');
INSERT INTO `audit_logs` VALUES ('146','3','STOCK_OUT_REQUEST','Stock','Requested 15 of model ID 1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:47:32');
INSERT INTO `audit_logs` VALUES ('147','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:47:52');
INSERT INTO `audit_logs` VALUES ('148','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:47:58');
INSERT INTO `audit_logs` VALUES ('149','2','STOCK_OUT_APPROVE','Stock','Approved request ID 8','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 15:48:44');
INSERT INTO `audit_logs` VALUES ('150','2','UPDATE_PROFILE','Profile','Updated profile information','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:36:28');
INSERT INTO `audit_logs` VALUES ('151','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:36:49');
INSERT INTO `audit_logs` VALUES ('152','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:37:08');
INSERT INTO `audit_logs` VALUES ('153','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:37:32');
INSERT INTO `audit_logs` VALUES ('154','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:37:42');
INSERT INTO `audit_logs` VALUES ('155','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:37:49');
INSERT INTO `audit_logs` VALUES ('156','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:38:38');
INSERT INTO `audit_logs` VALUES ('157','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:39:18');
INSERT INTO `audit_logs` VALUES ('158','2','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:39:23');
INSERT INTO `audit_logs` VALUES ('159','2','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:40:17');
INSERT INTO `audit_logs` VALUES ('160','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:40:22');
INSERT INTO `audit_logs` VALUES ('161','1','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:42:11');
INSERT INTO `audit_logs` VALUES ('162','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:42:48');
INSERT INTO `audit_logs` VALUES ('163','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:44:39');
INSERT INTO `audit_logs` VALUES ('164','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-24 16:48:07');
INSERT INTO `audit_logs` VALUES ('165','3','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-26 10:42:05');
INSERT INTO `audit_logs` VALUES ('166','3','LOGOUT','Authentication','User logged out','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-26 10:42:50');
INSERT INTO `audit_logs` VALUES ('167','1','LOGIN','Authentication','User logged in','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-26 10:43:24');

DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `brands` VALUES ('1','Apple','Apple Inc. - iPhone, iPad, MacBooks',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `brands` VALUES ('2','Samsung','Samsung Electronics - Galaxy series',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `brands` VALUES ('3','Xiaomi','Xiaomi Corporation - Redmi, Mi series',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `brands` VALUES ('4','OnePlus','OnePlus Technology - OnePlus series',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `brands` VALUES ('5','ZTE Bland','ZTE technology',NULL,'active','2026-08-19 18:36:03','2026-08-19 18:36:03');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` VALUES ('1','Smartphones','Mobile phones and smartphones',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `categories` VALUES ('2','Tablets','Tablet computers',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `categories` VALUES ('3','Accessories','Phone cases, chargers, screen protectors',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `categories` VALUES ('4','Wearables','Smartwatches, fitness bands',NULL,'active','2026-08-19 17:33:28','2026-08-19 17:33:28');

DROP TABLE IF EXISTS `mobile_models`;
CREATE TABLE `mobile_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'Pcs',
  `unit_price` decimal(10,2) DEFAULT 0.00,
  `purchase_price` decimal(10,2) DEFAULT 0.00,
  `selling_price` decimal(10,2) DEFAULT 0.00,
  `current_stock` int(11) DEFAULT 0,
  `min_stock_level` int(11) DEFAULT 5,
  `max_stock_level` int(11) DEFAULT 100,
  `reorder_point` int(11) DEFAULT 10,
  `location` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `brand_id` (`brand_id`),
  KEY `category_id` (`category_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `mobile_models_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mobile_models_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mobile_models_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mobile_models` VALUES ('1','APP-001','iPhone 15 Pro Max','Apple iPhone 15 Pro Max 256GB','1','1','1','Pcs','1199.00','0.00','1199.00','1','5','100','5',NULL,'active','2026-08-19 17:33:28','2026-08-24 15:48:44');
INSERT INTO `mobile_models` VALUES ('2','APP-002','iPhone 15 Pro','Apple iPhone 15 Pro 128GB','1','1','1','Pcs','999.00','0.00','999.00','23','5','100','5',NULL,'active','2026-08-19 17:33:28','2026-08-19 21:02:57');
INSERT INTO `mobile_models` VALUES ('3','SAM-001','Samsung Galaxy S24 Ultra','Samsung Galaxy S24 Ultra 256GB','2','1','2','Pcs','1199.00','0.00','1199.00','82','5','100','5',NULL,'active','2026-08-19 17:33:28','2026-08-20 17:27:33');
INSERT INTO `mobile_models` VALUES ('9','ZTE-001','ZTE 8085','mobile is good','5','1','2','Pcs','10.00','0.00','0.00','200','5','100','100',NULL,'active','2026-08-24 12:08:12','2026-08-24 15:46:13');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `roles` VALUES ('1','admin','System Administrator','{\"all\":true}','2026-08-19 17:33:27','2026-08-19 17:33:27');
INSERT INTO `roles` VALUES ('2','manager','Store Manager','{\"approve_requests\":true,\"view_reports\":true,\"monitor_inventory\":true,\"manage_suppliers\":true}','2026-08-19 17:33:27','2026-08-19 17:33:27');
INSERT INTO `roles` VALUES ('3','store_keeper','Store Keeper','{\"manage_stock\":true,\"record_transactions\":true,\"update_inventory\":true}','2026-08-19 17:33:27','2026-08-19 17:33:27');

DROP TABLE IF EXISTS `stock_transactions`;
CREATE TABLE `stock_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_type` enum('IN','OUT','RETURN','ADJUSTMENT','TRANSFER') NOT NULL,
  `model_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `transaction_date` datetime DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('PENDING','APPROVED','REJECTED','COMPLETED') DEFAULT 'PENDING',
  `department` varchar(100) DEFAULT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `stock_transactions_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `mobile_models` (`id`),
  CONSTRAINT `stock_transactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `stock_transactions_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `stock_transactions` VALUES ('1','OUT','1','1',NULL,NULL,'2026-08-19 18:28:37','3',NULL,NULL,'APPROVED','cs','wubete','communication','2','2026-08-19 18:29:38','2026-08-19 18:28:37','2026-08-19 18:29:38');
INSERT INTO `stock_transactions` VALUES ('2','IN','3','20','20.50','410.00','2026-08-19 18:32:30','3','','gain sams','COMPLETED',NULL,NULL,NULL,NULL,NULL,'2026-08-19 18:32:30','2026-08-19 18:32:30');
INSERT INTO `stock_transactions` VALUES ('3','RETURN','2','3',NULL,NULL,'2026-08-19 21:02:57','1',NULL,'not afford','COMPLETED',NULL,NULL,NULL,NULL,NULL,'2026-08-19 21:02:57','2026-08-19 21:02:57');
INSERT INTO `stock_transactions` VALUES ('4','ADJUSTMENT','3','50',NULL,NULL,'2026-08-20 17:27:33','1',NULL,'adjust','COMPLETED',NULL,NULL,NULL,NULL,NULL,'2026-08-20 17:27:33','2026-08-20 17:27:33');
INSERT INTO `stock_transactions` VALUES ('5','OUT','2','23',NULL,NULL,'2026-08-24 11:13:20','3',NULL,NULL,'PENDING','cs','wubete','out',NULL,NULL,'2026-08-24 11:13:20','2026-08-24 11:13:20');
INSERT INTO `stock_transactions` VALUES ('6','RETURN','1','2',NULL,NULL,'2026-08-24 11:13:52','3',NULL,'not confort','COMPLETED',NULL,NULL,NULL,NULL,NULL,'2026-08-24 11:13:52','2026-08-24 11:13:52');
INSERT INTO `stock_transactions` VALUES ('7','ADJUSTMENT','9','200',NULL,NULL,'2026-08-24 15:46:13','3',NULL,'stock count increase','COMPLETED',NULL,NULL,NULL,NULL,NULL,'2026-08-24 15:46:13','2026-08-24 15:46:13');
INSERT INTO `stock_transactions` VALUES ('8','OUT','1','15',NULL,NULL,'2026-08-24 15:47:32','3',NULL,NULL,'APPROVED','it','alem','profit','2','2026-08-24 15:48:44','2026-08-24 15:47:32','2026-08-24 15:48:44');

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `suppliers` VALUES ('1','SUP-001','Apple Direct','John Smith','john@apple.com','1-800-692-7753','1 Apple Park Way, Cupertino, CA','active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `suppliers` VALUES ('2','SUP-002','Samsung Distribution','Sarah Johnson','sarah@samsung.com','1-800-726-7864','85 Challenger Road, Ridgefield Park, NJ','active','2026-08-19 17:33:28','2026-08-19 17:33:28');
INSERT INTO `suppliers` VALUES ('3','accessories','earpad','wubete tayework','wubete@store.com','0939124576','Arba Minch','active','2026-08-24 12:14:21','2026-08-24 12:14:21');

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_settings` VALUES ('1','company_name','Mobile Store Management System','Company Name','2026-08-19 17:33:27');
INSERT INTO `system_settings` VALUES ('2','currency_symbol','40','Currency Symbol','2026-08-19 20:25:46');
INSERT INTO `system_settings` VALUES ('3','low_stock_threshold','5','Low Stock Alert Threshold','2026-08-19 17:33:27');
INSERT INTO `system_settings` VALUES ('4','date_format','Y-m-d H:i:s','Date Format','2026-08-19 17:33:27');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `role` enum('admin','manager','store_keeper') DEFAULT 'store_keeper',
  `status` enum('active','inactive') DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES ('1','admin','$2y$10$uM6rKpR9IxWonxQcMlBYMeMPDjhwxllnboCgx1t.FUC7OayxUtHIO','admin@store.com','System Administrator',NULL,'admin','active','2026-08-26 10:43:24','2026-08-19 17:33:27','2026-08-26 10:43:24');
INSERT INTO `users` VALUES ('2','manager','$2y$10$0tB.kvC6nvjxpDulesh6Gei2RegGgNyieEtE/zWEKVBISDiyu.kRu','manager@store.com','Store Manager','store','manager','active','2026-08-24 16:39:23','2026-08-19 17:33:27','2026-08-24 16:39:23');
INSERT INTO `users` VALUES ('3','storekeeper','$2y$10$uM6rKpR9IxWonxQcMlBYMeMPDjhwxllnboCgx1t.FUC7OayxUtHIO','keeper@store.com','Store Keeper',NULL,'store_keeper','active','2026-08-26 10:42:04','2026-08-19 17:33:27','2026-08-26 10:42:04');
INSERT INTO `users` VALUES ('4','wubete','$2y$10$FZLm1.b3L45OdkmA7g.JKONJ3yUkWVH03UEdNPPcFhQ/.wpC9/9RS','wubete@store.com','wubete tayework',NULL,'store_keeper','active','2026-08-19 20:38:43','2026-08-19 20:37:07','2026-08-19 20:38:43');
INSERT INTO `users` VALUES ('5','tibeb','$2y$10$1M7rSwil.m4JAVDyJNNp0OoSAUUH2MLUqi.pm.ebr3bMAzHDGw3hK','tibeb@gmail.com','gerima',NULL,'store_keeper','active',NULL,'2026-08-24 11:23:00','2026-08-24 11:23:00');

SET FOREIGN_KEY_CHECKS=1;
