-- =============================================
-- MOBILE STORE MANAGEMENT SYSTEM DATABASE
-- FULLY UPDATED WITH ALL FIXES
-- =============================================

-- Disable foreign key checks for clean drop
SET FOREIGN_KEY_CHECKS = 0;

-- Drop all tables in correct order
DROP TABLE IF EXISTS stock_transactions;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS mobile_models;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS system_settings;

-- Enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================
-- 1. USERS TABLE
-- =============================================
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    department VARCHAR(100),
    role ENUM('admin','manager','store_keeper','employee') DEFAULT 'store_keeper',
    status ENUM('active','inactive') DEFAULT 'active',
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- 2. ROLES TABLE
-- =============================================
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    permissions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- 3. CATEGORIES TABLE
-- =============================================
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_id INT DEFAULT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- =============================================
-- 4. SUPPLIERS TABLE
-- =============================================
CREATE TABLE suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- 5. MOBILE MODELS TABLE 
-- =============================================
CREATE TABLE mobile_models (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    category_id INT,
    supplier_id INT,
    unit VARCHAR(20) NOT NULL DEFAULT 'Pcs',
    unit_price DECIMAL(10,2) DEFAULT 0.00,
    purchase_price DECIMAL(10,2) DEFAULT 0.00,
    selling_price DECIMAL(10,2) DEFAULT 0.00,
    current_stock INT DEFAULT 0,
    min_stock_level INT DEFAULT 5,
    max_stock_level INT DEFAULT 100,
    reorder_point INT DEFAULT 10,
    location VARCHAR(100),
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

-- =============================================
-- 6. STOCK TRANSACTIONS TABLE (Fully fixed)
-- =============================================
CREATE TABLE stock_transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_type ENUM('IN','OUT','RETURN','ADJUSTMENT','TRANSFER') NOT NULL,
    model_id INT NOT NULL,
    supplier_id INT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2),
    total_amount DECIMAL(10,2),
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_id INT NULL,
    reference_number VARCHAR(50),
    notes TEXT,
    status ENUM('PENDING','APPROVED','REJECTED','COMPLETED') DEFAULT 'PENDING',
    department VARCHAR(100),
    employee_name VARCHAR(100),
    purpose TEXT,
    from_location VARCHAR(100) NULL,          -- For transfers
    to_location VARCHAR(100) NULL,            -- For transfers
    approved_by INT NULL,
    approved_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (model_id) REFERENCES mobile_models(id) ON DELETE CASCADE,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- 7. AUDIT LOGS TABLE
-- =============================================
CREATE TABLE audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    module VARCHAR(50),
    description TEXT,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- 8. SYSTEM SETTINGS TABLE
-- =============================================
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value TEXT,
    description VARCHAR(200),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- INSERT DEFAULT DATA
-- =============================================

INSERT IGNORE INTO roles (role_name, description, permissions) VALUES
('admin', 'System Administrator', '{"all":true}'),
('manager', 'Store Manager', '{"approve_requests":true,"view_reports":true,"monitor_inventory":true,"manage_suppliers":true}'),
('store_keeper', 'Store Keeper', '{"manage_stock":true,"record_transactions":true,"update_inventory":true}'),
('employee', 'Store Employee', '{"view_inventory":true,"record_sales":true}');

-- Users (password: password)
INSERT IGNORE INTO users (id, username, password, email, full_name, role, status) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@store.com', 'System Administrator', 'admin', 'active'),
(2, 'manager', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'manager@store.com', 'Store Manager', 'manager', 'active'),
(3, 'storekeeper', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'keeper@store.com', 'Store Keeper', 'store_keeper', 'active'),
(4, 'employee', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee@store.com', 'Employee User', 'employee', 'active');

INSERT IGNORE INTO system_settings (setting_key, setting_value, description) VALUES
('company_name', 'Mobile Store Management System', 'Company Name'),
('currency_symbol', '$', 'Currency Symbol'),
('low_stock_threshold', '5', 'Low Stock Alert Threshold'),
('date_format', 'Y-m-d H:i:s', 'Date Format');

-- Sample Categories
INSERT IGNORE INTO categories (name, description) VALUES
('Smartphones', 'Mobile phones and smartphones'),
('Tablets', 'Tablet computers'),
('Accessories', 'Phone cases, chargers, screen protectors'),
('Wearables', 'Smartwatches, fitness bands');

-- Sample Suppliers
INSERT IGNORE INTO suppliers (code, name, contact_person, email, phone, address) VALUES
('SUP-001', 'Apple Direct', 'John Smith', 'john@apple.com', '1-800-692-7753', '1 Apple Park Way, Cupertino, CA'),
('SUP-002', 'Samsung Distribution', 'Sarah Johnson', 'sarah@samsung.com', '1-800-726-7864', '85 Challenger Road, Ridgefield Park, NJ');

-- Sample Mobile Models 
INSERT IGNORE INTO mobile_models (code, name, description, category_id, supplier_id, unit, unit_price, selling_price, current_stock, reorder_point) VALUES
('APP-001', 'iPhone 15 Pro Max', 'Apple iPhone 15 Pro Max 256GB', 1, 1, 'Pcs', 1199.00, 1199.00, 15, 5),
('APP-002', 'iPhone 15 Pro', 'Apple iPhone 15 Pro 128GB', 1, 1, 'Pcs', 999.00, 999.00, 20, 5),
('SAM-001', 'Samsung Galaxy S24 Ultra', 'Samsung Galaxy S24 Ultra 256GB', 1, 2, 'Pcs', 1199.00, 1199.00, 12, 5);

-- =============================================
-- VERIFICATION (optional)
-- =============================================
-- SHOW TABLES;
-- SELECT * FROM users;
-- SELECT * FROM roles;