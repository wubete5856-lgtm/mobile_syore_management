<?php require_once 'config/config.php'; if (isLoggedIn()) { header('Location: dashboard.php'); exit(); } ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="container">
        <div class="row justify-content-center min-vh-100 align-items-center">
            <div class="col-md-5">
                <div class="card login-card shadow-lg">
                    <div class="card-body p-5">
                        <div class="text-center mb-4">
                            <i class="fas fa-mobile-alt fa-4x text-primary mb-3"></i>
                            <h3 class="fw-bold">Mobile Store</h3>
                            <p class="text-muted">Management System</p>
                        </div>
                        <div id="alertMessage"></div>
                        <form id="loginForm">
                            <div class="mb-3">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" placeholder="Username" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" placeholder="Password" required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 py-2"><i class="fas fa-sign-in-alt me-2"></i>Login</button>
                        </form>
                        
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function(){
        $('#loginForm').on('submit', function(e){
            e.preventDefault();
            const username = $('#username').val().trim();
            const password = $('#password').val().trim();
            $.ajax({
                url: 'api/auth.php',
                type: 'POST',
                data: { action: 'login', username: username, password: password },
                dataType: 'json',
                success: function(res){
                    if(res.success){
                        $('#alertMessage').html('<div class="alert alert-success">'+res.message+'</div>');
                        setTimeout(function(){ window.location.href = 'dashboard.php'; }, 500);
                    } else {
                        $('#alertMessage').html('<div class="alert alert-danger">'+res.message+'</div>');
                    }
                },
                error: function(){ $('#alertMessage').html('<div class="alert alert-danger">An error occurred.</div>'); }
            });
        });
    });
    </script>
</body>
</html>