<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

// =============================================
// GET: Fetch models (allowed for all roles)
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    if ($id > 0) {
        $stmt = $db->prepare("
            SELECT m.*, c.name as category_name, s.name as supplier_name
            FROM mobile_models m
            LEFT JOIN categories c ON m.category_id = c.id
            LEFT JOIN suppliers s ON m.supplier_id = s.id
            WHERE m.id = :id
        ");
        $stmt->execute([':id' => $id]);
        $model = $stmt->fetch();
        if ($model) {
            echo json_encode(['success' => true, 'data' => $model]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Model not found']);
        }
        exit;
    }

    $stmt = $db->query("
        SELECT m.*, c.name as category_name, s.name as supplier_name
        FROM mobile_models m
        LEFT JOIN categories c ON m.category_id = c.id
        LEFT JOIN suppliers s ON m.supplier_id = s.id
        WHERE m.status = 'active'
        ORDER BY m.name
    ");
    $models = $stmt->fetchAll();
    echo json_encode(['success' => true, 'data' => $models]);
    exit;
}

// =============================================
// POST: Create, Update, Delete (Admin ONLY)
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Only Admin can modify models
    if (!hasRole('admin')) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized: Only Admin can modify models']);
        exit;
    }

    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $userId = $_SESSION['user_id'];

    // CREATE
    if ($action === 'create') {
        $code = sanitize($_POST['code']);
        $name = sanitize($_POST['name']);
        $desc = sanitize($_POST['description']);
        $category = sanitize($_POST['category_id']);
        $supplier = sanitize($_POST['supplier_id']);
        $unit = sanitize($_POST['unit']);
        $price = sanitize($_POST['unit_price']);
        $reorder = sanitize($_POST['reorder_point']);
        $status = sanitize($_POST['status']);
        $location = sanitize($_POST['location']);

        if (empty($code) || empty($name) || empty($category)) {
            echo json_encode(['success' => false, 'message' => 'Code, Name, and Category are required']);
            exit;
        }

        try {
            $stmt = $db->prepare("
                INSERT INTO mobile_models (code, name, description, category_id, supplier_id, unit, unit_price, reorder_point, status, location)
                VALUES (:code, :name, :desc, :category, :supplier, :unit, :price, :reorder, :status, :location)
            ");
            $res = $stmt->execute([
                ':code' => $code,
                ':name' => $name,
                ':desc' => $desc,
                ':category' => $category,
                ':supplier' => $supplier,
                ':unit' => $unit,
                ':price' => $price,
                ':reorder' => $reorder,
                ':status' => $status,
                ':location' => $location
            ]);
            if ($res) {
                logActivity($userId, 'CREATE_MODEL', "Created model: $name", 'Inventory');
                echo json_encode(['success' => true, 'message' => 'Model created successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create model']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // UPDATE
    if ($action === 'update') {
        $id = intval($_POST['id']);
        $code = sanitize($_POST['code']);
        $name = sanitize($_POST['name']);
        $desc = sanitize($_POST['description']);
        $category = sanitize($_POST['category_id']);
        $supplier = sanitize($_POST['supplier_id']);
        $unit = sanitize($_POST['unit']);
        $price = sanitize($_POST['unit_price']);
        $reorder = sanitize($_POST['reorder_point']);
        $status = sanitize($_POST['status']);
        $location = sanitize($_POST['location']);

        if (empty($code) || empty($name) || empty($category)) {
            echo json_encode(['success' => false, 'message' => 'Code, Name, and Category are required']);
            exit;
        }

        try {
            $stmt = $db->prepare("
                UPDATE mobile_models
                SET code = :code,
                    name = :name,
                    description = :desc,
                    category_id = :category,
                    supplier_id = :supplier,
                    unit = :unit,
                    unit_price = :price,
                    reorder_point = :reorder,
                    status = :status,
                    location = :location
                WHERE id = :id
            ");
            $res = $stmt->execute([
                ':code' => $code,
                ':name' => $name,
                ':desc' => $desc,
                ':category' => $category,
                ':supplier' => $supplier,
                ':unit' => $unit,
                ':price' => $price,
                ':reorder' => $reorder,
                ':status' => $status,
                ':location' => $location,
                ':id' => $id
            ]);
            if ($res) {
                logActivity($userId, 'UPDATE_MODEL', "Updated model: $name", 'Inventory');
                echo json_encode(['success' => true, 'message' => 'Model updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update model']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // DELETE
    if ($action === 'delete') {
        $id = intval($_POST['id']);
        try {
            $stmt = $db->prepare("DELETE FROM mobile_models WHERE id = :id");
            $res = $stmt->execute([':id' => $id]);
            if ($res && $stmt->rowCount() > 0) {
                logActivity($userId, 'DELETE_MODEL', "Deleted model ID: $id", 'Inventory');
                echo json_encode(['success' => true, 'message' => 'Model deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Model not found']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>