<?php
require_once '../config/config.php';
requireLogin();

// Allow Manager and Storekeeper
if (!hasRole('manager') && !hasRole('store_keeper')) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$db = getDB();
header('Content-Type: application/json');

$type = isset($_GET['type']) ? $_GET['type'] : '';

try {
    switch ($type) {
        case 'stock':
            $stmt = $db->query("
                SELECT m.*, c.name as category_name
                FROM mobile_models m
                LEFT JOIN categories c ON m.category_id = c.id
                WHERE m.status = 'active'
                ORDER BY m.name
            ");
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'movement':
            $stmt = $db->query("
                SELECT st.*, m.name as model_name
                FROM stock_transactions st
                LEFT JOIN mobile_models m ON st.model_id = m.id
                ORDER BY st.transaction_date DESC
                LIMIT 200
            ");
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'supplier':
            $stmt = $db->query("
                SELECT s.*,
                       COUNT(m.id) as total_models,
                       COALESCE(SUM(m.current_stock * m.unit_price), 0) as total_value
                FROM suppliers s
                LEFT JOIN mobile_models m ON s.id = m.supplier_id
                WHERE s.status = 'active'
                GROUP BY s.id
                ORDER BY s.name
            ");
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'low_stock':
            $stmt = $db->query("
                SELECT m.*, c.name as category_name
                FROM mobile_models m
                LEFT JOIN categories c ON m.category_id = c.id
                WHERE m.current_stock <= m.reorder_point AND m.status = 'active'
                ORDER BY m.current_stock ASC
            ");
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Invalid report type']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
exit;