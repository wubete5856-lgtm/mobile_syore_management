<?php
require_once '../config/config.php';
requireRole('admin');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$db = getDB();
header('Content-Type: application/json');

// =============================================
// GET: List all users (excluding admin)
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $db->query("SELECT id, username, full_name, role, status FROM users WHERE username != 'admin' ORDER BY id DESC");
        $users = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $users]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// =============================================
// POST: Reset user password
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $newPassword = $_POST['password'];
    $adminId = $_SESSION['user_id'];

    if ($id <= 0 || empty($newPassword) || strlen($newPassword) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
        exit;
    }

    try {
        $stmt = $db->prepare("SELECT username, role FROM users WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $user = $stmt->fetch();
        if (!$user || $user['role'] === 'admin') {
            echo json_encode(['success' => false, 'message' => 'Invalid user or cannot reset admin password']);
            exit;
        }

        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET password = :password WHERE id = :id");
        $res = $stmt->execute([':password' => $hashed, ':id' => $id]);
        if ($res) {
            logActivity($adminId, 'ADMIN_RESET_PASSWORD', "Reset password for user: " . $user['username'] . " (ID: $id)", 'Password Reset');
            echo json_encode(['success' => true, 'message' => 'Password reset successfully for ' . $user['username']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to reset password']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}
?>