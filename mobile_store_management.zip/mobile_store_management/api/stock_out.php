<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

// GET: Pending requests, approved requests, history...
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $status = isset($_GET['status']) ? $_GET['status'] : '';
    $history = isset($_GET['history']) ? 1 : 0;

    // Pending (for Manager)
    if ($status === 'pending') {
        $stmt = $db->query("
            SELECT so.*, m.name as model_name, u.full_name
            FROM stock_transactions so
            LEFT JOIN mobile_models m ON so.model_id = m.id
            LEFT JOIN users u ON so.user_id = u.id
            WHERE so.transaction_type = 'OUT' AND so.status = 'PENDING'
            ORDER BY so.transaction_date DESC
        ");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
        exit;
    }

    // Approved (for Storekeeper)
    if ($status === 'approved') {
        $stmt = $db->query("
            SELECT so.*, m.name as model_name, u.full_name
            FROM stock_transactions so
            LEFT JOIN mobile_models m ON so.model_id = m.id
            LEFT JOIN users u ON so.user_id = u.id
            WHERE so.transaction_type = 'OUT' AND so.status = 'APPROVED'
            ORDER BY so.transaction_date ASC
        ");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
        exit;
    }

    // History (all)
    if ($history) {
        $stmt = $db->query("
            SELECT so.*, m.name as model_name, u.full_name, a.full_name as approved_by_name
            FROM stock_transactions so
            LEFT JOIN mobile_models m ON so.model_id = m.id
            LEFT JOIN users u ON so.user_id = u.id
            LEFT JOIN users a ON so.approved_by = a.id
            WHERE so.transaction_type = 'OUT'
            ORDER BY so.transaction_date DESC
            LIMIT 50
        ");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
        exit;
    }

    // Default
    $stmt = $db->query("
        SELECT so.*, m.name as model_name
        FROM stock_transactions so
        LEFT JOIN mobile_models m ON so.model_id = m.id
        WHERE so.transaction_type = 'OUT'
        ORDER BY so.transaction_date DESC
        LIMIT 20
    ");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
    exit;
}

// POST: Create, Approve, Reject, Fulfill
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $userId = getValidUserId();

    // Create new request (Employee)
    if ($action === '' || $action === 'create') {
        $model = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
        $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
        $department = isset($_POST['department']) ? trim($_POST['department']) : '';
        $employee = isset($_POST['employee']) ? trim($_POST['employee']) : '';
        $purpose = isset($_POST['purpose']) ? trim($_POST['purpose']) : '';

        if ($model <= 0 || $qty <= 0) {
            echo json_encode(['success' => false, 'message' => 'Model and Quantity are required']);
            exit;
        }

        // Check stock (just to warn, but we won't block)
        $stmt = $db->prepare("SELECT current_stock FROM mobile_models WHERE id = :id");
        $stmt->execute([':id' => $model]);
        $stock = $stmt->fetchColumn();
        if ($stock === false) {
            echo json_encode(['success' => false, 'message' => 'Model not found']);
            exit;
        }

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("
                INSERT INTO stock_transactions
                (transaction_type, model_id, quantity, user_id, department, employee_name, purpose, status)
                VALUES ('OUT', :model, :qty, :user, :dept, :emp, :purpose, 'PENDING')
            ");
            $stmt->execute([
                ':model' => $model,
                ':qty' => $qty,
                ':user' => $userId,
                ':dept' => $department,
                ':emp' => $employee,
                ':purpose' => $purpose
            ]);

            $db->commit();

            logActivity($userId ?? 0, 'STOCK_OUT_REQUEST', "Requested $qty of model ID $model", 'Stock');
            echo json_encode(['success' => true, 'message' => 'Request submitted for approval']);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Approve (Manager) – only changes status, NO stock deduction
    if ($action === 'approve') {
        if (!hasRole('admin') && !hasRole('manager')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit;
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid request ID']);
            exit;
        }

        try {
            $db->beginTransaction();

            // Get request details (check if pending)
            $stmt = $db->prepare("SELECT model_id, quantity FROM stock_transactions WHERE id = :id AND transaction_type = 'OUT' AND status = 'PENDING'");
            $stmt->execute([':id' => $id]);
            $request = $stmt->fetch();
            if (!$request) {
                echo json_encode(['success' => false, 'message' => 'Request not found or already processed']);
                exit;
            }

            // Update status to APPROVED (stock NOT deducted)
            $stmt = $db->prepare("
                UPDATE stock_transactions
                SET status = 'APPROVED', approved_by = :approved, approved_at = NOW()
                WHERE id = :id
            ");
            $stmt->execute([':approved' => $userId, ':id' => $id]);

            $db->commit();

            logActivity($userId ?? 0, 'STOCK_OUT_APPROVE', "Approved request ID $id", 'Stock');
            echo json_encode(['success' => true, 'message' => 'Request approved – waiting for storekeeper to fulfill']);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Reject (Manager)
    if ($action === 'reject') {
        if (!hasRole('admin') && !hasRole('manager')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit;
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';

        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid request ID']);
            exit;
        }

        try {
            $stmt = $db->prepare("
                UPDATE stock_transactions
                SET status = 'REJECTED', approved_by = :approved, notes = :reason
                WHERE id = :id AND transaction_type = 'OUT' AND status = 'PENDING'
            ");
            $res = $stmt->execute([
                ':approved' => $userId,
                ':reason' => $reason,
                ':id' => $id
            ]);
            if ($res && $stmt->rowCount() > 0) {
                logActivity($userId ?? 0, 'STOCK_OUT_REJECT', "Rejected request ID $id", 'Stock');
                echo json_encode(['success' => true, 'message' => 'Request rejected']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Request not found or already processed']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Fulfill (Storekeeper) – deduct stock and set COMPLETED
    if ($action === 'fulfill') {
        if (!hasRole('store_keeper')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized: Only Storekeeper can fulfill requests']);
            exit;
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid request ID']);
            exit;
        }

        try {
            $db->beginTransaction();

            // Get approved request
            $stmt = $db->prepare("
                SELECT model_id, quantity FROM stock_transactions 
                WHERE id = :id AND transaction_type = 'OUT' AND status = 'APPROVED'
            ");
            $stmt->execute([':id' => $id]);
            $request = $stmt->fetch();
            if (!$request) {
                echo json_encode(['success' => false, 'message' => 'Request not found or not approved']);
                exit;
            }

            // Check stock
            $stmt = $db->prepare("SELECT current_stock FROM mobile_models WHERE id = :id");
            $stmt->execute([':id' => $request['model_id']]);
            $stock = $stmt->fetchColumn();
            if ($stock < $request['quantity']) {
                echo json_encode(['success' => false, 'message' => 'Insufficient stock to fulfill']);
                $db->rollBack();
                exit;
            }

            // Update status to COMPLETED
            $stmt = $db->prepare("
                UPDATE stock_transactions
                SET status = 'COMPLETED', approved_by = :approved
                WHERE id = :id
            ");
            $stmt->execute([':approved' => $userId, ':id' => $id]);

            // Deduct stock
            $stmt = $db->prepare("UPDATE mobile_models SET current_stock = current_stock - :qty WHERE id = :model");
            $stmt->execute([':qty' => $request['quantity'], ':model' => $request['model_id']]);

            $db->commit();

            logActivity($userId ?? 0, 'STOCK_OUT_FULFILL', "Fulfilled request ID $id", 'Stock');
            echo json_encode(['success' => true, 'message' => 'Request fulfilled – stock deducted']);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }
}
?>