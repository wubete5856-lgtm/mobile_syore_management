<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');
$userId = $_SESSION['user_id'];

// =============================================
// GET: Fetch user profile
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $db->prepare("
        SELECT id, username, email, full_name, department, role, created_at, last_login
        FROM users
        WHERE id = :id
    ");
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();
    
    if ($user) {
        echo json_encode(['success' => true, 'data' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
    exit;
}

// =============================================
// POST: Update user profile
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $department = sanitize($_POST['department']);
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';

    // Validate
    if (empty($full_name)) {
        echo json_encode(['success' => false, 'message' => 'Full name is required']);
        exit;
    }

    try {
        // Check if email exists for another user
        if (!empty($email)) {
            $stmt = $db->prepare("SELECT id FROM users WHERE email = :email AND id != :id");
            $stmt->execute([':email' => $email, ':id' => $userId]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Email already in use by another user']);
                exit;
            }
        }

        // Update profile
        if (!empty($new_password)) {
            // Validate password strength
            if (strlen($new_password) < 6) {
                echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
                exit;
            }
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $stmt = $db->prepare("
                UPDATE users
                SET full_name = :full_name,
                    email = :email,
                    department = :department,
                    password = :password
                WHERE id = :id
            ");
            $result = $stmt->execute([
                ':full_name' => $full_name,
                ':email' => $email,
                ':department' => $department,
                ':password' => $hashed_password,
                ':id' => $userId
            ]);
        } else {
            $stmt = $db->prepare("
                UPDATE users
                SET full_name = :full_name,
                    email = :email,
                    department = :department
                WHERE id = :id
            ");
            $result = $stmt->execute([
                ':full_name' => $full_name,
                ':email' => $email,
                ':department' => $department,
                ':id' => $userId
            ]);
        }

        if ($result) {
            // Update session with new name
            $_SESSION['full_name'] = $full_name;
            
            logActivity($userId, 'UPDATE_PROFILE', 'Updated profile information', 'Profile');
            echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update profile']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// Invalid method
echo json_encode(['success' => false, 'message' => 'Invalid request method']);
?>