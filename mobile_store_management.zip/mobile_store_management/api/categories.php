<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../config/config.php';
requireRole('admin');

$db = getDB();
header('Content-Type: application/json');

// ========== GET ==========
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id > 0) {
            $stmt = $db->prepare("SELECT * FROM categories WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $category = $stmt->fetch();
            echo json_encode(['success' => true, 'data' => $category]);
        } else {
            $stmt = $db->query("
                SELECT c.*, p.name as parent_name
                FROM categories c
                LEFT JOIN categories p ON c.parent_id = p.id
                ORDER BY c.name ASC
            ");
            $categories = $stmt->fetchAll();
            echo json_encode(['success' => true, 'data' => $categories]);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// ========== POST ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $userId = $_SESSION['user_id'];

    // CREATE
    if ($action === 'create') {
        $name = isset($_POST['name']) ? trim($_POST['name']) : '';
        $desc = isset($_POST['description']) ? trim($_POST['description']) : '';
        $parent = isset($_POST['parent_id']) && !empty($_POST['parent_id']) ? intval($_POST['parent_id']) : null;
        $status = isset($_POST['status']) ? $_POST['status'] : 'active';

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Category name is required']);
            exit;
        }

        try {
            $stmt = $db->prepare("
                INSERT INTO categories (name, description, parent_id, status)
                VALUES (:name, :desc, :parent, :status)
            ");
            $res = $stmt->execute([
                ':name' => $name,
                ':desc' => $desc,
                ':parent' => $parent,
                ':status' => $status
            ]);
            if ($res) {
                logActivity($userId, 'CREATE_CATEGORY', "Created category: $name", 'Categories');
                echo json_encode(['success' => true, 'message' => 'Category created successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to insert category']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // UPDATE
    if ($action === 'update') {
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $name = isset($_POST['name']) ? trim($_POST['name']) : '';
        $desc = isset($_POST['description']) ? trim($_POST['description']) : '';
        $parent = isset($_POST['parent_id']) && !empty($_POST['parent_id']) ? intval($_POST['parent_id']) : null;
        $status = isset($_POST['status']) ? $_POST['status'] : 'active';

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Category name is required']);
            exit;
        }
        if ($parent == $id) {
            echo json_encode(['success' => false, 'message' => 'A category cannot be its own parent']);
            exit;
        }

        try {
            $stmt = $db->prepare("
                UPDATE categories
                SET name = :name,
                    description = :desc,
                    parent_id = :parent,
                    status = :status
                WHERE id = :id
            ");
            $res = $stmt->execute([
                ':name' => $name,
                ':desc' => $desc,
                ':parent' => $parent,
                ':status' => $status,
                ':id' => $id
            ]);
            if ($res) {
                logActivity($userId, 'UPDATE_CATEGORY', "Updated category: $name", 'Categories');
                echo json_encode(['success' => true, 'message' => 'Category updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update category']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // DELETE
    if ($action === 'delete') {
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        try {
            $stmt = $db->prepare("SELECT COUNT(*) FROM categories WHERE parent_id = :id");
            $stmt->execute([':id' => $id]);
            if ($stmt->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'message' => 'Cannot delete: has sub-categories']);
                exit;
            }
            $stmt = $db->prepare("SELECT COUNT(*) FROM mobile_models WHERE category_id = :id");
            $stmt->execute([':id' => $id]);
            if ($stmt->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'message' => 'Cannot delete: category has devices assigned']);
                exit;
            }
            $stmt = $db->prepare("DELETE FROM categories WHERE id = :id");
            $res = $stmt->execute([':id' => $id]);
            if ($res && $stmt->rowCount() > 0) {
                logActivity($userId, 'DELETE_CATEGORY', "Deleted category ID: $id", 'Categories');
                echo json_encode(['success' => true, 'message' => 'Category deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Category not found']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>