<?php require_once '../config/config.php'; header('Content-Type: application/json');
$db = getDB();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    if ($action === 'login') {
        $username = sanitize($_POST['username']);
        $password = $_POST['password'];
        $stmt = $db->prepare("SELECT * FROM users WHERE username = :username AND status = 'active'");
        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $stmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
            $stmt->execute([':id' => $user['id']]);
            logActivity($user['id'], 'LOGIN', 'User logged in', 'Authentication');
            echo json_encode(['success' => true, 'message' => 'Login successful!', 'role' => $user['role']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
        }
    }
    if ($action === 'logout') {
        if (isset($_SESSION['user_id'])) logActivity($_SESSION['user_id'], 'LOGOUT', 'User logged out', 'Authentication');
        session_destroy();
        echo json_encode(['success' => true]);
    }
}
?>