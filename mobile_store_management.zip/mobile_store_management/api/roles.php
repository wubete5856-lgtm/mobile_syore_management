<?php
require_once '../config/config.php';
requireRole('admin');

$db = getDB();
header('Content-Type: application/json');

// GET: Fetch roles
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($id > 0) {
        $stmt = $db->prepare("SELECT * FROM roles WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $role = $stmt->fetch();
        if ($role) {
            echo json_encode(['success' => true, 'data' => $role]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Role not found']);
        }
        exit;
    }
    $stmt = $db->query("SELECT * FROM roles ORDER BY id");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
    exit;
}

// POST: Create, Update, Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $userId = $_SESSION['user_id'];

    // ===== CREATE =====
    if ($action === 'create') {
        $name = sanitize($_POST['name']);
        $description = sanitize($_POST['description']);
        $permissions = isset($_POST['permissions']) ? $_POST['permissions'] : '{}';

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Role name is required']);
            exit;
        }

        try {
            $stmt = $db->prepare("INSERT INTO roles (role_name, description, permissions) VALUES (:name, :desc, :perms)");
            $res = $stmt->execute([':name' => $name, ':desc' => $description, ':perms' => $permissions]);
            if ($res) {
                logActivity($userId, 'CREATE_ROLE', "Created role: $name", 'Roles');
                echo json_encode(['success' => true, 'message' => 'Role created successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create role']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== UPDATE =====
    if ($action === 'update') {
        $id = intval($_POST['id']);
        $name = sanitize($_POST['name']);
        $description = sanitize($_POST['description']);
        $permissions = isset($_POST['permissions']) ? $_POST['permissions'] : '{}';

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Role name is required']);
            exit;
        }

        try {
            $stmt = $db->prepare("UPDATE roles SET role_name = :name, description = :desc, permissions = :perms WHERE id = :id");
            $res = $stmt->execute([':name' => $name, ':desc' => $description, ':perms' => $permissions, ':id' => $id]);
            if ($res) {
                logActivity($userId, 'UPDATE_ROLE', "Updated role: $name (ID: $id)", 'Roles');
                echo json_encode(['success' => true, 'message' => 'Role updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update role']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== DELETE =====
    if ($action === 'delete') {
        $id = intval($_POST['id']);

        // Prevent deletion of system roles
        $stmt = $db->prepare("SELECT role_name FROM roles WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $role = $stmt->fetch();
        if (!$role) {
            echo json_encode(['success' => false, 'message' => 'Role not found']);
            exit;
        }
        if (in_array($role['role_name'], ['admin', 'manager', 'store_keeper'])) {
            echo json_encode(['success' => false, 'message' => 'Cannot delete system roles']);
            exit;
        }

        try {
            $stmt = $db->prepare("DELETE FROM roles WHERE id = :id");
            $res = $stmt->execute([':id' => $id]);
            if ($res && $stmt->rowCount() > 0) {
                logActivity($userId, 'DELETE_ROLE', "Deleted role: " . $role['role_name'] . " (ID: $id)", 'Roles');
                echo json_encode(['success' => true, 'message' => 'Role deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete role']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>