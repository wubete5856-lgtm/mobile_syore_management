<?php
require_once '../config/config.php';
requireRole('admin');

$db = getDB();
header('Content-Type: application/json');

// =============================================
// GET: Fetch users (single or all)
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    if ($id > 0) {
        $stmt = $db->prepare("
            SELECT id, username, email, full_name, department, role, status, created_at, last_login
            FROM users
            WHERE id = :id
        ");
        $stmt->execute([':id' => $id]);
        $user = $stmt->fetch();
        if ($user) {
            echo json_encode(['success' => true, 'data' => $user]);
        } else {
            echo json_encode(['success' => false, 'message' => 'User not found']);
        }
        exit;
    }

    // Get all users
    $stmt = $db->query("
        SELECT id, username, email, full_name, department, role, status, created_at, last_login
        FROM users
        ORDER BY id DESC
    ");
    $users = $stmt->fetchAll();
    echo json_encode(['success' => true, 'data' => $users]);
    exit;
}

// =============================================
// POST: Create, Update, Delete
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $userId = $_SESSION['user_id'];

    // ===== CREATE =====
    if ($action === 'create') {
        $username = sanitize($_POST['username']);
        $full_name = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        $password = $_POST['password'];
        $role = sanitize($_POST['role']);
        $status = sanitize($_POST['status']);

        if (empty($username)) {
            echo json_encode(['success' => false, 'message' => 'Username is required']);
            exit;
        }
        if (empty($full_name)) {
            echo json_encode(['success' => false, 'message' => 'Full name is required']);
            exit;
        }
        if (empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Password is required for new users']);
            exit;
        }
        if (strlen($password) < 6) {
            echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
            exit;
        }

        // Check username exists
        $stmt = $db->prepare("SELECT id FROM users WHERE username = :username");
        $stmt->execute([':username' => $username]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Username already exists']);
            exit;
        }

        // Check email exists
        if (!empty($email)) {
            $stmt = $db->prepare("SELECT id FROM users WHERE email = :email");
            $stmt->execute([':email' => $email]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Email already in use']);
                exit;
            }
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $db->prepare("
                INSERT INTO users (username, password, email, full_name, role, status)
                VALUES (:username, :password, :email, :full_name, :role, :status)
            ");
            $res = $stmt->execute([
                ':username' => $username,
                ':password' => $hashedPassword,
                ':email' => $email,
                ':full_name' => $full_name,
                ':role' => $role,
                ':status' => $status
            ]);
            if ($res) {
                logActivity($userId, 'CREATE_USER', "Created user: $username", 'User Management');
                echo json_encode(['success' => true, 'message' => 'User created successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create user']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== UPDATE =====
    if ($action === 'update') {
        $id = intval($_POST['id']);
        $username = sanitize($_POST['username']);
        $full_name = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        $password = $_POST['password'];
        $role = sanitize($_POST['role']);
        $status = sanitize($_POST['status']);

        if (empty($username)) {
            echo json_encode(['success' => false, 'message' => 'Username is required']);
            exit;
        }
        if (empty($full_name)) {
            echo json_encode(['success' => false, 'message' => 'Full name is required']);
            exit;
        }

        // Check if username exists for another user
        $stmt = $db->prepare("SELECT id FROM users WHERE username = :username AND id != :id");
        $stmt->execute([':username' => $username, ':id' => $id]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Username already exists']);
            exit;
        }

        if (!empty($email)) {
            $stmt = $db->prepare("SELECT id FROM users WHERE email = :email AND id != :id");
            $stmt->execute([':email' => $email, ':id' => $id]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Email already in use']);
                exit;
            }
        }

        try {
            if (!empty($password)) {
                if (strlen($password) < 6) {
                    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
                    exit;
                }
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("
                    UPDATE users
                    SET username = :username,
                        full_name = :full_name,
                        email = :email,
                        password = :password,
                        role = :role,
                        status = :status
                    WHERE id = :id
                ");
                $res = $stmt->execute([
                    ':username' => $username,
                    ':full_name' => $full_name,
                    ':email' => $email,
                    ':password' => $hashedPassword,
                    ':role' => $role,
                    ':status' => $status,
                    ':id' => $id
                ]);
            } else {
                // Update without changing password
                $stmt = $db->prepare("
                    UPDATE users
                    SET username = :username,
                        full_name = :full_name,
                        email = :email,
                        role = :role,
                        status = :status
                    WHERE id = :id
                ");
                $res = $stmt->execute([
                    ':username' => $username,
                    ':full_name' => $full_name,
                    ':email' => $email,
                    ':role' => $role,
                    ':status' => $status,
                    ':id' => $id
                ]);
            }
            if ($res) {
                logActivity($userId, 'UPDATE_USER', "Updated user: $username (ID: $id)", 'User Management');
                echo json_encode(['success' => true, 'message' => 'User updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update user']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== DELETE =====
    if ($action === 'delete') {
        $id = intval($_POST['id']);

        if ($id == $_SESSION['user_id']) {
            echo json_encode(['success' => false, 'message' => 'Cannot delete your own account']);
            exit;
        }

        $stmt = $db->prepare("SELECT username FROM users WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $user = $stmt->fetch();
        if (!$user) {
            echo json_encode(['success' => false, 'message' => 'User not found']);
            exit;
        }
        if ($user['username'] === 'admin') {
            echo json_encode(['success' => false, 'message' => 'Cannot delete system admin']);
            exit;
        }

        try {
            $stmt = $db->prepare("DELETE FROM users WHERE id = :id");
            $res = $stmt->execute([':id' => $id]);
            if ($res && $stmt->rowCount() > 0) {
                logActivity($userId, 'DELETE_USER', "Deleted user: " . $user['username'] . " (ID: $id)", 'User Management');
                echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>