<?php
require_once '../config/config.php';
requireRole('admin');

$db = getDB();
header('Content-Type: application/json');

// Backup directory
$backupDir = __DIR__ . '/../backups/';
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0777, true);
}

// =============================================
// GET: List backups or download
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = isset($_GET['action']) ? $_GET['action'] : 'list';

    // Download backup file
    if ($action === 'download') {
        $filename = isset($_GET['filename']) ? basename($_GET['filename']) : '';
        if (empty($filename)) {
            echo json_encode(['success' => false, 'message' => 'No filename specified']);
            exit;
        }

        $filepath = $backupDir . $filename;
        if (!file_exists($filepath)) {
            echo json_encode(['success' => false, 'message' => 'File not found']);
            exit;
        }

        // Force download
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    }

    // List backups
    $files = glob($backupDir . 'backup_*.sql');
    $backups = [];
    foreach ($files as $file) {
        $backups[] = [
            'filename' => basename($file),
            'size' => filesize($file),
            'created' => filemtime($file)
        ];
    }
    // Sort by date (newest first)
    usort($backups, function($a, $b) {
        return $b['created'] - $a['created'];
    });
    echo json_encode(['success' => true, 'data' => $backups]);
    exit;
}

// =============================================
// POST: Create, Restore, Delete
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $userId = $_SESSION['user_id'];

    // ===== CREATE BACKUP (WITHOUT mysqldump) =====
    if ($action === 'create') {
        try {
            $filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
            $filepath = $backupDir . $filename;

            // Build SQL dump using PDO (no mysqldump required)
            $sql = "-- Backup created on " . date('Y-m-d H:i:s') . "\n\n";
            $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

            // Get all tables
            $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            if (empty($tables)) {
                throw new Exception('No tables found in database');
            }

            foreach ($tables as $table) {
                // Drop table
                $sql .= "DROP TABLE IF EXISTS `{$table}`;\n";
                // Create table
                $stmt = $db->query("SHOW CREATE TABLE `{$table}`");
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $sql .= $row['Create Table'] . ";\n\n";

                // Insert data
                $rows = $db->query("SELECT * FROM `{$table}`")->fetchAll();
                if ($rows) {
                    foreach ($rows as $row) {
                        $values = array_map(function($v) use ($db) {
                            if ($v === null) return 'NULL';
                            return $db->quote($v);
                        }, (array)$row);
                        $sql .= "INSERT INTO `{$table}` VALUES (" . implode(',', $values) . ");\n";
                    }
                    $sql .= "\n";
                }
            }
            $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";

            // Write to file
            if (file_put_contents($filepath, $sql) === false) {
                throw new Exception('Failed to write backup file. Check folder permissions.');
            }

            if (file_exists($filepath) && filesize($filepath) > 0) {
                logActivity($userId, 'CREATE_BACKUP', "Created backup: $filename", 'Backup');
                echo json_encode(['success' => true, 'message' => "Backup created: $filename (Size: " . round(filesize($filepath)/1024, 2) . " KB)"]);
            } else {
                throw new Exception('Backup file is empty or was not created');
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== RESTORE BACKUP =====
    if ($action === 'restore') {
        $filename = isset($_POST['filename']) ? basename($_POST['filename']) : '';
        if (empty($filename)) {
            echo json_encode(['success' => false, 'message' => 'No filename specified']);
            exit;
        }

        $filepath = $backupDir . $filename;
        if (!file_exists($filepath)) {
            echo json_encode(['success' => false, 'message' => 'Backup file not found']);
            exit;
        }

        try {
            $sql = file_get_contents($filepath);
            if (empty($sql)) {
                throw new Exception('Backup file is empty');
            }

            // Disable foreign key checks
            $db->exec("SET FOREIGN_KEY_CHECKS=0");

            // Execute SQL statements (split by semicolon)
            $statements = explode(";\n", $sql);
            $errorCount = 0;
            foreach ($statements as $stmt) {
                $stmt = trim($stmt);
                if (!empty($stmt)) {
                    try {
                        $db->exec($stmt);
                    } catch (PDOException $e) {
                        $errorCount++;
                        // Continue with next statement (don't stop on minor errors)
                    }
                }
            }

            // Enable foreign key checks
            $db->exec("SET FOREIGN_KEY_CHECKS=1");

            $message = 'Database restored successfully from: ' . $filename;
            if ($errorCount > 0) {
                $message .= ' (with ' . $errorCount . ' warnings)';
            }
            logActivity($userId, 'RESTORE_BACKUP', "Restored backup: $filename", 'Backup');
            echo json_encode(['success' => true, 'message' => $message]);
        } catch (Exception $e) {
            $db->exec("SET FOREIGN_KEY_CHECKS=1");
            echo json_encode(['success' => false, 'message' => 'Restore failed: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== DELETE BACKUP =====
    if ($action === 'delete') {
        $filename = isset($_POST['filename']) ? basename($_POST['filename']) : '';
        if (empty($filename)) {
            echo json_encode(['success' => false, 'message' => 'No filename specified']);
            exit;
        }

        $filepath = $backupDir . $filename;
        if (!file_exists($filepath)) {
            echo json_encode(['success' => false, 'message' => 'File not found']);
            exit;
        }

        if (unlink($filepath)) {
            logActivity($userId, 'DELETE_BACKUP', "Deleted backup: $filename", 'Backup');
            echo json_encode(['success' => true, 'message' => 'Backup deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete backup']);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>