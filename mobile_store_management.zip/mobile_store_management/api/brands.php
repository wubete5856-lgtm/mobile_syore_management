<?php
require_once '../config/config.php';
requireLogin(); // All logged-in users can manage brands

$db = getDB();
header('Content-Type: application/json');

// Enable error logging for debugging
error_log("Brands API called with method: " . $_SERVER['REQUEST_METHOD']);

// =============================================
// GET: Fetch brands (single or all)
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    if ($id > 0) {
        $stmt = $db->prepare("SELECT * FROM brands WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $brand = $stmt->fetch();
        if ($brand) {
            echo json_encode(['success' => true, 'data' => $brand]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Brand not found']);
        }
        exit;
    }

    // Get all brands
    try {
        $stmt = $db->query("SELECT * FROM brands ORDER BY name ASC");
        $brands = $stmt->fetchAll();
        error_log("Found " . count($brands) . " brands");
        echo json_encode(['success' => true, 'data' => $brands]);
    } catch (PDOException $e) {
        error_log("GET brands error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// =============================================
// POST: Create, Update, Delete
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    error_log("POST action: " . $action);
    $userId = $_SESSION['user_id'];

    // ===== CREATE =====
    if ($action === 'create') {
        $name = sanitize($_POST['name']);
        $description = sanitize($_POST['description']);
        $status = sanitize($_POST['status']);

        error_log("Creating brand: name=$name, status=$status");

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Brand name is required']);
            exit;
        }

        try {
            // Check if brand already exists
            $check = $db->prepare("SELECT id FROM brands WHERE name = :name");
            $check->execute([':name' => $name]);
            if ($check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Brand "' . $name . '" already exists']);
                exit;
            }

            $stmt = $db->prepare("
                INSERT INTO brands (name, description, status)
                VALUES (:name, :description, :status)
            ");
            $res = $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':status' => $status
            ]);

            if ($res) {
                $newId = $db->lastInsertId();
                logActivity($userId, 'CREATE_BRAND', "Created brand: $name (ID: $newId)", 'Brands');
                error_log("Brand created successfully: ID $newId");
                echo json_encode(['success' => true, 'message' => 'Brand created successfully']);
            } else {
                error_log("Failed to create brand");
                echo json_encode(['success' => false, 'message' => 'Failed to create brand']);
            }
        } catch (PDOException $e) {
            error_log("CREATE brand error: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== UPDATE =====
    if ($action === 'update') {
        $id = intval($_POST['id']);
        $name = sanitize($_POST['name']);
        $description = sanitize($_POST['description']);
        $status = sanitize($_POST['status']);

        error_log("Updating brand ID $id: name=$name, status=$status");

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Brand name is required']);
            exit;
        }

        try {
            // Check if brand exists
            $check = $db->prepare("SELECT id FROM brands WHERE id = :id");
            $check->execute([':id' => $id]);
            if (!$check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Brand not found']);
                exit;
            }

            // Check duplicate name (excluding self)
            $check = $db->prepare("SELECT id FROM brands WHERE name = :name AND id != :id");
            $check->execute([':name' => $name, ':id' => $id]);
            if ($check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Brand "' . $name . '" already exists']);
                exit;
            }

            $stmt = $db->prepare("
                UPDATE brands
                SET name = :name,
                    description = :description,
                    status = :status
                WHERE id = :id
            ");
            $res = $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':status' => $status,
                ':id' => $id
            ]);

            if ($res) {
                logActivity($userId, 'UPDATE_BRAND', "Updated brand: $name (ID: $id)", 'Brands');
                error_log("Brand updated successfully: ID $id");
                echo json_encode(['success' => true, 'message' => 'Brand updated successfully']);
            } else {
                error_log("Failed to update brand ID $id");
                echo json_encode(['success' => false, 'message' => 'Failed to update brand']);
            }
        } catch (PDOException $e) {
            error_log("UPDATE brand error: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // ===== DELETE =====
    if ($action === 'delete') {
        $id = intval($_POST['id']);
        error_log("Deleting brand ID: $id");

        try {
            // Check if brand exists
            $check = $db->prepare("SELECT id FROM brands WHERE id = :id");
            $check->execute([':id' => $id]);
            if (!$check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Brand not found']);
                exit;
            }

            // Check if brand is used in any mobile model
            $stmt = $db->prepare("SELECT COUNT(*) FROM mobile_models WHERE brand_id = :id");
            $stmt->execute([':id' => $id]);
            if ($stmt->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'message' => 'Cannot delete: brand has associated mobile models']);
                exit;
            }

            $stmt = $db->prepare("DELETE FROM brands WHERE id = :id");
            $res = $stmt->execute([':id' => $id]);
            if ($res && $stmt->rowCount() > 0) {
                logActivity($userId, 'DELETE_BRAND', "Deleted brand ID: $id", 'Brands');
                error_log("Brand deleted successfully: ID $id");
                echo json_encode(['success' => true, 'message' => 'Brand deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Brand could not be deleted']);
            }
        } catch (PDOException $e) {
            error_log("DELETE brand error: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action: ' . $action]);
}
?>