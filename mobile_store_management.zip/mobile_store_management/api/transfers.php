<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

// GET: Transfer history
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $db->query("
            SELECT t.*, m.name as model_name
            FROM stock_transactions t
            LEFT JOIN mobile_models m ON t.model_id = m.id
            WHERE t.transaction_type = 'TRANSFER'
            ORDER BY t.transaction_date DESC
            LIMIT 50
        ");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// POST: Create transfer
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $model = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
    $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $from = isset($_POST['from_location']) ? trim($_POST['from_location']) : '';
    $to = isset($_POST['to_location']) ? trim($_POST['to_location']) : '';
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    $userId = getValidUserId();

    if ($model <= 0 || $qty <= 0 || empty($from) || empty($to)) {
        echo json_encode(['success' => false, 'message' => 'Model, Quantity, From Location, and To Location are required']);
        exit;
    }

    // Check stock
    $stmt = $db->prepare("SELECT current_stock FROM mobile_models WHERE id = :id");
    $stmt->execute([':id' => $model]);
    $stock = $stmt->fetchColumn();
    if ($stock === false) {
        echo json_encode(['success' => false, 'message' => 'Model not found']);
        exit;
    }
    if ($stock < $qty) {
        echo json_encode(['success' => false, 'message' => 'Insufficient stock']);
        exit;
    }

    try {
        $db->beginTransaction();

        $stmt = $db->prepare("
            INSERT INTO stock_transactions
            (transaction_type, model_id, quantity, user_id, from_location, to_location, notes, status)
            VALUES ('TRANSFER', :model, :qty, :user, :from, :to, :notes, 'COMPLETED')
        ");
        $stmt->execute([
            ':model' => $model,
            ':qty' => -$qty,
            ':user' => $userId,
            ':from' => $from,
            ':to' => $to,
            ':notes' => $notes
        ]);

        $stmt = $db->prepare("UPDATE mobile_models SET current_stock = current_stock - :qty WHERE id = :model");
        $stmt->execute([':qty' => $qty, ':model' => $model]);

        $db->commit();

        logActivity($userId ?? 0, 'STOCK_TRANSFER', "Transferred $qty of model ID $model from $from to $to", 'Stock');
        echo json_encode(['success' => true, 'message' => 'Transfer completed successfully']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}