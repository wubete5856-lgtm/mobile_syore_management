<?php
require_once '../config/config.php';
requireRole('admin');
$db = getDB();
header('Content-Type: application/json');

$stmt = $db->query("
    SELECT al.*, u.full_name
    FROM audit_logs al
    LEFT JOIN users u ON al.user_id = u.id
    ORDER BY al.created_at DESC
    LIMIT 2000
");
echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
?>