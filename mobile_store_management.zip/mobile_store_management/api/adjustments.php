<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

// GET: Adjustment history
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $db->query("
            SELECT a.*, m.name as model_name
            FROM stock_transactions a
            LEFT JOIN mobile_models m ON a.model_id = m.id
            WHERE a.transaction_type = 'ADJUSTMENT'
            ORDER BY a.transaction_date DESC
            LIMIT 50
        ");
        $data = $stmt->fetchAll();
        foreach ($data as &$row) {
            if ($row['transaction_date']) {
                $row['transaction_date'] = date('Y-m-d H:i:s', strtotime($row['transaction_date']));
            }
            $row['transaction_type'] = $row['quantity'] > 0 ? 'increase' : 'decrease';
        }
        echo json_encode(['success' => true, 'data' => $data]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// POST: Create adjustment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $model = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
    $type = isset($_POST['adjustment_type']) ? $_POST['adjustment_type'] : '';
    $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
    $userId = getValidUserId();

    if ($model <= 0 || $qty <= 0 || empty($reason) || !in_array($type, ['increase', 'decrease'])) {
        echo json_encode(['success' => false, 'message' => 'Valid model, type, quantity, and reason required']);
        exit;
    }

    // Check current stock
    $stmt = $db->prepare("SELECT current_stock FROM mobile_models WHERE id = :id");
    $stmt->execute([':id' => $model]);
    $current = $stmt->fetchColumn();
    if ($current === false) {
        echo json_encode(['success' => false, 'message' => 'Model not found']);
        exit;
    }

    $actualQty = $type === 'increase' ? $qty : -$qty;
    if ($type === 'decrease' && ($current + $actualQty) < 0) {
        echo json_encode(['success' => false, 'message' => 'Insufficient stock']);
        exit;
    }

    try {
        $db->beginTransaction();

        $stmt = $db->prepare("
            INSERT INTO stock_transactions
            (transaction_type, model_id, quantity, user_id, notes, status)
            VALUES ('ADJUSTMENT', :model, :qty, :user, :reason, 'COMPLETED')
        ");
        $stmt->execute([
            ':model' => $model,
            ':qty' => $actualQty,
            ':user' => $userId,
            ':reason' => $reason
        ]);

        $stmt = $db->prepare("UPDATE mobile_models SET current_stock = current_stock + :qty WHERE id = :model");
        $stmt->execute([':qty' => $actualQty, ':model' => $model]);

        $db->commit();

        logActivity($userId ?? 0, 'STOCK_ADJUST', "Adjusted stock: $type $qty for model ID $model", 'Stock');
        echo json_encode(['success' => true, 'message' => 'Stock adjusted successfully']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}