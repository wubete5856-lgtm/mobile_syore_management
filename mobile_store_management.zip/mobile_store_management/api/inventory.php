<?php
require_once '../config/config.php';
requireLogin();

// Only Admin and Manager can access this API
if (!hasRole('admin') && !hasRole('manager')) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$db = getDB();
header('Content-Type: application/json');

try {
    $stmt = $db->query("
        SELECT m.*, c.name as category_name
        FROM mobile_models m
        LEFT JOIN categories c ON m.category_id = c.id
        WHERE m.status = 'active'
        ORDER BY m.name
    ");
    $data = $stmt->fetchAll();
    echo json_encode(['success' => true, 'data' => $data]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
exit;
?>