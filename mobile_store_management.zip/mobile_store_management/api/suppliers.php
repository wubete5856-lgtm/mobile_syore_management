<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

// GET: fetch suppliers
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id > 0) {
            $stmt = $db->prepare("SELECT * FROM suppliers WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $supplier = $stmt->fetch();
            echo json_encode(['success' => true, 'data' => $supplier]);
        } else {
            $stmt = $db->query("SELECT id, name FROM suppliers WHERE status = 'active' ORDER BY name");
            $suppliers = $stmt->fetchAll();
            echo json_encode(['success' => true, 'data' => $suppliers]);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// POST: create, update, delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $userId = $_SESSION['user_id'];

    // Create supplier
    if ($action === 'create') {
        $code = sanitize($_POST['code']);
        $name = sanitize($_POST['name']);
        $contact = sanitize($_POST['contact']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        $status = sanitize($_POST['status']);

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Supplier name is required']);
            exit;
        }

        try {
            $stmt = $db->prepare("
                INSERT INTO suppliers (code, name, contact_person, email, phone, address, status)
                VALUES (:code, :name, :contact, :email, :phone, :address, :status)
            ");
            $res = $stmt->execute([
                ':code' => $code,
                ':name' => $name,
                ':contact' => $contact,
                ':email' => $email,
                ':phone' => $phone,
                ':address' => $address,
                ':status' => $status
            ]);
            if ($res) {
                logActivity($userId, 'CREATE_SUPPLIER', "Created supplier: $name", 'Suppliers');
                echo json_encode(['success' => true, 'message' => 'Supplier created successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create supplier']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Update supplier
    if ($action === 'update') {
        $id = intval($_POST['id']);
        $code = sanitize($_POST['code']);
        $name = sanitize($_POST['name']);
        $contact = sanitize($_POST['contact']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        $status = sanitize($_POST['status']);

        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Supplier name is required']);
            exit;
        }

        try {
            $stmt = $db->prepare("
                UPDATE suppliers
                SET code = :code,
                    name = :name,
                    contact_person = :contact,
                    email = :email,
                    phone = :phone,
                    address = :address,
                    status = :status
                WHERE id = :id
            ");
            $res = $stmt->execute([
                ':code' => $code,
                ':name' => $name,
                ':contact' => $contact,
                ':email' => $email,
                ':phone' => $phone,
                ':address' => $address,
                ':status' => $status,
                ':id' => $id
            ]);
            if ($res) {
                logActivity($userId, 'UPDATE_SUPPLIER', "Updated supplier: $name", 'Suppliers');
                echo json_encode(['success' => true, 'message' => 'Supplier updated successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update supplier']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Delete supplier
    if ($action === 'delete') {
        $id = intval($_POST['id']);
        try {
            // Check if supplier is used
            $stmt = $db->prepare("SELECT COUNT(*) FROM mobile_models WHERE supplier_id = :id");
            $stmt->execute([':id' => $id]);
            if ($stmt->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'message' => 'Cannot delete: supplier has associated mobile models']);
                exit;
            }
            $stmt = $db->prepare("DELETE FROM suppliers WHERE id = :id");
            $res = $stmt->execute([':id' => $id]);
            if ($res && $stmt->rowCount() > 0) {
                logActivity($userId, 'DELETE_SUPPLIER', "Deleted supplier ID: $id", 'Suppliers');
                echo json_encode(['success' => true, 'message' => 'Supplier deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Supplier not found']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>