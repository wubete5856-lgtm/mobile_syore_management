<?php
require_once '../config/config.php';
requireLogin();
$db = getDB();
header('Content-Type: application/json');

$stmt = $db->query("
    SELECT st.*, m.name as model_name, u.full_name
    FROM stock_transactions st
    LEFT JOIN mobile_models m ON st.model_id = m.id
    LEFT JOIN users u ON st.user_id = u.id
    ORDER BY st.transaction_date DESC
    LIMIT 100
");
echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
?>