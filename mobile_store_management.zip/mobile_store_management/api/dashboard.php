<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

$stats = [];

// =============================================
// BASIC STATS
// =============================================
$stmt = $db->query("SELECT COUNT(*) as total FROM mobile_models WHERE status = 'active'");
$stats['total_models'] = $stmt->fetch()['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM brands WHERE status = 'active'");
$stats['total_brands'] = $stmt->fetch()['total'];

$stmt = $db->query("
    SELECT COUNT(*) as count, GROUP_CONCAT(name SEPARATOR ', ') as low_stock_list
    FROM mobile_models 
    WHERE current_stock <= reorder_point AND status = 'active'
");
$lowStock = $stmt->fetch();
$stats['low_stock'] = $lowStock['count'];
$stats['low_stock_list'] = $lowStock['low_stock_list'] ?: 'None';

$stmt = $db->query("SELECT COALESCE(SUM(quantity), 0) as total FROM stock_transactions WHERE transaction_type='IN' AND MONTH(transaction_date)=MONTH(CURRENT_DATE())");
$stats['stock_in_month'] = $stmt->fetch()['total'];

$stmt = $db->query("SELECT COALESCE(SUM(quantity), 0) as total FROM stock_transactions WHERE transaction_type='OUT' AND status='APPROVED' AND MONTH(transaction_date)=MONTH(CURRENT_DATE())");
$stats['stock_out_month'] = $stmt->fetch()['total'];

// =============================================
// PENDING REQUESTS (Admin & Manager)
// =============================================
if (hasRole('admin') || hasRole('manager')) {
    $stmt = $db->query("
        SELECT so.id, so.model_id, so.quantity, so.department, so.employee_name, 
               so.transaction_date, so.status, m.name as model_name, u.full_name as requested_by
        FROM stock_transactions so
        LEFT JOIN mobile_models m ON so.model_id = m.id
        LEFT JOIN users u ON so.user_id = u.id
        WHERE so.transaction_type = 'OUT' AND so.status = 'PENDING'
        ORDER BY so.transaction_date ASC
        LIMIT 10
    ");
    $stats['pending_requests'] = $stmt->fetchAll();
    $stats['pending_count'] = count($stats['pending_requests']);
}

// =============================================
// PIE CHART: Stock by Category
// =============================================
$categoryData = [];
$stmt = $db->query("
    SELECT c.name as category, COALESCE(SUM(m.current_stock), 0) as total_stock
    FROM categories c
    LEFT JOIN mobile_models m ON c.id = m.category_id AND m.status = 'active'
    GROUP BY c.id
    ORDER BY total_stock DESC
    LIMIT 6
");
$categories = $stmt->fetchAll();
$labels = [];
$data = [];
foreach ($categories as $row) {
    $labels[] = $row['category'] ?: 'Unknown';
    $data[] = (int)$row['total_stock'];
}
$stats['stock_by_category'] = ['labels' => $labels, 'data' => $data];

// =============================================
// DAILY MOVEMENT (Last 7 Days)
// =============================================
$days = [];
$inData = [];
$outData = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $days[] = date('M d', strtotime("-$i days"));
    
    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity), 0) as total FROM stock_transactions WHERE transaction_type='IN' AND DATE(transaction_date) = :date");
    $stmt->execute([':date' => $date]);
    $inData[] = (int)$stmt->fetch()['total'];
    
    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity), 0) as total FROM stock_transactions WHERE transaction_type='OUT' AND status='APPROVED' AND DATE(transaction_date) = :date");
    $stmt->execute([':date' => $date]);
    $outData[] = (int)$stmt->fetch()['total'];
}
$stats['daily_movement'] = ['labels' => $days, 'in' => $inData, 'out' => $outData];

// =============================================
// MONTHLY MOVEMENT (Backup)
// =============================================
$months = [];
$inMonthly = [];
$outMonthly = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $months[] = date('M', strtotime("-$i months"));
    
    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity), 0) as total FROM stock_transactions WHERE transaction_type='IN' AND DATE_FORMAT(transaction_date, '%Y-%m') = :month");
    $stmt->execute([':month' => $month]);
    $inMonthly[] = (int)$stmt->fetch()['total'];
    
    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity), 0) as total FROM stock_transactions WHERE transaction_type='OUT' AND status='APPROVED' AND DATE_FORMAT(transaction_date, '%Y-%m') = :month");
    $stmt->execute([':month' => $month]);
    $outMonthly[] = (int)$stmt->fetch()['total'];
}
$stats['monthly_movement'] = ['labels' => $months, 'in' => $inMonthly, 'out' => $outMonthly];

// =============================================
// RECENT TRANSACTIONS
// =============================================
$stmt = $db->query("
    SELECT st.*, m.name as model_name, u.full_name
    FROM stock_transactions st
    LEFT JOIN mobile_models m ON st.model_id = m.id
    LEFT JOIN users u ON st.user_id = u.id
    ORDER BY st.transaction_date DESC
    LIMIT 10
");
$stats['recent_transactions'] = $stmt->fetchAll();

echo json_encode($stats);
?>