<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

// GET: Return history
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $db->query("
            SELECT r.*, m.name as model_name
            FROM stock_transactions r
            LEFT JOIN mobile_models m ON r.model_id = m.id
            WHERE r.transaction_type = 'RETURN'
            ORDER BY r.transaction_date DESC
            LIMIT 50
        ");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// POST: Create return
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $model = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
    $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
    $userId = getValidUserId();

    if ($model <= 0 || $qty <= 0 || empty($reason)) {
        echo json_encode(['success' => false, 'message' => 'Model, quantity, and reason required']);
        exit;
    }

    // Check model exists
    $stmt = $db->prepare("SELECT id FROM mobile_models WHERE id = :id");
    $stmt->execute([':id' => $model]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Model not found']);
        exit;
    }

    try {
        $db->beginTransaction();

        $stmt = $db->prepare("
            INSERT INTO stock_transactions
            (transaction_type, model_id, quantity, user_id, notes, status)
            VALUES ('RETURN', :model, :qty, :user, :reason, 'COMPLETED')
        ");
        $stmt->execute([
            ':model' => $model,
            ':qty' => $qty,
            ':user' => $userId,
            ':reason' => $reason
        ]);

        $stmt = $db->prepare("UPDATE mobile_models SET current_stock = current_stock + :qty WHERE id = :model");
        $stmt->execute([':qty' => $qty, ':model' => $model]);

        $db->commit();

        logActivity($userId ?? 0, 'STOCK_RETURN', "Returned $qty of model ID $model", 'Stock');
        echo json_encode(['success' => true, 'message' => 'Return completed successfully']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}