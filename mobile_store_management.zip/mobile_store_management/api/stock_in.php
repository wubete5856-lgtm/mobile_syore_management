<?php
require_once '../config/config.php';
requireLogin();

$db = getDB();
header('Content-Type: application/json');

// GET: Stock-in history
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $db->query("
            SELECT si.*, m.name as model_name, s.name as supplier_name
            FROM stock_transactions si
            LEFT JOIN mobile_models m ON si.model_id = m.id
            LEFT JOIN suppliers s ON si.supplier_id = s.id
            WHERE si.transaction_type = 'IN'
            ORDER BY si.transaction_date DESC
            LIMIT 50
        ");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// POST: Receive stock
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $model = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
    $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $price = isset($_POST['unit_price']) ? floatval($_POST['unit_price']) : 0;
    $supplier = isset($_POST['supplier_id']) && !empty($_POST['supplier_id']) ? intval($_POST['supplier_id']) : null;
    $invoice = isset($_POST['invoice_no']) ? trim($_POST['invoice_no']) : '';
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    $userId = getValidUserId();

    // Validate
    if ($model <= 0 || $qty <= 0 || $price <= 0) {
        echo json_encode(['success' => false, 'message' => 'Model, Quantity, and Unit Price are required']);
        exit;
    }

    // Check model exists
    $stmt = $db->prepare("SELECT current_stock FROM mobile_models WHERE id = :id");
    $stmt->execute([':id' => $model]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Model not found']);
        exit;
    }

    try {
        $db->beginTransaction();

        $total = $qty * $price;
        $stmt = $db->prepare("
            INSERT INTO stock_transactions
            (transaction_type, model_id, supplier_id, quantity, unit_price, total_amount, user_id, reference_number, notes, status)
            VALUES ('IN', :model, :supplier, :qty, :price, :total, :user, :ref, :notes, 'COMPLETED')
        ");
        $stmt->execute([
            ':model' => $model,
            ':supplier' => $supplier,
            ':qty' => $qty,
            ':price' => $price,
            ':total' => $total,
            ':user' => $userId,
            ':ref' => $invoice,
            ':notes' => $notes
        ]);

        $stmt = $db->prepare("UPDATE mobile_models SET current_stock = current_stock + :qty WHERE id = :model");
        $stmt->execute([':qty' => $qty, ':model' => $model]);

        $db->commit();

        logActivity($userId ?? 0, 'STOCK_IN', "Received $qty of model ID $model", 'Stock');
        echo json_encode(['success' => true, 'message' => 'Stock received successfully']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}