<?php
require_once '../config/config.php';
requireRole('admin');
$db = getDB();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $db->query("SELECT setting_key, setting_value FROM system_settings");
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    echo json_encode(['success' => true, 'data' => $settings]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
    try {
        foreach ($data as $key => $value) {
            $stmt = $db->prepare("UPDATE system_settings SET setting_value = :value WHERE setting_key = :key");
            $stmt->execute([':key' => $key, ':value' => $value]);
        }
        logActivity($_SESSION['user_id'], 'UPDATE_SETTINGS', 'Updated system settings', 'Settings');
        echo json_encode(['success' => true, 'message' => 'Settings updated successfully']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>