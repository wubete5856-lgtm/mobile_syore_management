<?php
// =============================================
// SYSTEM FUNCTIONS
// =============================================

// Authentication functions with BASE_URL redirects
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'index.php');
        exit();
    }
}

function requireRole($role) {
    requireLogin();
    if (!hasRole($role) && !hasRole('admin')) {
        header('Location: ' . BASE_URL . 'dashboard.php');
        exit();
    }
}

function hasPermission($permission) {
    if (!isLoggedIn()) return false;
    if (hasRole('admin')) return true;
    
    $db = getDB();
    $stmt = $db->prepare("SELECT permissions FROM roles WHERE role_name = :role");
    $stmt->execute([':role' => $_SESSION['role']]);
    $result = $stmt->fetch();
    if ($result) {
        $perms = json_decode($result['permissions'], true);
        return isset($perms[$permission]) && $perms[$permission] === true;
    }
    return false;
}

// Security functions
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function generateCSRF() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Database helpers
function getSetting($key) {
    $db = getDB();
    $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = :key");
    $stmt->execute([':key' => $key]);
    $result = $stmt->fetch();
    return $result ? $result['setting_value'] : null;
}

function getCurrency() {
    return getSetting('currency_symbol') ?: '$';
}

// Logging
function logActivity($userId, $action, $description, $module = null) {
    $db = getDB();
    $stmt = $db->prepare("
        INSERT INTO audit_logs (user_id, action, module, description, ip_address, user_agent)
        VALUES (:user_id, :action, :module, :description, :ip_address, :user_agent)
    ");
    return $stmt->execute([
        ':user_id' => $userId,
        ':action' => $action,
        ':module' => $module,
        ':description' => $description,
        ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
        ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
    ]);
}

function addNotification($userId, $title, $message, $type = 'info', $link = null) {
    $db = getDB();
    $stmt = $db->prepare("
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (:user_id, :title, :message, :type, :link)
    ");
    return $stmt->execute([
        ':user_id' => $userId,
        ':title' => $title,
        ':message' => $message,
        ':type' => $type,
        ':link' => $link
    ]);
}

// Response helpers
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

function successResponse($message, $data = null) {
    return jsonResponse(['success' => true, 'message' => $message, 'data' => $data]);
}

function errorResponse($message, $data = null) {
    return jsonResponse(['success' => false, 'message' => $message, 'data' => $data], 400);
}

// Formatting
function formatCurrency($amount) {
    return getCurrency() . number_format($amount, 2);
}

function formatDate($date) {
    return date(getSetting('date_format') ?: 'Y-m-d H:i:s', strtotime($date));
}

function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff/60) . 'm ago';
    if ($diff < 86400) return floor($diff/3600) . 'h ago';
    if ($diff < 604800) return floor($diff/86400) . 'd ago';
    return date('M d, Y', $time);
}

function getStatusBadge($status) {
    $badges = [
        'active' => '<span class="badge bg-success">Active</span>',
        'inactive' => '<span class="badge bg-danger">Inactive</span>',
        'pending' => '<span class="badge bg-warning">Pending</span>',
        'approved' => '<span class="badge bg-success">Approved</span>',
        'rejected' => '<span class="badge bg-danger">Rejected</span>',
        'completed' => '<span class="badge bg-info">Completed</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-secondary">Unknown</span>';
}

function getStockStatus($current, $min) {
    if ($current <= 0) return ['class' => 'danger', 'text' => 'Out of Stock'];
    if ($current <= $min) return ['class' => 'warning', 'text' => 'Low Stock'];
    return ['class' => 'success', 'text' => 'In Stock'];
}

function paginate($total, $page, $perPage = 50) {
    $totalPages = ceil($total / $perPage);
    $page = max(1, min($page, $totalPages));
    $offset = ($page - 1) * $perPage;
    return [
        'page' => $page,
        'perPage' => $perPage,
        'total' => $total,
        'totalPages' => $totalPages,
        'offset' => $offset,
        'hasPrev' => $page > 1,
        'hasNext' => $page < $totalPages
    ];
}
// =============================================
// Helper to get a valid user ID from session
// =============================================
function getValidUserId() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    $userId = intval($_SESSION['user_id']);
    if ($userId <= 0) {
        return null;
    }
    // Verify the user exists in the database
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM users WHERE id = :id");
    $stmt->execute([':id' => $userId]);
    if ($stmt->fetch()) {
        return $userId;
    }
    return null;
}
?>