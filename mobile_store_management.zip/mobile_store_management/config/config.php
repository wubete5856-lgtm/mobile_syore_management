<?php
// =============================================
// SYSTEM CONFIGURATION
// =============================================

// Start session - MUST be first
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// Timezone
date_default_timezone_set('America/Los_Angeles');

// =============================================
// BASE URL - CHANGE THIS FOR YOUR DEPLOYMENT
// =============================================
// For localhost:
define('BASE_URL', 'http://localhost/mobile_store_management/');

// For live server (uncomment and update):
// define('BASE_URL', 'https://yourdomain.com/');

define('APP_NAME', 'Mobile Store Management System');
define('APP_VERSION', '1.0.0');

// Include dependencies
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';

// Create logs directory if not exists
if (!file_exists(__DIR__ . '/../logs')) {
    mkdir(__DIR__ . '/../logs', 0777, true);
}

// Maintenance mode check
$maintenance = getSetting('maintenance_mode');
if ($maintenance === 'true' && !isset($_SESSION['user_id'])) {
    die('<h1>System Under Maintenance</h1><p>Please try again later.</p>');
}
?>