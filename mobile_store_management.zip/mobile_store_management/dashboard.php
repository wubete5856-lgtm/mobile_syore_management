<?php require_once 'config/config.php'; requireLogin(); $role=$_SESSION['role']; $userName=$_SESSION['full_name']; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    <div class="container-fluid mt-4">
        <div class="row"><div class="col-md-12"><div class="d-flex justify-content-between align-items-center"><h2><i class="fas fa-chart-line"></i> Dashboard</h2><span class="text-muted">Welcome, <?php echo htmlspecialchars($userName); ?>!</span></div><hr></div></div>
        <div class="row" id="dashboardStats">
            <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-primary shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><i class="fas fa-mobile-alt"></i> Total Models</div><div class="h5 mb-0 font-weight-bold text-gray-800" id="totalModels">Loading...</div></div><div class="col-auto"><i class="fas fa-mobile-alt fa-2x text-gray-300"></i></div></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-danger shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-danger text-uppercase mb-1"><i class="fas fa-exclamation-triangle"></i> Low Stock</div><div class="h5 mb-0 font-weight-bold text-gray-800" id="lowStock">Loading...</div></div><div class="col-auto"><i class="fas fa-exclamation-circle fa-2x text-gray-300"></i></div></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-success shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-success text-uppercase mb-1"><i class="fas fa-arrow-down"></i> Stock In (Month)</div><div class="h5 mb-0 font-weight-bold text-gray-800" id="stockInMonth">Loading...</div></div><div class="col-auto"><i class="fas fa-arrow-down fa-2x text-gray-300"></i></div></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-warning shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-warning text-uppercase mb-1"><i class="fas fa-arrow-up"></i> Stock Out (Month)</div><div class="h5 mb-0 font-weight-bold text-gray-800" id="stockOutMonth">Loading...</div></div><div class="col-auto"><i class="fas fa-arrow-up fa-2x text-gray-300"></i></div></div></div></div></div>
        </div>
       <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-clock"></i> Recent Transactions</h6></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover"><thead><tr><th>Date</th><th>Type</th><th>Model</th><th>Quantity</th><th>Status</th></tr></thead><tbody id="recentTransactions"><tr><td colspan="5" class="text-center">Loading...</td></tr></tbody></table></div></div></div></div></div>
    <?php include 'includes/footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function(){ loadDashboardStats(); loadRecentTransactions(); });
    function loadDashboardStats() {
        $.ajax({ url: 'api/dashboard.php', type: 'GET', dataType: 'json',
            success: function(data){
                $('#totalModels').text(data.total_models||0);
                $('#lowStock').text(data.low_stock||0);
                $('#stockInMonth').text(data.stock_in_month||0);
                $('#stockOutMonth').text(data.stock_out_month||0);
            },
            error: function(){ $('#totalModels').text('Error'); $('#lowStock').text('Error'); $('#stockInMonth').text('Error'); $('#stockOutMonth').text('Error'); }
        });
    }
    function loadRecentTransactions() {
        $.ajax({ url: 'api/dashboard.php', type: 'GET', dataType: 'json',
            success: function(data){
                let html='';
                if(data.recent_transactions && data.recent_transactions.length>0){
                    data.recent_transactions.forEach(function(tx){
                        const badge = getStatusBadge(tx.status);
                        html += `<tr><td>${formatDate(tx.transaction_date)}</td><td><span class="badge bg-${tx.transaction_type==='IN'?'success':'warning'}">${tx.transaction_type}</span></td><td>${tx.model_name||'N/A'}</td><td>${tx.quantity}</td><td>${badge}</td></tr>`;
                    });
                } else { html = '<tr><td colspan="5" class="text-center">No recent transactions</td></tr>'; }
                $('#recentTransactions').html(html);
            }
        });
    }
    function getStatusBadge(status){ const map={'PENDING':'<span class="badge bg-warning">Pending</span>','APPROVED':'<span class="badge bg-success">Approved</span>','REJECTED':'<span class="badge bg-danger">Rejected</span>','COMPLETED':'<span class="badge bg-info">Completed</span>'}; return map[status]||'<span class="badge bg-secondary">Unknown</span>'; }
    function formatDate(dateStr){ const d=new Date(dateStr); return d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'}); }
    </script>
</body>
</html>