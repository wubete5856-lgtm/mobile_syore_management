<?php
$role = $_SESSION['role'] ?? '';
$userName = $_SESSION['full_name'] ?? 'User';
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        /* ===== SIDEBAR STYLES ===== */
        * { box-sizing: border-box; }
        body { margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f8f9fc; }

        .sidebar {
            position: fixed;
            top: 56px;
            left: 0;
            width: 220px;
            height: calc(100% - 56px);
            background: #1a1a2e;
            color: #fff;
            z-index: 1050;
            overflow-y: auto;
            overflow-x: hidden;
            display: flex;
            flex-direction: column;
            box-shadow: 2px 0 8px rgba(0,0,0,0.08);
            transition: transform 0.3s ease;
        }
        .sidebar-menu-wrapper {
            flex: 1;
            overflow-y: auto;
            padding: 6px 0 10px;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-menu li a {
            display: flex;
            align-items: center;
            padding: 8px 18px;
            color: rgba(255,255,255,0.75);
            text-decoration: none;
            transition: all 0.2s;
            border-left: 3px solid transparent;
            font-size: 0.85rem;
            gap: 10px;
        }
        .sidebar-menu li a i {
            width: 20px;
            text-align: center;
            font-size: 1rem;
        }
        .sidebar-menu li a:hover {
            background: rgba(255,255,255,0.06);
            color: #fff;
            border-left-color: #667eea;
        }
        .sidebar-menu li a.active {
            background: rgba(102,126,234,0.15);
            color: #fff;
            border-left-color: #667eea;
        }
        .sidebar-menu .menu-divider {
            height: 1px;
            background: rgba(255,255,255,0.06);
            margin: 6px 18px;
        }
        .sidebar-menu .menu-label {
            padding: 8px 18px 2px;
            font-size: 0.6rem;
            text-transform: uppercase;
            color: rgba(255,255,255,0.3);
            letter-spacing: 1px;
            font-weight: 600;
        }

        /* ===== TOP HEADER ===== */
        .top-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 56px;
            background: #fff;
            border-bottom: 1px solid #e3e6f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            z-index: 1040;
            box-shadow: 0 1px 4px rgba(0,0,0,0.04);
        }
        .top-header .brand {
            font-size: 1.1rem;
            font-weight: 700;
            color: #1a1a2e;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .top-header .brand i {
            color: #667eea;
            font-size: 1.3rem;
        }
        .top-header .user-area {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .top-header .user-area .user-name {
            font-weight: 500;
            color: #333;
            font-size: 0.85rem;
        }
        .top-header .user-area .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.8rem;
        }
        .top-header .user-area a {
            color: #555;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.3s;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .top-header .user-area a:hover {
            background: #f0f0f0;
        }
        .top-header .user-area a.text-danger {
            color: #e74a3b !important;
        }
        .top-header .user-area a.text-danger:hover {
            background: #fde8e8;
        }
        .top-header .user-area .divider {
            width: 1px;
            height: 24px;
            background: #ddd;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left: 220px;
            margin-top: 56px;
            padding: 16px 20px;
            min-height: calc(100vh - 56px);
            background: #f8f9fc;
        }

        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 1060;
            background: #1a1a2e;
            color: #fff;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            font-size: 1.2rem;
            cursor: pointer;
        }
        .sidebar-toggle:hover { background: #2a2a4e; }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); width: 240px; }
            .sidebar.open { transform: translateX(0); }
            .sidebar-toggle { display: block; }
            .main-content { margin-left: 0; padding-top: 10px; }
            .top-header .user-area .user-name { display: none; }
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-track { background: rgba(255,255,255,0.03); }
        .sidebar::-webkit-scrollbar-thumb { background: #667eea; border-radius: 4px; }
    </style>
</head>
<body>

<button class="sidebar-toggle" id="sidebarToggle">
    <i class="fas fa-bars"></i>
</button>

<div class="top-header">
    <a href="<?php echo BASE_URL; ?>dashboard.php" class="brand">
        <i class="fas fa-mobile-alt"></i>
        <span>Mobile Store</span>
    </a>
    <div class="user-area">
        <span class="user-name"><?php echo htmlspecialchars($userName); ?></span>
        <div class="user-avatar">
            <?php echo strtoupper(substr($userName, 0, 1)); ?>
        </div>
        <div class="divider"></div>
        <a href="<?php echo BASE_URL; ?>pages/profile.php" title="Profile">
            <i class="fas fa-user-cog"></i> Profile
        </a>
        <a href="<?php echo BASE_URL; ?>logout.php" class="text-danger" title="Logout">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>

<div class="sidebar" id="sidebar">
    <div class="sidebar-menu-wrapper">
        <ul class="sidebar-menu">
            <li>
                <a href="<?php echo BASE_URL; ?>dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </li>

            <?php if ($role === 'admin'): ?>
            <li class="menu-label">Admin</li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/users.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i> Users
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/roles.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'roles.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user-tag"></i> Roles
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/admin_reset_password.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'admin_reset_password.php' ? 'active' : ''; ?>">
                    <i class="fas fa-key"></i> Reset Passwords
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'settings.php' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/audit_log.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'audit_log.php' ? 'active' : ''; ?>">
                    <i class="fas fa-clipboard-list"></i> Audit Log
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/backup.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'backup.php' ? 'active' : ''; ?>">
                    <i class="fas fa-database"></i> Backup
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/suppliers.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'suppliers.php' ? 'active' : ''; ?>">
                    <i class="fas fa-truck"></i> Suppliers
                </a>
            </li>
            <li>
    <a href="<?php echo BASE_URL; ?>pages/categories.php">
        <i class="fas fa-tags"></i> Categories
    </a>
</li>
            <?php endif; ?>

            <?php if ($role === 'admin' || $role === 'manager'): ?>
            <li class="menu-label">Management</li>
            <?php if ($role === 'manager'): ?>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/approvals.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'approvals.php' ? 'active' : ''; ?>">
                    <i class="fas fa-check-double"></i> Approvals
                </a>
            </li>
            <?php endif; ?>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'reports.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/inventory.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'inventory.php' ? 'active' : ''; ?>">
                    <i class="fas fa-warehouse"></i> Inventory
                </a>
            </li>
            <?php if ($role === 'manager'): ?>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/suppliers.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'suppliers.php' ? 'active' : ''; ?>">
                    <i class="fas fa-truck"></i> Suppliers
                </a>
                <?php if ($role === 'manager'): ?>
<li class="menu-divider"></li>
<li>
    <a href="<?php echo BASE_URL; ?>pages/stock_balance.php">
        <i class="fas fa-database"></i> Stock Balance
    </a>
</li>
<?php endif; ?>
            </li>
            <?php endif; ?>
            <?php endif; ?>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/materials.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'materials.php' ? 'active' : ''; ?>">
                    <i class="fas fa-mobile-alt"></i> Mobile Models
                </a>
            </li>

            <?php if ($role === 'store_keeper'): ?>
            <li class="menu-divider"></li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/stock_in.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'stock_in.php' ? 'active' : ''; ?>">
                    <i class="fas fa-arrow-down"></i> Receive Stock
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/stock_out.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'stock_out.php' ? 'active' : ''; ?>">
                    <i class="fas fa-arrow-up"></i> Issue Materials
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/returns.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'returns.php' ? 'active' : ''; ?>">
                    <i class="fas fa-undo"></i> Returns
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/adjustments.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'adjustments.php' ? 'active' : ''; ?>">
                    <i class="fas fa-balance-scale"></i> Adjustments
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/transfers.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'transfers.php' ? 'active' : ''; ?>">
                    <i class="fas fa-exchange-alt"></i> Transfers
                </a>
            </li>
            <?php endif; ?>

            <?php if ($role !== 'admin'): ?>
            <li class="menu-divider"></li>
            
            <li>
                <a href="<?php echo BASE_URL; ?>pages/low_stock.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'low_stock.php' ? 'active' : ''; ?>">
                    <i class="fas fa-exclamation-triangle"></i> Low Stock
                </a>
            </li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/transactions.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'transactions.php' ? 'active' : ''; ?>">
                    <i class="fas fa-history"></i> History
                </a>
            </li>
            <?php endif; ?>

            <?php if ($role === 'store_keeper'): ?>
            <li class="menu-divider"></li>
            <li>
                <a href="<?php echo BASE_URL; ?>pages/reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'reports.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
            </li>
           
            <?php endif; ?>
        </ul>
        <!-- ===== EMPLOYEE ONLY ===== -->
<?php if ($role === 'employee'): ?>
<li class="menu-label">Employee</li>
<li>
    <a href="<?php echo BASE_URL; ?>pages/stock_out.php">
        <i class="fas fa-paper-plane"></i> Request Materials
    </a>
</li>
<li>
    <a href="<?php echo BASE_URL; ?>pages/transactions.php">
        <i class="fas fa-history"></i> My Requests
    </a>
</li>
<?php endif; ?>
    </div>
</div>

<div class="main-content">