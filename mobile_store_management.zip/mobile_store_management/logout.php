<?php
require_once 'config/config.php';

if (isset($_SESSION['user_id'])) {
    logActivity($_SESSION['user_id'], 'LOGOUT', 'User logged out', 'Authentication');
}

session_destroy();
header('Location: ' . BASE_URL . 'index.php');
exit();
?>